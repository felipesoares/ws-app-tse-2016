<?php

require_once "../config.inc.php";
require_once "../classes/controllers/BolsaController.php";

if ( $SESSION->logged() && !$SESSION->expired() ) {
	
    $bolsaController = new BolsaController();
    
    $dados = $bolsaController->pesquisar($_REQUEST["id"]);
    $dados = $dados ? $dados : array();
    
    $html = !$dados ? "<tr><td colspan='8'>Nenhum resultado foi encontrado para sua busca</td></tr>" : "";
        
    foreach( $dados as $objeto ){
        $html .= "
        <tr data-registro='".$objeto->getId()."'>
            <td>
                ".str_pad($objeto->getId(), 4, '0', STR_PAD_LEFT)."
            </td>
            <td>
                ".$objeto->getDoacao()->getId()."
            </td>
            <td>
                -
            </td>
            <td>
                -
            </td>
            <td>
                -
            </td>
            <td>
                <a href='?pagina=transferencias&acao=adicionar'>Transferir Bolsa</a>
            </td>
            <td>
                <a href='?pagina=bolsas&acao=editar&id=".$objeto->getId()."'>Visualizar</a>
            </td>
            <td>
                <a href='?pagina=bolsas&acao=editar&id=".$objeto->getId()."'>
                    <i class='fa fa-pencil-square-o'></i>
                </a>
                <a href='javascript:void(0)' data-remove='".$objeto->getId()."'> <i class='fa fa-times'></i> </a>
            </td>
        </tr>
        ";
    }
    
    #echo "<pre>"; print_r($html);exit;
    
    echo json_encode(array(
            "status" => "success",
            "msg" => "",
            "js" => "",
            "html" => $html 
        ));
    
}