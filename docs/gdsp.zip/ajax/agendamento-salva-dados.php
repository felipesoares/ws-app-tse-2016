<?php

require_once "../config.inc.php";
require_once "../classes/controllers/AgendamentoController.php";

$pagina = "agendamentos";

$atualizar = ( isset($_POST["id"][0]) );
$inserir   = ( !$atualizar );

// checar permissões

if ($_POST && $SESSION->logged() && !$SESSION->expired()) {
    
    $id             = $atualizar ? Functions::filtrarDados($_POST["id"]) : null;
    
    $pessoaId    = isset($_POST["pessoaId"]) ? Functions::filtrarDados($_POST["pessoaId"]) : null; #fk
    $motivoDoacaoId           = isset($_POST["motivoDoacaoId"]) ? Functions::filtrarDados($_POST["motivoDoacaoId"]) : null; #fk
    $estabelecimentoId = isset($_POST["estabelecimentoId"]) ? Functions::filtrarDados($_POST["estabelecimentoId"]) : null; #fk
    $campanhaId = isset($_POST["campanhaId"]) ? Functions::filtrarDados($_POST["campanhaId"]) : null; #fk
    $data            = isset($_POST["data"]) ? Functions::filtrarDados($_POST["data"]) : null; #validar/formatar
    $horario    = isset($_POST["horario"]) ? Functions::filtrarDados($_POST["horario"]) : null;
    
    $status = isset($_POST["status"]) ? Functions::filtrarDados($_POST["status"]) : null; #validar/default: 1-Ativo
    
    // Solicitação ruim
	if( !Functions::validarStatus($status) ){
        http_response_code(400); exit;
    }
    
    if( $ACESSO->isDoador() ){
        $_REQUEST["pessoaId"] = $pessoaId = $PESSOA->getId();
    }
    
    // Campos obrigatórios (inserção)
    if ($inserir && !($pessoaId)) {
        echo Functions::jsonRequiredFields(); exit;
    }
    
    // Campos obrigatórios
    if ( !($motivoDoacaoId && $estabelecimentoId && $data && $horario) ) {
        echo Functions::jsonRequiredFields(); exit;
    }
    
    // Validação de data
    if( !Functions::validarData($data) ){
        $js = "$('#data').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Data inválida", $js); exit;
    }
    
    list($dia, $mes, $ano) = explode("/", $data);
    
    $timestamp = mktime(0, 0, 0, $mes, $dia, $ano);
    
    if ( mktime(0, 0, 0, $mes, $dia, $ano) <= mktime(0, 0, 0, date("m"), date("d"), date("Y")) ){
        $js = "$('#data').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Por favor, selecione uma data com pelo menos um dia de antecedência", $js); exit;
    }
    
    if( !in_array( date("w", $timestamp), array(1,2,3,4,5) ) ){
        $js = "$('#data').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Por favor, selecione uma data em dia útil", $js); exit;
    }
    
    $agendamentoController = new AgendamentoController();
    
    if ($agendamentoController->checharDuplicidade($estabelecimentoId, $data, $horario, $id) ){
        $js = "$('#horario').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Horário encontra-se indisponível!", $js); exit;
    }
    
    if ( $atualizar ) { // atualizar
        
        if ( $agendamentoController->atualizar() ) {
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    } else if( $inserir ){ // inserir
        
        if ( $id = $agendamentoController->inserir() ) {
            
            $acao = "editar";
            $acao = "listar";
            echo Functions::jsonSuccessRedirect($pagina, $acao, $id); exit;
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    }
    
}