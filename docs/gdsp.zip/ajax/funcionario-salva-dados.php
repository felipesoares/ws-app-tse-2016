<?php

require_once "../config.inc.php";
require_once "../classes/controllers/FuncionarioController.php";

$pagina = "funcionarios";

$atualizar = ( isset($_POST["id"][0]) );
$inserir   = ( !$atualizar );

// checar permissões

if ($_POST && $SESSION->logged() && !$SESSION->expired()) {
    
    $id             = $atualizar ? Functions::filtrarDados($_POST["id"]) : null;
    
    $pessoaId    = isset($_POST["pessoaId"]) ? Functions::filtrarDados($_POST["pessoaId"]) : null; #fk
    $matricula           = isset($_POST["matricula"]) ? Functions::filtrarDados($_POST["matricula"]) : null;
    $dataAdmissao = isset($_POST["dataAdmissao"]) ? Functions::filtrarDados($_POST["dataAdmissao"]) : null; #validar/formatar
    $salario            = isset($_POST["salario"]) ? Functions::filtrarDados($_POST["salario"]) : null; #validar/formatar
    $cargoId    = isset($_POST["cargoId"]) ? Functions::filtrarDados($_POST["cargoId"]) : null; #fk
    $registroProfissional       = isset($_POST["registroProfissional"]) ? Functions::filtrarDados($_POST["registroProfissional"]) : null;
    $estabelecimentoId           = isset($_POST["estabelecimentoId"]) ? Functions::filtrarDados($_POST["estabelecimentoId"]) : null; #fk
    
    $status = isset($_POST["status"]) ? Functions::filtrarDados($_POST["status"]) : null; #validar/default: 1-Ativo
    
    // Solicitação ruim
	if( !Functions::validarStatus($status) ){
        http_response_code(400); exit;
    }
    
    // Campos obrigatórios (inserção)
    if ($inserir && !($pessoaId)) {
        echo Functions::jsonRequiredFields(); exit;
    }
    
    // Campos obrigatórios
    if ( !($matricula && $dataAdmissao && $salario && $cargoId && $estabelecimentoId) ) {
        echo Functions::jsonRequiredFields(); exit;
    }
    
    // Validação de data
    if( !Functions::validarData($dataAdmissao) ){
        $js = "$('#dataAdmissao').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Data de admissão inválida", $js); exit;
    }
    
    $funcionarioController = new FuncionarioController();
    
    if ($funcionarioController->checharDuplicidade("matricula", $matricula, $id) ){
        $js = "$('#matricula').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Matrícula \"{$matricula}\" previamente cadastrada!", $js); exit;
    }
    
    if ($registroProfissional && $funcionarioController->checharDuplicidade("registro_profissional", $registroProfissional, $id) ){
        $js = "$('#registroProfissional').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Registro Profissional \"{$registroProfissional}\" previamente cadastrado!", $js); exit;
    }
    
    if ( $atualizar ) { // atualizar
        
        if ( $funcionarioController->atualizar() ) {
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    } else if( $inserir ){ // inserir
        
        if ( $id = $funcionarioController->inserir() ) {
            
            $acao = "listar";
            $acao = "editar";
            echo Functions::jsonSuccessRedirect($pagina, $acao, $id); exit;
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    }
    
}