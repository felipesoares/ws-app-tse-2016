<?php

require_once "../config.inc.php";
require_once "../classes/controllers/CampanhaController.php";

$pagina = "campanhas";

$atualizar = ( isset($_POST["id"][0]) );
$inserir   = ( !$atualizar );

// checar permissões

if ($_POST && $SESSION->logged() && !$SESSION->expired()) {
    
    $id             = $atualizar ? Functions::filtrarDados($_POST["id"]) : null;
    
    $nome    = isset($_POST["nome"]) ? Functions::filtrarDados($_POST["nome"]) : null;
    $descricao    = isset($_POST["descricao"]) ? Functions::filtrarDados($_POST["descricao"]) : null;
    $dataInicio            = isset($_POST["dataInicio"]) ? Functions::filtrarDados($_POST["dataInicio"]) : null; #validar/formatar
    $dataFim            = isset($_POST["dataFim"]) ? Functions::filtrarDados($_POST["dataFim"]) : null; #validar/formatar
    $estabelecimentoId = isset($_POST["estabelecimentoId"]) ? Functions::filtrarDados($_POST["estabelecimentoId"]) : null; #fk/opcional
    
    $status = isset($_POST["status"]) ? Functions::filtrarDados($_POST["status"]) : null; #validar/default: 1-Ativo
    
    // Solicitação ruim
	if( !Functions::validarStatus($status) ){
        http_response_code(400); exit;
    }
    
    // Campos obrigatórios
    if ( !($nome && $descricao && $dataInicio && $dataFim) ) {
        echo Functions::jsonRequiredFields(); exit;
    }
    
    // Validação de dataInicio
    if( !Functions::validarData($dataInicio) ){
        $js = "$('#dataInicio').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Data inválida", $js); exit;
    }
    
    // Validação de dataFim
    if( !Functions::validarData($dataFim) ){
        $js = "$('#dataFim').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Data inválida", $js); exit;
    }
    
    list($dia, $mes, $ano) = explode("/", $dataInicio);
    list($dia2, $mes2, $ano2) = explode("/", $dataFim);
    
    $timestamp = mktime(0, 0, 0, $mes, $dia, $ano);
    $timestamp2 = mktime(0, 0, 0, $mes2, $dia2, $ano2);
    
    if ( mktime(0, 0, 0, $mes2, $dia2, $ano2) < mktime(0, 0, 0, $mes, $dia, $ano)  ){
        $js = "$('#dataInicio, #dataFim').focus().parent().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Por favor, selecione uma data Fim que não seja inferior à data Início", $js); exit;
    }
    
    $campanhaController = new CampanhaController();
    
    if ($campanhaController->checharDuplicidade("nome", $nome, $id) ){
        $js = "$('#nome').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Nome encontra-se indisponível!", $js); exit;
    }
    
    if ( $atualizar ) { // atualizar
        
        if ( $campanhaController->atualizar() ) {
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    } else if( $inserir ){ // inserir
        
        if ( $id = $campanhaController->inserir() ) {
            
            $acao = "editar";
            $acao = "listar";
            echo Functions::jsonSuccessRedirect($pagina, $acao, $id); exit;
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    }
    
}