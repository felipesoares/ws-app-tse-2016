<?php

require_once "../config.inc.php";
require_once "../classes/controllers/SorologiaController.php";

if ( $SESSION->logged() && !$SESSION->expired() ) {
	
    $sorologiaController = new SorologiaController();
    
    $dados = $sorologiaController->pesquisar($_REQUEST["id"]);
    $dados = $dados ? $dados : array();
    
    $html = !$dados ? "<tr><td colspan='8'>Nenhum resultado foi encontrado para sua busca</td></tr>" : "";
        
    foreach( $dados as $objeto ){
        $html .= "
        <tr data-registro='".$objeto->getId()."'>
            <td>
                ".str_pad($objeto->getId(), 4, '0', STR_PAD_LEFT)."
            </td>
            <td>";
        
        $bolsas = array();
        foreach( $objeto->getBolsas() as $bolsa ){
            $bolsas[] = str_pad($bolsa->getId(), 4, "0", STR_PAD_LEFT);
        }
        $html .= join($bolsas, ", ");
        
        $html .= "
            </td>
            <td>
                ".$objeto->getBolsas()[0]->getDoacao()->getDoador()->getIdDoador()."
            </td>
            <td>
                ".Functions::printHtml($objeto->getBolsas()[0]->getDoacao()->getDoador()->getNome())."
            </td>
            <td>
                ".Functions::printHtml($objeto->getLaboratorio()->getNome())."
            </td>
            <td>
                ".Functions::formatarDateTime($objeto->getBolsas()[0]->getDoacao()->getData())->date."
            </td>
            <td>
                <a href='?pagina=sorologias&acao=editar&id=".$objeto->getId()."'>Visualizar Resultados</a>
            </td>
            <td>
                <a href='javascript:void(0)' data-href='?pagina=sorologias&acao=editar&id=".$objeto->getId()."'>
                    <i class='fa fa-pencil-square-o'></i>
                </a>
                <a href='javascript:void(0)' data-remove='".$objeto->getId()."'> <i class='fa fa-times'></i> </a>
            </td>
        </tr>
        ";
    }
    
    #echo "<pre>"; print_r($html);exit;
    
    echo json_encode(array(
            "status" => "success",
            "msg" => "",
            "js" => "",
            "html" => $html 
        ));
    
}