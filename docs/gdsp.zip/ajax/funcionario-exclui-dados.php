<?php

require_once "../config.inc.php";
require_once "../classes/controllers/FuncionarioController.php";

if ( isset($_REQUEST["id"][0]) && $SESSION->logged() && !$SESSION->expired() ) {
	
    $funcionarioController = new FuncionarioController();
    
    if ( $funcionarioController->excluir() ) {
        
        $js = "";
        echo Functions::jsonSuccessDelete($js); exit;
        
    } else {
        
        $js = "";
        echo Functions::jsonErrorDelete($js); exit;
    }
    
}