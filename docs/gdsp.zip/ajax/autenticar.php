<?php

require_once "../config.inc.php";
require_once "../classes/controllers/AcessoController.php";

if (!$SESSION->logged() && $_POST) {
    
    $status = $msg = $js = "";
    
    $login = isset($_POST["login"]) ? Functions::filtrarDados($_POST["login"]) : null;
    $senha = isset($_POST["senha"]) ? Functions::filtrarDados($_POST["senha"]) : null;
    
    if (!$login || !$senha) {
        
        $js = "$('#txtLogin').focus();";
        echo Functions::jsonEncode("info", "Gentileza entrar com seu Usuário e Senha!", $js); exit;
    }
    
    $acessoController = new AcessoController();
    
    if ($acessoController->autenticar($login, $senha)) {
        $status = "success";
        $msg    = "Login efetuado com sucesso!";
        $js     = "";
        
    } else {
        $status = "error";
        $msg    = "Usuário e/ou Senha inválidos!";
        $js     = "$('#txtLogin').focus();";
    }
    
    echo Functions::jsonEncode($status, $msg, $js); exit;
    
}