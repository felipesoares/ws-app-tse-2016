<?php

require_once "../config.inc.php";
require_once "../classes/controllers/PessoaController.php";
require_once "../classes/controllers/AcessoController.php";

$pagina = "pessoas";

$atualizar = ( isset($_POST["id"][0]) );
$inserir   = ( !$atualizar );

// checar permissões

if ($_POST && $SESSION->logged() && !$SESSION->expired()) {
    
    $id             = $atualizar ? Functions::filtrarDados($_POST["id"]) : null;
    $nome           = isset($_POST["nome"]) ? Functions::filtrarDados($_POST["nome"]) : null;
    $cpf            = isset($_POST["cpf"]) ? Functions::filtrarDados($_POST["cpf"]) : null; #validar/formatar
    $rg             = isset($_POST["rg"]) ? Functions::filtrarDados($_POST["rg"]) : null;
    $dataNascimento = isset($_POST["dataNascimento"]) ? Functions::filtrarDados($_POST["dataNascimento"]) : null; #validar/formatar
    $sexo           = isset($_POST["sexo"]) ? Functions::filtrarDados($_POST["sexo"]) : null; #fk
    $tipoSanguineo  = isset($_POST["tipoSanguineo"]) ? Functions::filtrarDados($_POST["tipoSanguineo"]) : null; #fk/opcional
    $telefone       = isset($_POST["telefone"]) ? Functions::filtrarDados($_POST["telefone"]) : null;
    
    $cep         = isset($_POST["cep"]) ? Functions::filtrarDados($_POST["cep"]) : null; #validar/formatar
    $cidadeId    = isset($_POST["cidadeId"]) ? Functions::filtrarDados($_POST["cidadeId"]) : null; #fk
    $logradouro  = isset($_POST["logradouro"]) ? Functions::filtrarDados($_POST["logradouro"]) : null;
    $numero      = isset($_POST["numero"]) ? Functions::filtrarDados($_POST["numero"]) : null;
    $complemento = isset($_POST["complemento"]) ? Functions::filtrarDados($_POST["complemento"]) : null; #opcional
    $bairro      = isset($_POST["bairro"]) ? Functions::filtrarDados($_POST["bairro"]) : null;
    
    $email            = isset($_POST["email"]) ? Functions::filtrarDados($_POST["email"]) : null; #validar
    $emailConfirmacao = isset($_POST["emailConfirmacao"]) ? Functions::filtrarDados($_POST["emailConfirmacao"]) : null; #validar
    $senha            = isset($_POST["senha"]) ? Functions::filtrarDados($_POST["senha"]) : null; #validar
    $senhaConfirmacao = isset($_POST["senhaConfirmacao"]) ? Functions::filtrarDados($_POST["senhaConfirmacao"]) : null; #validar
    
    $perfilAcessoId = isset($_POST["perfilAcessoId"]) ? Functions::filtrarDados($_POST["perfilAcessoId"]) : null; #fk/default: 2-Doador
    $status = isset($_POST["status"]) ? Functions::filtrarDados($_POST["status"]) : null; #validar/default: 1-Ativo
    
    /*
    tipos de cadastros
    pessoa se auto cadastra
    administradores cadastram pessoas
    pessoas atualizam seus cadastros
    */
    
    if( $atualizar && !$ACESSO->isAdmin() ){
        $_REQUEST["status"] = $status = $PESSOA->getStatus();
    }
    
    // Solicitação ruim
	if( !Functions::validarStatus($status) ){
        http_response_code(400); exit;
    }
    
    // Campos obrigatórios
    if (!($nome && $cpf && $rg && $dataNascimento && $sexo && $telefone && $cep && $cidadeId && $logradouro && $numero && $bairro)) {
        echo Functions::jsonRequiredFields(); exit;
    }
    
    // Validação de cpf
    if( !Functions::validarCpf($cpf) ){
        $js = "$('#cpf').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonInvalidCpf($js); exit;
    }
    
    // Validação de data
    if( !Functions::validarData($dataNascimento) ){
        $js = "$('#dataNascimento').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Data de nascimento inválida", $js); exit;
    }
    
    // Validação de maioridade
    if( !Functions::validarMaioridade($dataNascimento) ){
        $js = "$('#dataNascimento').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonInvalidMaioridade($js); exit;
    }
    
    // Validação de cep
    if( !Functions::validarCep($cep) ){
        $js = "$('#cep').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonInvalidCep($js); exit;
    }
    
    // Campos obrigatórios (inserção)
    if ($inserir && !($email && $emailConfirmacao && $senha && $senhaConfirmacao && $perfilAcessoId)) {
        echo Functions::jsonRequiredFields(); exit;
    }
    
    // Validação de igualdade de e-mails (inserção)
    if( $inserir && ($email != $emailConfirmacao) ){
        $js = "$('#email, #emailConfirmacao').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Os e-mails digitados não se coincidem!", $js); exit;
    }
    
    // Validação de e-mail (inserção)
    if( $inserir && !Functions::validarEmail($email) ){
        $js = "$('#email, #emailConfirmacao').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonInvalidEmail($js); exit;
    }
    
    // Validação de igualdade de senhas (inserção)
    if( $inserir && ($senha != $senhaConfirmacao) ){
        $js = "$('#senha, #senhaConfirmacao').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "As senhas digitadas não se coincidem!", $js); exit;
    }
    
    $pessoaController = new PessoaController();
    
    if ($pessoaController->checharDuplicidade("cpf", Functions::cleanCpf($cpf), $id) ){
        $js = "$('#cpf').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "CPF \"{$cpf}\" previamente cadastrado!", $js); exit;
    }
    
    if ($pessoaController->checharDuplicidade("rg", $rg, $id) ){
        $js = "$('#rg').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "RG \"{$rg}\" previamente cadastrado!", $js); exit;
    }
    
    $acessoController = new AcessoController();
    
    if ($inserir && $acessoController->checharDuplicidade("email", $email, null) ){
        $js = "$('#email').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "E-mail \"{$email}\" previamente cadastrado!", $js); exit;
    }
    
    if ( $atualizar ) { // atualizar
        
        if ( $pessoaController->atualizar() ) {
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    } else if( $inserir ){ // inserir
        
        if ( $id = $pessoaController->inserir() ) {
            
            $acao = "listar";
            $acao = "editar";
            echo Functions::jsonSuccessRedirect($pagina, $acao, $id); exit;
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    }
    
}