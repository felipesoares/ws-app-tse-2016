<?php

require_once "../config.inc.php";
require_once "../classes/controllers/CidadeController.php";

if ($_GET) {
    
    $status = $msg = $js = $render = "";
    
    $siglaEstado = isset($_GET["sigla"]) ? Functions::filtrarDados($_GET["sigla"]) : null;
    
    if ($siglaEstado) {
        
        $cidadeController = new CidadeController();
        $cidades          = $cidadeController->carregarCidadesEstado($siglaEstado);
        
        $render = array();
        
        $aux = 0;
        
        foreach($cidades as $cidade){
            $render[$aux]["id"] = $cidade->getId();
            $render[$aux]["nome"] = $cidade->getNome();
            $aux++;
        }
        $status = "success";
        
        echo json_encode(array(
            "status" => $status,
            "msg" => $msg,
            "js" => $js,
            "render" => $render
        ));
    }
}