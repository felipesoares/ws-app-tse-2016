<?php

require_once "../config.inc.php";
require_once "../classes/controllers/DoadorController.php";

$pagina = "doadores";

$atualizar = ( isset($_POST["id"][0]) );
$inserir   = ( !$atualizar );

// checar permissões

if ($_POST && $SESSION->logged() && !$SESSION->expired()) {
    
    $id             = $atualizar ? Functions::filtrarDados($_POST["id"]) : null;
    
    $pessoaId    = isset($_POST["pessoaId"]) ? Functions::filtrarDados($_POST["pessoaId"]) : null; #fk
    $tipoDoadorId  = isset($_POST["tipoDoadorId"]) ? Functions::filtrarDados($_POST["tipoDoadorId"]) : null; #fk
    
    $status = isset($_POST["status"]) ? Functions::filtrarDados($_POST["status"]) : null; #validar/default: 1-Ativo
    
    
    // Solicitação ruim
	if( !Functions::validarStatus($status) ){
        http_response_code(400); exit;
    }
    
    // Campos obrigatórios
    if ( $inserir && !($pessoaId) ) {
        echo Functions::jsonRequiredFields(); exit;
    }
    
    if ( !($tipoDoadorId) ) {
        echo Functions::jsonRequiredFields(); exit;
    }
    
    
    $doadorController = new DoadorController();
    
    if ( $atualizar ) { // atualizar
        
        if ( $doadorController->atualizar() ) {
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    } else if( $inserir ){ // inserir
        
        if ( $id = $doadorController->inserir() ) {
            
            $acao = "listar";
            $acao = "editar";
            echo Functions::jsonSuccessRedirect($pagina, $acao, $id); exit;
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    }
    
}