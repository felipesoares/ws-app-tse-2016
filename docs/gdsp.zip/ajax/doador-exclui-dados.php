<?php

require_once "../config.inc.php";
require_once "../classes/controllers/DoadorController.php";

if ( isset($_REQUEST["id"][0]) && $SESSION->logged() && !$SESSION->expired() ) {
	
    $doadorController = new DoadorController();
    
    if ( $doadorController->excluir() ) {
        
        $js = "";
        echo Functions::jsonSuccessDelete($js); exit;
        
    } else {
        
        $js = "";
        echo Functions::jsonErrorDelete($js); exit;
    }
    
}