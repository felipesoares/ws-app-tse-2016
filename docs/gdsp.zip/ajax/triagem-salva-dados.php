<?php

require_once "../config.inc.php";
require_once "../classes/controllers/TriagemController.php";

$pagina = "triagens";

$atualizar = ( isset($_POST["id"][0]) );
$inserir   = ( !$atualizar );

// checar permissões

if ($_POST && $SESSION->logged() && !$SESSION->expired()) {
    
    $id             = $atualizar ? Functions::filtrarDados($_POST["id"]) : null;
    
    $pessoaId    = isset($_POST["pessoaId"]) ? Functions::filtrarDados($_POST["pessoaId"]) : null; #fk/
    $funcionarioId    = isset($_POST["funcionarioId"]) ? Functions::filtrarDados($_POST["funcionarioId"]) : null; #fk/
    $data            = isset($_POST["data"]) ? Functions::filtrarDados($_POST["data"]) : null; #validar/formatar
    $horario            = isset($_POST["horario"]) ? Functions::filtrarDados($_POST["horario"]) : null; #validar/formatar
    $q1 = isset($_POST["q1"]) ? Functions::filtrarDados($_POST["q1"]) : null;
    $q2 = isset($_POST["q2"]) ? Functions::filtrarDados($_POST["q2"]) : null;
    $q3 = isset($_POST["q3"]) ? Functions::filtrarDados($_POST["q3"]) : null;
    $q4 = isset($_POST["q4"]) ? Functions::filtrarDados($_POST["q4"]) : null;
    $q5 = isset($_POST["q5"]) ? Functions::filtrarDados($_POST["q5"]) : null;
    $q6 = isset($_POST["q6"]) ? Functions::filtrarDados($_POST["q6"]) : null;
    $q7 = isset($_POST["q7"]) ? Functions::filtrarDados($_POST["q7"]) : null;
    $q8 = isset($_POST["q8"]) ? Functions::filtrarDados($_POST["q8"]) : null;
    $q9 = isset($_POST["q9"]) ? Functions::filtrarDados($_POST["q9"]) : null;
    $q10 = isset($_POST["q10"]) ? Functions::filtrarDados($_POST["q10"]) : null;
    
    $aptidao_ok = isset($_POST["aptidao_ok"]) ? Functions::filtrarDados($_POST["aptidao_ok"]) : null; #validar
    
    // Solicitação ruim
	if( !in_array($aptidao_ok, array(0, 1)) ){
        http_response_code(400); exit;
    }
    
    // Campos obrigatórios
    if ( ! ( $funcionarioId && $data && $horario && in_array($q1, array("S", "N")) && in_array($q2, array("S", "N")) && in_array($q3, array("S", "N")) && in_array($q4, array("S", "N")) && in_array($q5, array("S", "N")) && in_array($q6, array("S", "N")) && in_array($q7, array("S", "N")) && in_array($q8, array("S", "N")) && in_array($q9, array("S", "N")) && in_array($q10, array("S", "N")) ) ) {
        echo Functions::jsonRequiredFields(); exit;
    }
    
    if( $inserir && !$pessoaId ){
        echo Functions::jsonRequiredFields(); exit;
    }
    
    // Validação de data
    if( !Functions::validarData($data) ){
        $js = "$('#data').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Data inválida", $js); exit;
    }
    
    // Validação de horário
    
    list($horas, $minutos) = explode(":", $horario);
    
    if( !($horas >= 0 && $horas <= 23) || !($minutos >= 0 && $minutos <=59) ){
        
        $js = "$('#horario').focus().parent('.form-group').addClass('has-warning')";
        echo Functions::jsonEncode("warning", "Horário inválido", $js); exit;
        
    }else{
        $_REQUEST["horario"] = $horario = $horario . ":00";
    }
    
    $triagemController = new TriagemController();
    
    if ( $atualizar ) { // atualizar
        
        if ( $triagemController->atualizar() ) {
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    } else if( $inserir ){ // inserir
        
        if ( $id = $triagemController->inserir() ) {
            
            $acao = "editar";
            $acao = "listar";
            echo Functions::jsonSuccessRedirect($pagina, $acao, $id); exit;
            
            $js = "";
            echo Functions::jsonSuccess($js); exit;
            
        } else {
            
            $js = "";
            echo Functions::jsonError($js); exit;
        }
        
    }
    
}