<?php

require_once "../config.inc.php";
require_once "../classes/controllers/TriagemController.php";

if ( isset($_REQUEST["id"][0]) && $SESSION->logged() && !$SESSION->expired() ) {
	
    $triagemController = new TriagemController();
    
    if ( $triagemController->excluir() ) {
        
        $js = "";
        echo Functions::jsonSuccessDelete($js); exit;
        
    } else {
        
        $js = "";
        echo Functions::jsonErrorDelete($js); exit;
    }
    
}