<?php

require_once "config.inc.php";
require_once "classes/controllers/PessoaController.php";

$pessoaController = new PessoaController();
$pessoaController->listarPaginaCadastro();

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

#echo "<pre>"; print_r($dados); exit;

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <meta name="robots" content="noindex, nofollow">

    <title>GDSP - Sistema de Gerenciamento de Doação de Sangue e Plaquetas</title>
    
    <link rel="icon" href="/views/assets/img/favicon-black-white.png">
    <link rel="icon" href="/views/assets/img/favicon-black-white.png" sizes="64x64">
    
    <!-- Bootstrap Core CSS -->
    <link href="/views/sb-admin-2/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="/views/sb-admin-2/bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/views/sb-admin-2/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="/views/sb-admin-2/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- fakeLoader.js -->
    <link href="/views/lib/js/fakeLoader.js-master/fakeLoader.css" rel="stylesheet">
    
    <!-- toastr -->
    <link href="/views/lib/js/CodeSeven-toastr-8bbd8db/build/toastr.min.css" rel="stylesheet">
    
    <!-- bootstrap datepicker -->
    <link href="/views/lib/js/bootstrap-datepicker-1.4.0-dist/css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css">
    
    <!-- style.css -->
    <link href="/views/assets/css/style.css" rel="stylesheet" type="text/css">
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    
    <div class="fakeLoader"></div>
    
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                
                <div class="cadastro-panel panel panel-default">
                    <div class="panel-heading">
                        Sistema de Gerenciamento de Doação de Sangue e Plaquetas - Cadastro de Doadores
                    </div>
                    <div class="panel-body">
                        <div class="row">

                            <a href="/" title="GDSP - Sistema de Gerenciamento de Doação de Sangue e Plaquetas">
                                <img src="/views/assets/img/logo-black-white.png" alt="Logo GDSP" width="190" height="50" class="logo-cadastro">
                            </a>

                            <div class="col-lg-12">
                                <form role="form" id="formulario" method="post" action="/ajax/efetuar-cadastro.php">
                                    
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="control-label" for="nome">Nome Completo*</label>
                                            <input type="text" class="form-control" id="nome" name="nome" value="" autocomplete="off">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label" for="cpf">CPF*</label>
                                            <input type="text" class="form-control" id="cpf" name="cpf" value="" placeholder="___.___.___-__" autocomplete="off" data-mask="cpf">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label" for="rg">RG*</label>
                                            <input type="text" class="form-control" id="rg" name="rg" value="" autocomplete="off">
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label class="control-label" for="dataNascimento">Data de Nascimento*</label>
                                            <input type="text" class="form-control datepicker-maioridade" id="dataNascimento" name="dataNascimento" value="" placeholder="__/__/____" autocomplete="off" data-mask="data">
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label class="control-label" for="sexo">Sexo*</label>
                                            <select class="form-control" id="sexo" name="sexo">
                                                <option value="M">Masculino</option>
                                                <option value="F">Feminino</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label class="control-label" for="tipoSanguineo">Tipo Sanguíneo</label>
                                            <select class="form-control" id="tipoSanguineo" name="tipoSanguineo">
                                                <option value="">Tipo Sanguíneo</option>
                                                <option value="0+">0+</option>
                                                <option value="A+">A+</option>
                                                <option value="B+">B+</option>
                                                <option value="AB+">AB+</option>
                                                <option value="O-">O-</option>
                                                <option value="A-">A-</option>
                                                <option value="B-">B-</option>
                                                <option value="AB-">AB-</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="control-label" for="telefone">Telefone*</label>
                                            <input type="tel" class="form-control" id="telefone" name="telefone" value="" placeholder="" autocomplete="off" data-mask="telefone">
                                        </div>
                                    </div>

                                    <div class="col-sm-12">
                                        <h3>Endereço</h3>
                                    </div>

                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="control-label" for="cep">CEP*</label>
                                            <input type="text" class="form-control" id="cep" name="cep" value="" autocomplete="off" placeholder="__.___-___" data-mask="cep">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label" for="estado">Estado*</label>
                                            <select class="form-control" id="estado">
                                                <option value="">Selecione o Estado</option>
                                                <?php 
                                                foreach( $dados["estado"] as $objeto )
                                                {
                                                ?>
                                                <option value="<?=$objeto->getSigla();?>"><?=$objeto->getNome();?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label" for="cidadeId">Cidade*</label>
                                            <select class="form-control" id="cidadeId" name="cidadeId">
                                                <option value="">Selecione a Cidade</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-8">
                                        <div class="form-group">
                                            <label class="control-label" for="logradouro">Logradouro*</label>
                                            <input type="tel" class="form-control" id="logradouro" name="logradouro" value="" placeholder="Endereço" autocomplete="off">
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label class="control-label" for="numero">Número*</label>
                                            <input type="tel" class="form-control" id="numero" name="numero" value="" autocomplete="off">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label" for="complemento">Complemento</label>
                                            <input type="tel" class="form-control" id="complemento" name="complemento" value="" placeholder="Bloco I - Apto 101" autocomplete="off">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label" for="bairro">Bairro*</label>
                                            <input type="tel" class="form-control" id="bairro" name="bairro" value="" autocomplete="off">
                                        </div>
                                    </div>

                                    <div class="col-sm-12">
                                        <h3>Autenticação</h3>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label" for="email">E-mail*</label>
                                            <input type="email" class="form-control" id="email" name="email" value="" autocomplete="off">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label" for="emailConfirmacao">Confirme seu e-mail*</label>
                                            <input type="email" class="form-control" id="emailConfirmacao" name="emailConfirmacao" value="" autocomplete="off">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label" for="senha">Senha*</label>
                                            <input type="password" class="form-control" id="senha" name="senha">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label" for="senhaConfirmacao">Confirme sua senha*</label>
                                            <input type="password" class="form-control" id="senhaConfirmacao" name="senhaConfirmacao">
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <a href="/" class="btn-link">Já possuo um cadastro.</a><br /><br />
                                            <button type="button" class="btn btn-primary" onclick="efetuarCadastro()">Salvar</button>
                                            <a href="/" class="btn btn-primary ml-15">Cancelar</a>
                                        </div>
                                    </div>

                                </form>
                            </div>
                            <!-- /.col-lg-12 (nested) -->

                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->

            </div>
        </div>
    </div>
    
    <!-- jQuery -->
    <script src="/views/sb-admin-2/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/views/sb-admin-2/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="/views/sb-admin-2/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="/views/sb-admin-2/dist/js/sb-admin-2.js"></script>

    <!-- ajax forms -->
    <script src="/views/lib/js/jquery.form.min.js"></script>
    
    <!-- masked input -->
    <script src="/views/lib/js/jquery.maskedinput.min.js"></script>
    
    <!-- fakeLoader.js -->
    <script src="/views/lib/js/fakeLoader.js-master/fakeLoader.js"></script>
    
    <!-- toastr -->
    <script src="/views/lib/js/CodeSeven-toastr-8bbd8db/build/toastr.min.js"></script>
    
    <!-- bootstrap datepicker -->
    <script src="/views/lib/js/bootstrap-datepicker-1.4.0-dist/js/bootstrap-datepicker.min.js"></script>
    <script src="/views/lib/js/bootstrap-datepicker-1.4.0-dist/locales/bootstrap-datepicker.pt-BR.min.js"></script>
    
    <!-- script.js -->
    <script src="/views/assets/js/script.js"></script>

</body>

</html>
