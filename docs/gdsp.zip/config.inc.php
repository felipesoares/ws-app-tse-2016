<?php

require_once "adodb5/adodb.inc.php";
require_once "classes/Session.php";
require_once "classes/Functions.php";
require_once "classes/controllers/AcessoController.php";
require_once "classes/controllers/PessoaController.php";

$CFG = array(
    "db_host" => "localhost",
    "db_user" => "root",
    "db_password" => "admin",
    "db_name" => "gdsp"
);

$CFG = (object) $CFG;

$DB = NewADOConnection("mysqli");
$DB->Connect($CFG->db_host, $CFG->db_user, $CFG->db_password, $CFG->db_name) or die("<h1>Falha na conex&atilde;o!</h1>");
$DB->EXECUTE("SET NAMES 'utf8'");

#$DB->debug = true;

$SESSION = new Session();

if( $SESSION->logged() && !$SESSION->expired() ){
    
    $ACESSO = new AcessoController();
    $ACESSO = $ACESSO->listarInfoAcesso( $SESSION->acessoId() )[0];

    $PESSOA = new PessoaController();
    $PESSOA = $PESSOA->listarDados(null, "p.acesso_id = " . $ACESSO->getId());

}

#echo "<pre>";print_r($PESSOA); exit;

date_default_timezone_set ( "America/Sao_Paulo" );

ini_set ( "display_errors", 1 );
ini_set ( "display_startup_erros", 1 );
error_reporting ( E_ALL );
