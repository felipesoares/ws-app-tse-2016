<?php

require_once "config.inc.php";

if ($_SERVER['REQUEST_URI'] == "/" && !$SESSION->logged()) {
    
    include_once "views/login.php";
    
} else {
    
    function error404() {
        
        header("HTTP/1.0 404 Not Found");
        
        print "<h1>Page Not Found</h1>";
        print "<a href='javascript:void(0)' onclick='javascript:window.history.back()'>Voltar</a>";
        
        exit;
    }
    
    function offline() {
        
        print "<h1>Acesso restrito</h1>";
        print "<a href='/'>Login</a>";
        
        exit;
    }
    
    function sessionExpired() {
        
        print "<h1>Sua sess&atilde;o expirou</h1>";
        print "<a href='/'>Login</a>";
        
        exit;
    }
    
    $pg   = isset($_GET["pagina"][0]) ? $_GET["pagina"] : "";
    $acao = isset($_GET["acao"][0]) ? $_GET["acao"] : "listar";
    
    $acoes_permitidas = array(
        "listar",
        "adicionar",
        "editar"
    );
    
    if ($_SERVER['REQUEST_URI'] == "/" && $SESSION->logged() && !$SESSION->expired()) {
        $pg = "dashboard";
        
    } else if (!$SESSION->logged()) {
        
        offline();
        
    } else if ($SESSION->expired()) {
        
        $SESSION->destroy();
        sessionExpired();
        
    } else if ($SESSION->logged() && $pg == "logout") {
        
        $SESSION->destroy();
        exit;
        
    } else if (!file_exists("views/" . $pg . ".php") || !in_array($acao, $acoes_permitidas) || $_GET["pagina"] == "login") {
        error404();
    }
    
    $seo = array(
        "dashboard" => array(
            "title" => "Dashboard",
            "h1" => "Dashboard",
            "controller" => "Dashboard"
        ),
        "pessoas" => array(
            "title" => "Pessoas",
            "h1" => "Pessoas",
            "controller" => "Pessoa"
        ),
        "funcionarios" => array(
            "title" => "Funcionários",
            "h1" => "Funcionários",
            "controller" => "Funcionario"
        ),
        "doadores" => array(
            "title" => "Doadores",
            "h1" => "Doadores",
            "controller" => "Doador"
        ),
        "receptores" => array(
            "title" => "Receptores",
            "h1" => "Receptores",
            "controller" => "Receptor"
        ),
        "estabelecimentos" => array(
            "title" => "Estabelecimentos",
            "h1" => "Estabelecimentos",
            "controller" => "Estabelecimento"
        ),
        "campanhas" => array(
            "title" => "Campanhas",
            "h1" => "Campanhas",
            "controller" => "Campanha"
        ),
        "agendamentos" => array(
            "title" => "Agendamentos",
            "h1" => "Agendamentos",
            "controller" => "Agendamento"
        ),
        "doacoes" => array(
            "title" => "Doações",
            "h1" => "Doações",
            "controller" => "Doacao"
        ),
        "triagens" => array(
            "title" => "Triagens",
            "h1" => "Triagens",
            "controller" => "Triagem"
        ),
        "bolsas" => array(
            "title" => "Bolsas de Sangue",
            "h1" => "Bolsas de Sangue",
            "controller" => "Bolsa"
        ),
        "transferencias" => array(
            "title" => "Transferências",
            "h1" => "Transferências",
            "controller" => "Transferencia"
        ),
        "sorologias" => array(
            "title" => "Sorologias",
            "h1" => "Sorologias",
            "controller" => "Sorologia"
        ),
        "relatorios" => array(
            "title" => "Relatórios",
            "h1" => "Relatórios",
            "controller" => "Relatorio"
        )
    );
    
    include_once "views/index.php";
    
}