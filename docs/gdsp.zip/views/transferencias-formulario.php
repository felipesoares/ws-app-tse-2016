<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

$atualizar = ( isset($_GET["id"][0]) );
$inserir   = ( !$atualizar );

#echo "<pre>"; print_r($dados); exit;

?>

<div class="panel panel-default">
    <div class="panel-heading">
        Detalhe Transferência
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form" id="formulario" method="post" action="/ajax/agendamento-salva-dados.php">
                    <input type="hidden" value="<?= $atualizar ? $_GET["id"] : "";?>" id="id" name="id">
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="disabledInput">Bolsa de Sangue*</label>
                            <input type="text" class="form-control" id="disabledInput" value="<?= $atualizar ? $dados[0]->getNome() : "0001";?>" disabled>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="estabelecimentoId">Unidade Origem*</label>
                            <select class="form-control" id="estabelecimentoId" name="estabelecimentoId" disabled>
                                <option value="">UCT001</option>
                                <?php 
                                foreach( $dados["estabelecimento"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getEstabelecimento()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="estabelecimentoId">Unidade Destino*</label>
                            <select class="form-control" id="estabelecimentoId" name="estabelecimentoId">
                                <option value="">Selecione a unidade de destino</option>
                                <?php 
                                foreach( $dados["estabelecimento"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getEstabelecimento()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="data">Data*</label>
                            <div class="input-group date">
                                <input type="text" class="form-control datepicker" id="data" name="data" value="<?= $atualizar ? Functions::formatarDateTime($dados[0]->getData())->date : "";?>" placeholder="__/__/____" autocomplete="off" data-mask="data">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="horario">Horário*</label>
                            <input type="text" class="form-control" id="horario" name="horario" value="<?= $atualizar ? Functions::formatarDateTime($dados[0]->getData())->date : "";?>" placeholder="__:__" autocomplete="off" data-mask="hora">
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <button type="button" class="btn btn-default" onclick="">Salvar</button>
                            <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                        </div>
                    </div>
                    
                </form>
            </div>
            <!-- /.col-lg-12 (nested) -->
            
        </div>
        <!-- /.row (nested) -->
    </div>
    <!-- /.panel-body -->
</div>
<!-- /.panel -->
