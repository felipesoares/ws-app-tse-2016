<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

#echo "<pre>"; print_r($dados); exit;

?>

<div class="row">
    
    <div class="col-lg-12">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th title="">ID</th>
                        <th title="">Doador</th>
                        <th title="">Motivo Doação</th>
                        <th title="">Unidade</th>
                        <th title="">Data</th>
                        <th title="">Horário</th>
                        <th title="">Coletor</th>
                        <th title="">Exames</th>
                        <?php 
                        if( !$ACESSO->isDoador() ){
                        ?>
                        <th title="">Relatório Doação</th>
                        <?php 
                        }
                        ?>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $aux = 0;
                    foreach( $dados as $objeto ){
                        $aux++;
                    ?>
                    <tr data-registro="<?=$objeto->getId();?>">
                        <td>
                            <?=$objeto->getId();?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getDoador()->getNome());?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getMotivoDoacao()->getNome());?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getEstabelecimento()->getNome());?>
                        </td>
                        <td>
                            <?=Functions::formatarDateTime($objeto->getData())->date;?>
                        </td>
                        <td>
                            <?=substr($objeto->getHorario(), 0, 5);?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getFuncionario()->getNome());?>
                        </td>
                        <td>
                            <a href="?pagina=doacoes&acao=editar&id=<?=$objeto->getId();?>&resultado-exames">Visualizar Resultados</a>
                        </td>
                        <?php 
                        if( !$ACESSO->isDoador() ){
                        ?>
                        <td>
                            <a href="?pagina=doacoes&acao=editar&id=<?=$objeto->getId();?>&relatorio-doacao">Gerar Relatório</a>
                        </td>
                        <?php 
                        }?>
                    </tr>
                    <?php 
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.col-lg-12 -->
    
</div>
<!-- /.row -->