<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

#echo "<pre>"; print_r($dados); exit;
#echo "<pre>"; print_r($_REQUEST["dados"]["sorologias"]); exit;

?>

<div class="row">
    
    <div class="col-lg-6">
        <div class="form-group">
            <label class="control-label" for="pesquisar-bolsa-sangue">Pesquisar bolsa pelo Identificador</label>
            <input type="text" class="form-control" id="pesquisar-bolsa-sangue" placeholder="Digite para pesquisar e tecle enter" autocomplete="off" autofocus>
        </div>
    </div>
    
    <div class="col-lg-12">
        
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th title="">ID</th>
                        <th title="">ID da Doação</th>
                        <th title="">Tipo Sanguíneo</th>
                        <th title="">Resultado dos Exames</th>
                        <th title="">Em estoque?</th>
                        <th title="">Transferência</th>
                        <th title="">Rastreabilidade</th>
                        <th title="">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $aux = 0;
                    foreach( $dados as $objeto ){
                        $aux++;
                    ?>
                    <tr data-registro="<?=$objeto->getId();?>">
                        <td>
                            <?=str_pad($objeto->getId(), 4, "0", STR_PAD_LEFT);?>
                        </td>
                        <td>
                            <?=$objeto->getDoacao()->getId();?>
                        </td>
                        <td>
                            <?php
                                $vetor = array("A+", "AB+", "B+", "0+", "A-", "AB-", "B-", "0-");
                                $sort = array_rand($vetor);
                                echo $vetor[$sort];
                            ?>
                        </td>
                        <td>
                            <?php
                                $vetor = array("Aprovado", "Reprovado");
                                $sort = array_rand($vetor);
                                echo $vetor[$sort];
                            ?>
                        </td>
                        <td>
                            <?php
                                $vetor = array("Sim", "Não");
                                $sort = array_rand($vetor);
                                echo $vetor[$sort];
                            ?>
                        </td>
                        <td>
                            <a href="?pagina=transferencias&acao=adicionar">Transferir Bolsa</a>
                        </td>
                        <td>
                            <a href="?pagina=<?=$_GET["pagina"];?>&acao=editar&id=<?=$objeto->getId();?>">Visualizar</a>
                        </td>
                        <td>
                            <a href="javascript:void(0)" data-href="?pagina=<?=$_GET["pagina"];?>&acao=editar&id=<?=$objeto->getId();?>">
                                <i class="fa fa-pencil-square-o"></i>
                            </a>
                            <a href="javascript:void(0)" data-remove="<?=$objeto->getId();?>"> <i class="fa fa-times"></i> </a>
                        </td>
                    </tr>
                    <?php 
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <!-- Modal -->
        <div class="modal fade" id="excluirModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <input type="hidden" id="id" value="" />
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Excluir Registro</h4>
                    </div>
                    <div class="modal-body">
                        Deseja mesmo excluir este registro?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" onclick="" data-dismiss="modal">Sim</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Não</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        
    </div>
    <!-- /.col-lg-12 -->
    
</div>
<!-- /.row -->
