<?php

#echo "<pre>"; print_r($_REQUEST["dados"]["uniaoFuncionariosDoadores"]); exit;

?>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                União Funcionários e Doadores
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>CPF</th>
                                <th>Nome</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            foreach( $_REQUEST["dados"]["uniaoFuncionariosDoadores"] as $dado ){
                            ?>
                            <tr>
                                <td><?=$dado["cpf"];?></td>
                                <td><?=$dado["nome"];?></td>
                            </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Interseção Funcionários e Doadores
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>CPF</th>
                                <th>Nome</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            foreach( $_REQUEST["dados"]["intersecaoFuncionariosDoadores"] as $dado ){
                            ?>
                            <tr>
                                <td><?=$dado["cpf"];?></td>
                                <td><?=$dado["nome"];?></td>
                            </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Diferença Funcionários e Doadores
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>CPF</th>
                                <th>Nome</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            foreach( $_REQUEST["dados"]["diferencaFuncionariosDoadores"] as $dado ){
                            ?>
                            <tr>
                                <td><?=$dado["cpf"];?></td>
                                <td><?=$dado["nome"];?></td>
                            </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Soma dos salários de todos os funcionários do sexo feminino cujo cargo é Médico
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Salário</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            foreach( $_REQUEST["dados"]["somaSalarioMedicas"] as $dado ){
                            ?>
                            <tr>
                                <td><?=$dado["salario"];?></td>
                            </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Quantidade de funcionários do sexo masculino cujo cargo é Enfermeiro
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Salário</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            foreach( $_REQUEST["dados"]["quantidadeEnfermeiros"] as $dado ){
                            ?>
                            <tr>
                                <td><?=$dado["quantidade"];?></td>
                            </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Salários mínimo e máximo dos funcionários do sexo masculino cujo cargo é Atendente ou Enfermeiro
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Salário mínimo</th>
                                <th>Salário máximo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            foreach( $_REQUEST["dados"]["salariosAtendentesEnfermeiros"] as $dado ){
                            ?>
                            <tr>
                                <td><?=$dado["minimo"];?></td>
                                <td><?=$dado["maximo"];?></td>
                            </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Médias das avaliações de atendimento por pessoa do sexo feminino, cujas médias resultantes são iguais ou superiores a 3
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Média</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            foreach( $_REQUEST["dados"]["mediasAvaliacoesAtendimento"] as $dado ){
                            ?>
                            <tr>
                                <td><?=$dado["nome"];?></td>
                                <td><?=$dado["media"];?></td>
                            </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>VISÃO</strong> (Quantidade de transfusões realizadas por tipo sanguíneo)
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Tipo Sanguíneo</th>
                                <th>Quantidade de Transfusões</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            foreach( $_REQUEST["dados"]["qtdTransfusoesTiposanguineo"] as $dado ){
                            ?>
                            <tr>
                                <td><?=$dado["tipo_sanguineo"];?></td>
                                <td><?=$dado["qtd_transfusoes"];?></td>
                            </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>VISÃO</strong> (Quantidade de doações espontâneas por sexo)
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Sexo</th>
                                <th>Quantidade de Transfusões</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            foreach( $_REQUEST["dados"]["qtdDoacoesEspontaneasSexo"] as $dado ){
                            ?>
                            <tr>
                                <td><?=$dado["sexo"];?></td>
                                <td><?=$dado["qtd_doacoes_espontaneas"];?></td>
                            </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
</div>
