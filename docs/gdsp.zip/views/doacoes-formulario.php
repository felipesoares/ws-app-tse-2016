<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

$atualizar = ( isset($_GET["id"][0]) );
$inserir   = ( !$atualizar );

#echo "<pre>"; print_r($dados); exit;

?>

<div class="panel panel-default">
    <div class="panel-heading">
        Detalhe Doação
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form" id="formulario" method="post" action="/ajax/doacoes-salva-dados.php">
                    <input type="hidden" value="<?= $atualizar ? $_GET["id"] : "";?>" id="id" name="id">
                    
                    <?php
                    if( $inserir && !$ACESSO->isDoador() ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="pessoaId">Doador*</label>
                            <select class="form-control" id="pessoaId" name="pessoaId">
                                <option value="">Selecione o Doador</option>
                                <?php 
                                foreach( $dados["pessoa"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>">
                                    <?=$objeto->getNome();?>
                                </option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <?php
                    }
                    ?>
                    
                    <?php
                    if( $atualizar ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="disabledInput">ID Doação</label>
                            <input type="text" class="form-control" id="disabledInput" value="<?= $atualizar ? $_GET["id"] : "";?>" disabled>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="disabledInput">Doador</label>
                            <input type="text" class="form-control" id="disabledInput" value="<?= $atualizar ? $dados[0]->getDoador()->getNome() : "";?>" disabled>
                        </div>
                    </div>
                    <?php }?>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="motivoDoacaoId">Motivo da Doação*</label>
                            <select class="form-control" id="motivoDoacaoId" name="motivoDoacaoId" <?= $atualizar ? "disabled" : "";?>>
                                <option value="">Selecione o Motivo da Doação</option>
                                <?php 
                                foreach( $dados["motivoDoacao"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getMotivoDoacao()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="estabelecimentoId">Unidade*</label>
                            <select class="form-control" id="estabelecimentoId" name="estabelecimentoId" <?= $atualizar ? "disabled" : "";?>>
                                <option value="">Selecione a Unidade</option>
                                <?php 
                                foreach( $dados["estabelecimento"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getEstabelecimento()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="data">Data*</label>
                            <div class="input-group date">
                                <input type="text" class="form-control datepicker-util-d1" id="data" name="data" value="<?= $atualizar ? Functions::formatarDateTime($dados[0]->getData())->date : "";?>" placeholder="__/__/____" autocomplete="off" data-mask="data" <?= $atualizar ? "disabled" : "";?>>
                                <span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="horario">Horário*</label>
                            <input type="text" class="form-control" id="horario" name="horario" value="<?= $atualizar ? substr($dados[0]->getHorario(), 0, 2) . ":00" : "";?>" placeholder="__:__" autocomplete="off" data-mask="hora" <?= $atualizar ? "disabled" : "";?>>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="coletorId">Coletor*</label>
                            <select class="form-control" id="coletorId" name="coletorId" <?= $atualizar ? "disabled" : "";?>>
                                <option value="">Selecione o Coletor</option>
                                <?php 
                                foreach( $dados["pessoa"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getFuncionario()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <?php
                    if( !$atualizar ){
                    ?>
                    <div class="col-sm-12">
                        <br>
                        <div class="form-group">
                            <button type="button" class="btn btn-default" onclick="">Salvar</button>
                            <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                        </div>
                    </div>
                    <?php }?>
                    
                </form>
            </div>
            <!-- /.col-lg-12 (nested) -->
            
        </div>
        <!-- /.row (nested) -->
    </div>
    <!-- /.panel-body -->
</div>
<!-- /.panel -->

<?php
if( $atualizar && isset($_GET["resultado-exames"]) ){
?>
<div class="panel panel-default">
    <div class="panel-heading">
        Resultado dos Exames
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <?php 
                if( isset($_REQUEST["dados"]["sorologia"][0]) ){
                    foreach( $_REQUEST["dados"]["sorologia"][0]->getResultadosExames() as $objeto )
                    {
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label><?=Functions::printHtml($objeto->getTipoExame()->getNome());?></label>
                            <!--
                            <p class="form-control-static"></p>
                            -->
                            <textarea class="form-control" rows="7" readonly><?=Functions::printHtml($objeto->getDescricao());?></textarea>
                        </div>
                    </div>
                    <?php 
                    }
                }?>
                
                <div class="col-sm-12">
                    <div class="form-group">
                        <button id="" class="btn btn-default" onclick="window.print(); return false;">Baixar PDF</button>
                        <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                    </div>
                </div>

            </div>
        
        </div>
    </div>
</div>
<!-- /.panel -->
<?php }?>

<?php
if( $atualizar && isset($_GET["relatorio-doacao"]) ){
?>
<div class="panel panel-default">
    <div class="panel-heading">
        Relatório de Doação
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form">
                    <input type="hidden" value="" id="id" name="id">
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>ID da Doação</label>
                            <p class="form-control-static"><?= $atualizar ? $_GET["id"] : "";?></p>
                            <br>
                            <label>Nome do Doador</label>
                            <p class="form-control-static"><?= $atualizar ? Functions::printHtml($dados[0]->getDoador()->getNome()) : "";?></p>
                            <br>
                            <label>Motivo da Doação</label>
                            <p class="form-control-static"><?= $atualizar ? Functions::printHtml($dados[0]->getMotivoDoacao()->getNome()) : "";?></p>
                            <br>
                            <label>Unidade</label>
                            <p class="form-control-static"><?= $atualizar ? Functions::printHtml($dados[0]->getEstabelecimento()->getNome()) : "";?></p>
                            <br>
                            <label>Data</label>
                            <p class="form-control-static"><?= $atualizar ? Functions::formatarDateTime($dados[0]->getData())->date : "";?></p>
                            <br>
                            <label>Horário</label>
                            <p class="form-control-static"><?= $atualizar ? substr($dados[0]->getHorario(), 0, 2) . ":00" : "";?></p>
                            <br>
                            <label>Coletor</label>
                            <p class="form-control-static"><?= $atualizar ? Functions::printHtml($dados[0]->getFuncionario()->getNome()) : "";?></p>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <button id="" class="btn btn-default" onclick="window.print(); return false;">Imprimir</button>
                            <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                        </div>
                    </div>
                    
                </form>
            </div>
        
        </div>
    </div>
</div>
<!-- /.panel -->
<?php }?>
