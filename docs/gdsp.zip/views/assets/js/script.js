var WWW = location.protocol + '//' + location.host;

var MSG_ERRO_REALIZAR_ACAO = "Erro ao tentar realizar ação!";
var MSG_BAD_REQUEST = "Bad Request!";

jQuery.fn.reset = function () {
    $(this).each(function () {
        this.reset();
    });
    //$("[placeholder]").val("");
}

jQuery.fn.validateEmail = function (email) {
    er = /^[a-zA-Z0-9][a-zA-Z0-9\._-]+@([a-zA-Z0-9\._-]+\.)[a-zA-Z-0-9]{2}/;
    if (er.exec(email))
        return true;
    else
        return false;
};

Number.prototype.number_format = function () {
    return this.toFixed(2).replace(".", ",").replace(/./g, function (c, i, a) {
        return i > 0 && c !== "," && (a.length - i) % 3 === 0 ? "." + c : c;
    });
}

Number.prototype.zeroFormat = function (n, f, r) {
    return n = new Array((++n, f ? (f = (this + "").length) < n ? n - f : 0 : n)).join(0), r ? this + n : n + this;
};

// demo: http://joaopereirawd.github.io/fakeLoader.js/demo/demo1.html

var showLoader = function () {
    $(".fakeLoader").fadeIn();
}

var hideLoader = function () {
    $(".fakeLoader").fadeOut();
}

// demo: http://codeseven.github.io/toastr/demo.html

toastr.options = {
    "closeButton": true,
    "debug": false,
    "newestOnTop": false,
    "progressBar": false,
    "positionClass": "toast-top-right",
    "preventDuplicates": true,
    "showDuration": "300",
    "hideDuration": "1000",
    "timeOut": "6000",
    "extendedTimeOut": "6000",
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
}

var showMessage = function (message, status) {

    if (message) {
        toastr[status](message);
    }

}

$(document).ready(function () {

    $("a[href='#']").click(function (e) {
        e.preventDefault();
    });

    $(".fakeLoader").fakeLoader({
        timeToHide: 1200,
        zIndex: "9999",
        spinner: "spinner3",
        bgColor: "rgba(40, 96, 144, 0.7)", // "rgba(40, 96, 144, 0.5)" rgba(52, 152, 219, 0.5)"
        //imagePath:
    });

    if (typeof ($.fn.mask) == "function") {
        $("input[data-mask='cpf']").mask("999.999.999-99");
        $("input[data-mask='cnpj']").mask("99.999.999/9999-99");
        $("input[data-mask='cep']").mask("99.999-999");
        $("input[data-mask='ddd']").mask("99");
        $("input[data-mask='data']").mask("99/99/9999");
        $("input[data-mask='hora']").mask("99:99");
        
        $("input[data-mask='telefone']").focusout(function () {
            var phone, element;
            element = $(this);
            element.unmask();
            phone = element.val().replace(/\D/g, '');
            if (phone.length > 10) {
                element.mask("(99) 99999-999?9");
            } else {
                element.mask("(99) 9999-9999?9");
            }
        }).trigger('focusout');
    }

    if (typeof ($.fn.maskMoney) == "function") {
        $("input[data-mask='money']").maskMoney({ thousands:'.', decimal:',', precision:2, allowZero:false, allowNegative:false });
    }
    
    if (typeof ($.fn.datepicker) == "function") {

        $('.datepicker').datepicker({
            format: "dd/mm/yyyy",
            language: "pt-BR",
            autoclose: true,
            todayHighlight: true
        });
        
        $('.datepicker-util').datepicker({
            format: "dd/mm/yyyy",
            language: "pt-BR",
            daysOfWeekDisabled: "0,6",
            autoclose: true,
            todayHighlight: true,
        });

        $('.datepicker-maioridade').datepicker({
            format: "dd/mm/yyyy",
            endDate: "-18y",
            startView: 2,
            language: "pt-BR",
            autoclose: true,
            todayHighlight: true
        });
        
        $('.datepicker-1d').datepicker({
            format: "dd/mm/yyyy",
            language: "pt-BR",
            endDate: "-1d",
            autoclose: true,
            todayHighlight: true,
        });
        
        $('.datepicker-0d').datepicker({
            format: "dd/mm/yyyy",
            language: "pt-BR",
            endDate: "0d",
            autoclose: true,
            todayHighlight: true,
        });
        
        $('.datepicker-d0').datepicker({
            format: "dd/mm/yyyy",
            language: "pt-BR",
            startDate: "0d",
            autoclose: true,
            todayHighlight: true,
        });
        
        $('.datepicker-d1').datepicker({
            format: "dd/mm/yyyy",
            language: "pt-BR",
            startDate: "+1d",
            autoclose: true,
            todayHighlight: true,
        });
        
        $('.datepicker-util-1d').datepicker({
            format: "dd/mm/yyyy",
            language: "pt-BR",
            endDate: "-1d",
            daysOfWeekDisabled: "0,6",
            autoclose: true,
            todayHighlight: true,
        });
        
        $('.datepicker-util-0d').datepicker({
            format: "dd/mm/yyyy",
            language: "pt-BR",
            endDate: "0d",
            daysOfWeekDisabled: "0,6",
            autoclose: true,
            todayHighlight: true,
        });
        
        $('.datepicker-util-d0').datepicker({
            format: "dd/mm/yyyy",
            language: "pt-BR",
            startDate: "0d",
            daysOfWeekDisabled: "0,6",
            autoclose: true,
            todayHighlight: true,
        });
        
        $('.datepicker-util-d1').datepicker({
            format: "dd/mm/yyyy",
            language: "pt-BR",
            startDate: "+1d",
            daysOfWeekDisabled: "0,6",
            autoclose: true,
            todayHighlight: true,
        });
        
    }

});

$(document).ready(function () {

    $("#btnSubmit").click(function () {
        autenticar();
    });

    $("#txtSenha").keypress(function (e) {
        if (e.which == 13) {
            autenticar();
        }
    });

    $("#deslogar").click(function () {

        var url = WWW + "?pagina=logout";

        $.ajax({

            method: "GET",
            url: url,
            dataType: "json",
            data: {},
            beforeSend: function (data) {
                showLoader();
            }

        }).done(function (data) {

            // Something

        }).fail(function (data) {

            // Something

        }).always(function (data) {

            hideLoader();
            showMessage("Logout efetuado com sucesso!", "info");
            window.location = "/";

        });

    });

    $("#estado").change(function () {

        var sigla = $(this).val();

        if (sigla) {

            var url = "ajax/carregar-cidades-estado.php";

            $.ajax({

                method: "GET",
                url: url,
                dataType: "json",
                data: {
                    sigla: sigla
                },
                beforeSend: function (data) {
                    $("#cidadeId").html("<option value=''>Carregando...</option>");
                }

            }).done(function (data) {

                if (data) {

                    if (data.status == "success") {

                        var valores = "<option value=''>Selecione a Cidade</option>";

                        $.each(data.render, function (index, value) {
                            valores += "<option value='" + value.id + "'>" + value.nome + "</value>";
                        });

                        $("#cidadeId").html(valores);

                    } else if (data.status == "warning") {
                        // Something

                    } else if (data.status == "info") {
                        // Something

                    } else if (data.status == "error") {
                        // Something
                    }

                    if (data.js) eval(data.js);

                } else {

                    showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
                    $("#cidadeId").html("<option value=''>Selecione a Cidade</option>");

                }

            }).fail(function (data) {

                showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
                $("#cidadeId").html("<option value=''>Selecione a Cidade</option>");

            }).always(function (data) {

                // Something

            });

        }else{
            
            $("#cidadeId").html("<option value=''>Selecione a Cidade</option>");
        }

    });
    
    
    var estabelecimentoTipoId = $("#estabelecimentoTipoId");

    if (estabelecimentoTipoId.val() != 1) {
        $("#estabelecimentoTipoUctId").addClass("disabled");
    }

    estabelecimentoTipoId.change(function () {

        if ($(this).val() != 1)
            $("#estabelecimentoTipoUctId").attr("disabled", "disabled").val("");
        else
            $("#estabelecimentoTipoUctId").removeAttr("disabled");

    });
    
    $("[data-remove]").click(function(){
       $("#id").val( $(this).attr("data-remove") );
       $('#excluirModal').modal();
    });
    
    $('#excluirModal').on('show.bs.modal', function (event) {
        // Something
    });
    
    $("#pesquisar-bolsa-sangue").on("keyup", function(e){

        if(e.keyCode != 13){
            return false;
        }
        
        var id = $(this).val();

        var url = "/ajax/pesquisar-bolsa-sangue.php";

        $.ajax({

            method: "GET",
            url: url,
            dataType: "json",
            data: {id: id},
            beforeSend: function (data) {
                //showLoader();
                $("tbody").html("<tr><td colspan='8'>Pesquisando bolsa, aguarde...</td></tr>");
            }

        }).done(function (data) {

            if (data) {

                if (data.status == "success") {

                    $("tbody").html(data.html);

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }

        }).fail(function (data) {

            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");

        }).always(function (data) {

            //hideLoader();
        });

    });
    
    $("#pesquisar-sorologia").on("keyup", function(e){
        
        if(e.keyCode != 13){
            return false;
        }
        
        $("#data-start, #data-end, #pesquisar-sorologia-nome-doador").val("");
        
        var id = $(this).val();
        
        var url = "/ajax/pesquisar-sorologia.php";

        $.ajax({

            method: "GET",
            url: url,
            dataType: "json",
            data: {id: id},
            beforeSend: function (data) {
                //showLoader();
                $("tbody").html("<tr><td colspan='8'>Pesquisando registros, aguarde...</td></tr>");
            }

        }).done(function (data) {

            if (data) {

                if (data.status == "success") {

                    $("tbody").html(data.html);

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }
            
            $("#limpar-pesquisa").fadeIn();
            
        }).fail(function (data) {

            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");

        }).always(function (data) {

            //hideLoader();
        });

    });
    
    $("#pesquisar-sorologia-nome-doador").on("keyup", function(e){
        
        if(e.keyCode != 13){
            return false;
        }
        
        $("#data-start, #data-end, #pesquisar-sorologia").val("");
        
        var nomeDoador = $(this).val();
        
        var url = "/ajax/pesquisar-sorologia-nome-doador.php";

        $.ajax({

            method: "GET",
            url: url,
            dataType: "json",
            data: {nomeDoador: nomeDoador},
            beforeSend: function (data) {
                //showLoader();
                $("tbody").html("<tr><td colspan='8'>Pesquisando registros, aguarde...</td></tr>");
            }

        }).done(function (data) {

            if (data) {

                if (data.status == "success") {

                    $("tbody").html(data.html);

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }
            
            $("#limpar-pesquisa").fadeIn();
            
        }).fail(function (data) {

            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");

        }).always(function (data) {

            //hideLoader();
        });

    });
    
    $("#pesquisar-sorologia-datas-doacoes").on("click", function(e){
        
        $("#pesquisar-sorologia, #pesquisar-sorologia-nome-doador").val("");
        
        var dataStart = $("#data-start").val();
        var dataEnd = $("#data-end").val();
        
        var url = "/ajax/pesquisar-sorologia-datas-doacoes.php";

        $.ajax({

            method: "GET",
            url: url,
            dataType: "json",
            data: {dataStart: dataStart, dataEnd: dataEnd},
            beforeSend: function (data) {
                //showLoader();
                $("tbody").html("<tr><td colspan='8'>Pesquisando registros, aguarde...</td></tr>");
            }

        }).done(function (data) {

            if (data) {

                if (data.status == "success") {

                    $("tbody").html(data.html);

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);
            }
            
            $("#limpar-pesquisa").fadeIn();
            
        }).fail(function (data) {

            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");

        }).always(function (data) {

            //hideLoader();
        });

    });
    
});

var autenticar = function () {

    $("#formularioLogin").ajaxSubmit({

        beforeSubmit: function () {
            showLoader();
        },
        error: function () {
            hideLoader();
            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
        },
        dataType: "json",
        success: function (data) {

            hideLoader();

            if (data) {

                if (data.status == "success") {

                    window.location = "/";

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            } else {
                showMessage(MSG_BAD_REQUEST, "error");
            }

        }
    });

}

var efetuarCadastro = function () {
    
    $("#formulario .form-group").removeClass("has-success has-warning has-error");
    
    $("#formulario").ajaxSubmit({
        
        beforeSubmit: function () {
            showLoader();
        },
        error: function () {
            hideLoader();
            showMessage(MSG_BAD_REQUEST, "error");
            //showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
        },
        dataType: "json",
        success: function (data) {
            
            hideLoader();
            
            if (data) {

                if (data.status == "success") {

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }

        }
        
    });

}

var pessoaSalvaDados = function () {
    
    $("#formulario .form-group").removeClass("has-success has-warning has-error");
    
    $("#formulario").ajaxSubmit({
        
        beforeSubmit: function () {
            showLoader();
        },
        error: function () {
            hideLoader();
            showMessage(MSG_BAD_REQUEST, "error");
            //showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
        },
        dataType: "json",
        success: function (data) {
            
            hideLoader();
            
            if (data) {

                if (data.status == "success") {

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }

        }
        
    });

}

var doadorSalvaDados = function () {
    
    $("#formulario .form-group").removeClass("has-success has-warning has-error");
    
    $("#formulario").ajaxSubmit({
        
        beforeSubmit: function () {
            showLoader();
        },
        error: function () {
            hideLoader();
            showMessage(MSG_BAD_REQUEST, "error");
            //showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
        },
        dataType: "json",
        success: function (data) {
            
            hideLoader();
            
            if (data) {

                if (data.status == "success") {

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }

        }
        
    });

}

var receptorSalvaDados = function () {
    
    $("#formulario .form-group").removeClass("has-success has-warning has-error");
    
    $("#formulario").ajaxSubmit({
        
        beforeSubmit: function () {
            showLoader();
        },
        error: function () {
            hideLoader();
            showMessage(MSG_BAD_REQUEST, "error");
            //showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
        },
        dataType: "json",
        success: function (data) {
            
            hideLoader();
            
            if (data) {

                if (data.status == "success") {

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }

        }
        
    });

}

var funcionarioSalvaDados = function () {
    
    $("#formulario .form-group").removeClass("has-success has-warning has-error");
    
    $("#formulario").ajaxSubmit({
        
        beforeSubmit: function () {
            showLoader();
        },
        error: function () {
            hideLoader();
            showMessage(MSG_BAD_REQUEST, "error");
            //showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
        },
        dataType: "json",
        success: function (data) {
            
            hideLoader();
            
            if (data) {

                if (data.status == "success") {

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }

        }
        
    });

}

var agendamentoSalvaDados = function () {
    
    $("#formulario .form-group").removeClass("has-success has-warning has-error");
    
    $("#formulario").ajaxSubmit({
        
        beforeSubmit: function () {
            showLoader();
        },
        error: function () {
            hideLoader();
            showMessage(MSG_BAD_REQUEST, "error");
            //showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
        },
        dataType: "json",
        success: function (data) {
            
            hideLoader();
            
            if (data) {

                if (data.status == "success") {

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }

        }
        
    });

}

var campanhaSalvaDados = function () {
    
    $("#formulario .form-group").removeClass("has-success has-warning has-error");
    
    $("#formulario").ajaxSubmit({
        
        beforeSubmit: function () {
            showLoader();
        },
        error: function () {
            hideLoader();
            showMessage(MSG_BAD_REQUEST, "error");
            //showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
        },
        dataType: "json",
        success: function (data) {
            
            hideLoader();
            
            if (data) {

                if (data.status == "success") {

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }

        }
        
    });

}

var triagemSalvaDados = function () {
    
    $("#formulario .form-group").removeClass("has-success has-warning has-error");
    
    $("#formulario").ajaxSubmit({
        
        beforeSubmit: function () {
            showLoader();
        },
        error: function () {
            hideLoader();
            showMessage(MSG_BAD_REQUEST, "error");
            //showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
        },
        dataType: "json",
        success: function (data) {
            
            hideLoader();
            
            if (data) {

                if (data.status == "success") {

                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }

        }
        
    });

}

var pessoaExcluiDados = function(id){
    
    var registroId = $("#id").val();
    
    if( registroId ){
        
        var url = "/ajax/pessoa-exclui-dados.php";
        
        $.ajax({
            
            method: "GET",
            url: url,
            dataType: "json",
            data: {id: registroId},
            beforeSend: function (data) {
                showLoader();
            }

        }).done(function (data) {
            
            if (data) {

                if (data.status == "success") {
                    
                    $("tr[data-registro='" + registroId + "']").hide('slow', function(){
                        $("tr[data-registro='" + registroId + "']").remove();
                    });
                    
                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }
            
        }).fail(function (data) {
            
            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
            
        }).always(function (data) {
            
            hideLoader();
        });
        
    }
    
}

var doadorExcluiDados = function(id){
    
    var registroId = $("#id").val();
    
    if( registroId ){
        
        var url = "/ajax/doador-exclui-dados.php";
        
        $.ajax({
            
            method: "GET",
            url: url,
            dataType: "json",
            data: {id: registroId},
            beforeSend: function (data) {
                showLoader();
            }

        }).done(function (data) {
            
            if (data) {

                if (data.status == "success") {
                    
                    $("tr[data-registro='" + registroId + "']").hide('slow', function(){
                        $("tr[data-registro='" + registroId + "']").remove();
                    });
                    
                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }
            
        }).fail(function (data) {
            
            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
            
        }).always(function (data) {
            
            hideLoader();
        });
        
    }
    
}

var receptorExcluiDados = function(id){
    
    var registroId = $("#id").val();
    
    if( registroId ){
        
        var url = "/ajax/receptor-exclui-dados.php";
        
        $.ajax({
            
            method: "GET",
            url: url,
            dataType: "json",
            data: {id: registroId},
            beforeSend: function (data) {
                showLoader();
            }

        }).done(function (data) {
            
            if (data) {

                if (data.status == "success") {
                    
                    $("tr[data-registro='" + registroId + "']").hide('slow', function(){
                        $("tr[data-registro='" + registroId + "']").remove();
                    });
                    
                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }
            
        }).fail(function (data) {
            
            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
            
        }).always(function (data) {
            
            hideLoader();
        });
        
    }
    
}

var funcionarioExcluiDados = function(id){
    
    var registroId = $("#id").val();
    
    if( registroId ){
        
        var url = "/ajax/funcionario-exclui-dados.php";
        
        $.ajax({
            
            method: "GET",
            url: url,
            dataType: "json",
            data: {id: registroId},
            beforeSend: function (data) {
                showLoader();
            }

        }).done(function (data) {
            
            if (data) {

                if (data.status == "success") {
                    
                    $("tr[data-registro='" + registroId + "']").hide('slow', function(){
                        $("tr[data-registro='" + registroId + "']").remove();
                    });
                    
                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }
            
        }).fail(function (data) {
            
            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
            
        }).always(function (data) {
            
            hideLoader();
        });
        
    }
    
}

var agendamentoExcluiDados = function(id){
    
    var registroId = $("#id").val();
    
    if( registroId ){
        
        var url = "/ajax/agendamento-exclui-dados.php";
        
        $.ajax({
            
            method: "GET",
            url: url,
            dataType: "json",
            data: {id: registroId},
            beforeSend: function (data) {
                showLoader();
            }

        }).done(function (data) {
            
            if (data) {

                if (data.status == "success") {
                    
                    $("tr[data-registro='" + registroId + "']").hide('slow', function(){
                        $("tr[data-registro='" + registroId + "']").remove();
                    });
                    
                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }
            
        }).fail(function (data) {
            
            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
            
        }).always(function (data) {
            
            hideLoader();
        });
        
    }
    
}

var campanhaExcluiDados = function(id){
    
    var registroId = $("#id").val();
    
    if( registroId ){
        
        var url = "/ajax/campanha-exclui-dados.php";
        
        $.ajax({
            
            method: "GET",
            url: url,
            dataType: "json",
            data: {id: registroId},
            beforeSend: function (data) {
                showLoader();
            }

        }).done(function (data) {
            
            if (data) {

                if (data.status == "success") {
                    
                    $("tr[data-registro='" + registroId + "']").hide('slow', function(){
                        $("tr[data-registro='" + registroId + "']").remove();
                    });
                    
                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }
            
        }).fail(function (data) {
            
            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
            
        }).always(function (data) {
            
            hideLoader();
        });
        
    }
    
}

var triagemExcluiDados = function(id){
    
    var registroId = $("#id").val();
    
    if( registroId ){
        
        var url = "/ajax/triagem-exclui-dados.php";
        
        $.ajax({
            
            method: "GET",
            url: url,
            dataType: "json",
            data: {id: registroId},
            beforeSend: function (data) {
                showLoader();
            }

        }).done(function (data) {
            
            if (data) {

                if (data.status == "success") {
                    
                    $("tr[data-registro='" + registroId + "']").hide('slow', function(){
                        $("tr[data-registro='" + registroId + "']").remove();
                    });
                    
                } else if (data.status == "info") {

                } else if (data.status == "warning") {

                } else if (data.status == "error") {

                }

                showMessage(data.msg, data.status);

                if (data.js) eval(data.js);

            }
            
        }).fail(function (data) {
            
            showMessage(MSG_ERRO_REALIZAR_ACAO, "error");
            
        }).always(function (data) {
            
            hideLoader();
        });
        
    }
    
}
