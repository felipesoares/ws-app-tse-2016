<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

$atualizar = ( isset($_GET["id"][0]) );
$inserir   = ( !$atualizar );

#echo "<pre>"; print_r($dados); exit;

?>

<div class="panel panel-default">
    <div class="panel-heading">
        Detalhe Triagem
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form" id="formulario" method="post" action="/ajax/triagem-salva-dados.php">
                    <input type="hidden" value="<?= $atualizar ? $_GET["id"] : "";?>" id="id" name="id">
                    
                    <?php
                    if( $inserir ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="pessoaId">Candidato*</label>
                            <select class="form-control" id="pessoaId" name="pessoaId">
                                <option value="">Selecione o Candidato</option>
                                <?php 
                                foreach( $dados["pessoa"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>">
                                    <?=$objeto->getNome();?>
                                </option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <?php
                    }
                    ?>
                    
                    <?php
                    if( $atualizar ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="disabledInput">Candidato</label>
                            <input type="text" class="form-control" id="disabledInput" value="<?= $atualizar ? $dados[0]->getPessoa()->getNome() : "";?>" disabled>
                        </div>
                    </div>
                    <?php }?>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="funcionarioId">Funcionário*</label>
                            <select class="form-control" id="funcionarioId" name="funcionarioId">
                                <option value="">Selecione o Funcionário</option>
                                <?php 
                                foreach( $dados["funcionario"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getIdFuncionario();?>" <?=($atualizar && $dados[0]->getFuncionario()->getIdFuncionario() == $objeto->getIdFuncionario()) ? "selected" : "";?> >
                                    <?=$objeto->getNome();?>
                                </option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="data">Data*</label>
                            <div class="input-group date">
                                <input type="text" class="form-control datepicker" id="data" name="data" value="<?= $atualizar ? Functions::formatarDateTime($dados[0]->getData())->date : "";?>" placeholder="__/__/____" autocomplete="off" data-mask="data">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="horario">Horário*</label>
                            <input type="text" class="form-control" id="horario" name="horario" value="<?= $atualizar ? substr($dados[0]->getHorario(), 0, 5) : "";?>" placeholder="__:__" autocomplete="off" data-mask="hora">
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <h3>Questionário</h3>
                    </div>
                    
                    <div class="col-sm-12">
                        
                        <div class="form-group">
                            <label class="control-label">Bebe?*</p>
                            
                            <label class="radio-inline">
                                <input type="radio" name="q1" id="q1-1" value="S" <?= $atualizar && $dados[0]->getQ1() == "S" ? "checked" : "";?> >Sim
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="q1" id="q1-2" value="N" <?= $atualizar && $dados[0]->getQ1() == "N" ? "checked" : "";?> >Não
                            </label>
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        
                        <div class="form-group">
                            <label class="control-label">Fuma?*</p>
                            
                            <label class="radio-inline">
                                <input type="radio" name="q2" id="q2-1" value="S" <?= $atualizar && $dados[0]->getQ2() == "S" ? "checked" : "";?> >Sim
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="q2" id="q2-2" value="N" <?= $atualizar && $dados[0]->getQ2() == "N" ? "checked" : "";?> >Não
                            </label>
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        
                        <div class="form-group">
                            <label class="control-label">Faz uso de alguma medicação?*</p>
                            
                            <label class="radio-inline">
                                <input type="radio" name="q3" id="q3-1" value="S" <?= $atualizar && $dados[0]->getQ3() == "S" ? "checked" : "";?> >Sim
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="q3" id="q3-2" value="N" <?= $atualizar && $dados[0]->getQ3() == "N" ? "checked" : "";?> >Não
                            </label>
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        
                        <div class="form-group">
                            <label class="control-label">Faz ou já fez uso de algum tipo de droga?*</p>
                            
                            <label class="radio-inline">
                                <input type="radio" name="q4" id="q4-1" value="S" <?= $atualizar && $dados[0]->getQ4() == "S" ? "checked" : "";?> >Sim
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="q4" id="q4-2" value="N" <?= $atualizar && $dados[0]->getQ4() == "N" ? "checked" : "";?> >Não
                            </label>
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        
                        <div class="form-group">
                            <label class="control-label">Possui doença crônica?*</p>
                            
                            <label class="radio-inline">
                                <input type="radio" name="q5" id="q5-1" value="S" <?= $atualizar && $dados[0]->getQ5() == "S" ? "checked" : "";?> >Sim
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="q5" id="q5-2" value="N" <?= $atualizar && $dados[0]->getQ5() == "N" ? "checked" : "";?> >Não
                            </label>
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        
                        <div class="form-group">
                            <label class="control-label">Já realizou algum procedimento cirúrgico?*</p>
                            
                            <label class="radio-inline">
                                <input type="radio" name="q6" id="q6-1" value="S" <?= $atualizar && $dados[0]->getQ6() == "S" ? "checked" : "";?> >Sim
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="q6" id="q6-2" value="N" <?= $atualizar && $dados[0]->getQ6() == "N" ? "checked" : "";?> >Não
                            </label>
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        
                        <div class="form-group">
                            <label class="control-label">Fez tatuagem ou colocou piercing nos últimos 3 meses?*</p>
                            
                            <label class="radio-inline">
                                <input type="radio" name="q7" id="q7-1" value="S" <?= $atualizar && $dados[0]->getQ7() == "S" ? "checked" : "";?> >Sim
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="q7" id="q7-2" value="N" <?= $atualizar && $dados[0]->getQ7() == "N" ? "checked" : "";?> >Não
                            </label>
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        
                        <div class="form-group">
                            <label class="control-label">Pratica sexo adotando métodos de prevenção contra DSTs?*</p>
                            
                            <label class="radio-inline">
                                <input type="radio" name="q8" id="q8-1" value="S" <?= $atualizar && $dados[0]->getQ8() == "S" ? "checked" : "";?> >Sim
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="q8" id="q8-2" value="N" <?= $atualizar && $dados[0]->getQ8() == "N" ? "checked" : "";?> >Não
                            </label>
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        
                        <div class="form-group">
                            <label class="control-label">Já teve convulsões?*</p>
                            
                            <label class="radio-inline">
                                <input type="radio" name="q9" id="q9-1" value="S" <?= $atualizar && $dados[0]->getQ9() == "S" ? "checked" : "";?> >Sim
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="q9" id="q9-2" value="N" <?= $atualizar && $dados[0]->getQ9() == "N" ? "checked" : "";?> >Não
                            </label>
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        
                        <div class="form-group">
                            <label class="control-label">Em seu histórico, já realizou transfusão de sangue?*</p>
                            
                            <label class="radio-inline">
                                <input type="radio" name="q10" id="q10-1" value="S" <?= $atualizar && $dados[0]->getQ10() == "S" ? "checked" : "";?> >Sim
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="q10" id="q10-2" value="N" <?= $atualizar && $dados[0]->getQ10() == "N" ? "checked" : "";?> >Não
                            </label>
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        <br>
                        <div class="form-group">
                            <label class="control-label" for="aptidao_ok">Selecione a aptidão para doação do candidato*</label>
                            <select class="form-control" id="aptidao_ok" name="aptidao_ok">
                                <option value="1" <?=($atualizar && $_REQUEST["dados"][0]->getAptidao() == 1) ? "selected" : "";?> >Apto</option>
                                <option value="0" <?=($atualizar && $_REQUEST["dados"][0]->getAptidao() == 0) ? "selected" : "";?> >Inapto</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <br>
                        <div class="form-group">
                            <button type="button" class="btn btn-default" onclick="triagemSalvaDados()">Salvar</button>
                            <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                        </div>
                    </div>
                    
                </form>
            </div>
            <!-- /.col-lg-12 (nested) -->
            
        </div>
        <!-- /.row (nested) -->
    </div>
    <!-- /.panel-body -->
</div>
<!-- /.panel -->
