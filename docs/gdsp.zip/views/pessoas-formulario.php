<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

$atualizar = ( isset($_GET["id"][0]) );
$inserir   = ( !$atualizar );

#echo "<pre>"; print_r($dados); exit;

?>

<div class="panel panel-default">
    <div class="panel-heading">
        Dados Pessoais
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form" id="formulario" method="post" action="/ajax/pessoa-salva-dados.php">
                    <input type="hidden" value="<?= $atualizar ? $_GET["id"] : "";?>" id="id" name="id">
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="nome">Nome Completo*</label>
                            <input type="text" class="form-control" id="nome" name="nome" value="<?= $atualizar ? $dados[0]->getNome() : "";?>" autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="cpf">CPF*</label>
                            <input type="text" class="form-control" id="cpf" name="cpf" value="<?= $atualizar ? $dados[0]->getCpf() : "";?>" placeholder="___.___.___-__" autocomplete="off" data-mask="cpf">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="rg">RG*</label>
                            <input type="text" class="form-control" id="rg" name="rg" value="<?= $atualizar ? $dados[0]->getRg() : "";?>" autocomplete="off">
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="control-label" for="dataNascimento">Data de Nascimento*</label>
                            <div class="input-group date">
                                <input type="text" class="form-control datepicker-maioridade" id="dataNascimento" name="dataNascimento" value="<?= $atualizar ? Functions::formatarDateTime($dados[0]->getDataNascimento())->date : "";?>" placeholder="__/__/____" autocomplete="off" data-mask="data">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="control-label" for="sexo">Sexo*</label>
                            <select class="form-control" id="sexo" name="sexo">
                                <option value="M" <?=($atualizar && $_REQUEST["dados"][0]->getSexo() == 'M') ? "selected" : "";?> >Masculino</option>
                                <option value="F" <?=($atualizar && $_REQUEST["dados"][0]->getSexo() == 'F') ? "selected" : "";?> >Feminino</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="control-label" for="tipoSanguineo">Tipo Sanguíneo</label>
                            <select class="form-control" id="tipoSanguineo" name="tipoSanguineo">
                                <option value="">Tipo Sanguíneo</option>
                                <option value="0+" <?=($atualizar && $_REQUEST["dados"][0]->getTipoSanguineo() == '0+') ? "selected" : "";?> >0+</option>
                                <option value="A+" <?=($atualizar && $_REQUEST["dados"][0]->getTipoSanguineo() == 'A+') ? "selected" : "";?> >A+</option>
                                <option value="B+" <?=($atualizar && $_REQUEST["dados"][0]->getTipoSanguineo() == 'B+') ? "selected" : "";?> >B+</option>
                                <option value="AB+" <?=($atualizar && $_REQUEST["dados"][0]->getTipoSanguineo() == 'AB+') ? "selected" : "";?> >AB+</option>
                                <option value="O-" <?=($atualizar && $_REQUEST["dados"][0]->getTipoSanguineo() == 'O-') ? "selected" : "";?> >O-</option>
                                <option value="A-" <?=($atualizar && $_REQUEST["dados"][0]->getTipoSanguineo() == 'A-') ? "selected" : "";?> >A-</option>
                                <option value="B-" <?=($atualizar && $_REQUEST["dados"][0]->getTipoSanguineo() == 'B-') ? "selected" : "";?> >B-</option>
                                <option value="AB-" <?=($atualizar && $_REQUEST["dados"][0]->getTipoSanguineo() == 'AB-') ? "selected" : "";?> >AB-</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="telefone">Telefone*</label>
                            <input type="tel" class="form-control" id="telefone" name="telefone" value="<?= $atualizar ? $dados[0]->getTelefone() : "";?>" placeholder="" autocomplete="off" data-mask="telefone">
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <h3>Endereço</h3>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="cep">CEP*</label>
                            <input type="text" class="form-control" id="cep" name="cep" value="<?= $atualizar ? $dados[0]->getEndereco()->getCep() : "";?>" autocomplete="off" placeholder="__.___-___" data-mask="cep">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="estado">Estado*</label>
                            <select class="form-control" id="estado">
                                <option value="">Selecione o Estado</option>
                                <?php 
                                foreach( $dados["estado"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getSigla();?>" <?=($atualizar && $_REQUEST["dados"][0]->getEndereco()->getCidade()->getEstado()->getSigla() == $objeto->getSigla()) ? "selected" : "";?>><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="cidadeId">Cidade*</label>
                            <select class="form-control" id="cidadeId" name="cidadeId">
                                <option value="">Selecione a Cidade</option>
                                <?php 
                                foreach( $dados["cidade"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getEndereco()->getCidade()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-8">
                        <div class="form-group">
                            <label class="control-label" for="logradouro">Logradouro*</label>
                            <input type="tel" class="form-control" id="logradouro" name="logradouro" value="<?= $atualizar ? $dados[0]->getEndereco()->getLogradouro() : "";?>" placeholder="Endereço" autocomplete="off">
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="control-label" for="numero">Número*</label>
                            <input type="tel" class="form-control" id="numero" name="numero" value="<?= $atualizar ? $dados[0]->getEndereco()->getNumero() : "";?>" autocomplete="off">
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="complemento">Complemento</label>
                            <input type="tel" class="form-control" id="complemento" name="complemento" value="<?= $atualizar ? $dados[0]->getEndereco()->getComplemento() : "";?>" placeholder="Bloco I - Apto 101" autocomplete="off">
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="bairro">Bairro*</label>
                            <input type="tel" class="form-control" id="bairro" name="bairro" value="<?= $atualizar ? $dados[0]->getEndereco()->getBairro() : "";?>" autocomplete="off">
                        </div>
                    </div>
                    
                    <?php if( $ACESSO->isAdmin() ) {?>
                    <div class="col-sm-12">
                        <h3>Status</h3>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="status">Status*</label>
                            <select class="form-control" id="status" name="status">
                                <option value="1" <?=($atualizar && $_REQUEST["dados"][0]->getStatus() == 1) ? "selected" : "";?> >Ativo</option>
                                <option value="2" <?=($atualizar && $_REQUEST["dados"][0]->getStatus() == 2) ? "selected" : "";?> >Inativo</option>
                            </select>
                        </div>
                    </div>
                    <?php } ?>
                    
                    <?php 
                    if( $inserir ){ # && admin
                    ?>
                    
                    <div class="col-sm-12">
                        <h3>Autenticação</h3>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="email">E-mail*</label>
                            <input type="email" class="form-control" id="email" name="email" value="" autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="emailConfirmacao">Confirme o e-mail*</label>
                            <input type="email" class="form-control" id="emailConfirmacao" name="emailConfirmacao" value="" autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="senha">Senha*</label>
                            <input type="password" class="form-control" id="senha" name="senha">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="senhaConfirmacao">Confirme a senha*</label>
                            <input type="password" class="form-control" id="senhaConfirmacao" name="senhaConfirmacao">
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <h3>Permissões</h3>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="perfilAcessoId">Perfil de Acesso*</label>
                            <select class="form-control" id="perfilAcessoId" name="perfilAcessoId">
                                <?php 
                                foreach( $dados["perfilAcesso"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>"><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <?php
                    }?>
                    
                    <div class="col-sm-12">
                        <br>
                        <div class="form-group">
                            <button type="button" class="btn btn-default" onclick="pessoaSalvaDados()">Salvar</button>
                            <?php if( $ACESSO->isAdmin() ) {?>
                            <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                            <?php } ?>
                        </div>
                    </div>
                    
                </form>
            </div>
            <!-- /.col-lg-12 (nested) -->
            
        </div>
        <!-- /.row (nested) -->
    </div>
    <!-- /.panel-body -->
</div>
<!-- /.panel -->

<?php /*
<div class="panel panel-default">
    <div class="panel-heading">
        Alterar E-mail
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form">
                    <input type="hidden" value="" id="id" name="id">
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="email-alterar">E-mail</label>
                            <input type="email" class="form-control" id="email-alterar" name="email-alterar" value="" autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="emailConfirmacao-alterar">Confirme seu e-mail</label>
                            <input type="email" class="form-control" id="emailConfirmacao-alterar" name="emailConfirmacao" value="" autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <button type="submit" id="" class="btn btn-default">Salvar</button>
                            <button type="reset" class="btn btn-default ml-15">Cancelar</button>
                        </div>
                    </div>
                    
                </form>
            </div>
        
        </div>
    </div>
</div>
<!-- /.panel -->

<div class="panel panel-default">
    <div class="panel-heading">
        Alterar Senha
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form">
                    <input type="hidden" value="" id="id" name="id">
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="senha-alterar">Nova senha</label>
                            <input type="password" class="form-control" id="senha-alterar" name="senha">
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="senhaConfirmacao-alterar">Confirme sua nova senha</label>
                            <input type="password" class="form-control" id="senhaConfirmacao-alterar" name="senhaConfirmacao">
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <button type="submit" id="" class="btn btn-default">Salvar</button>
                            <button type="reset" class="btn btn-default ml-15">Cancelar</button>
                        </div>
                    </div>
                    
                </form>
            </div>
        
        </div>
    </div>
</div>
<!-- /.panel -->
*/ ?>