<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

#echo "<pre>"; print_r($dados); exit;

?>

<div class="row">
    
    <div class="col-lg-12">
        
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th title="">ID</th>
                        <th title="">Nome</th>
                        <th title="">Descrição</th>
                        <th title="">Data Início</th>
                        <th title="">Data Fim</th>
                        <th title="">Estabelecimento</th>
                        <th title="">Status</th>
                        <th title="">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $aux = 0;
                    foreach( $dados as $objeto ){
                        $aux++;
                    ?>
                    <tr data-registro="<?=$objeto->getId();?>">
                        <td>
                            <?=$objeto->getId();?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getNome());?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getDescricao());?>
                        </td>
                        <td>
                            <?=Functions::formatarDateTime($objeto->getDataInicio())->date;?>
                        </td>
                        <td>
                            <?=Functions::formatarDateTime($objeto->getDataFim())->date;?>
                        </td>
                        <td>
                            <?=$objeto->getEstabelecimento() ? Functions::printHtml($objeto->getEstabelecimento()->getNome()) : "<em>NULL</em>";?>
                        </td>
                        <td>
                            <?=$objeto->getStatus() == 1 ? "Ativo" : "Inativo";?>
                        </td>
                        <td>
                            <a href="?pagina=<?=$_GET["pagina"];?>&acao=editar&id=<?=$objeto->getId();?>">
                                <i class="fa fa-pencil-square-o"></i>
                            </a>
                            <a href="javascript:void(0)" data-remove="<?=$objeto->getId();?>"> <i class="fa fa-times"></i> </a>
                        </td>
                    </tr>
                    <?php 
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <!-- Modal -->
        <div class="modal fade" id="excluirModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <input type="hidden" id="id" value="" />
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Excluir Registro</h4>
                    </div>
                    <div class="modal-body">
                        Deseja mesmo excluir este registro?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" onclick="campanhaExcluiDados()" data-dismiss="modal">Sim</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Não</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        
    </div>
    <!-- /.col-lg-12 -->
    
</div>
<!-- /.row -->
