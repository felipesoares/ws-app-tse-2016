<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

$atualizar = ( isset($_GET["id"][0]) );
$inserir   = ( !$atualizar );

#echo "<pre>"; print_r($dados); exit;

?>

<div class="panel panel-default">
    <div class="panel-heading">
        Detalhe Agendamento
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form" id="formulario" method="post" action="/ajax/agendamento-salva-dados.php">
                    <input type="hidden" value="<?= $atualizar ? $_GET["id"] : "";?>" id="id" name="id">
                    
                    <?php
                    if( $inserir && !$ACESSO->isDoador() ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="pessoaId">Doador*</label>
                            <select class="form-control" id="pessoaId" name="pessoaId">
                                <option value="">Selecione o Doador</option>
                                <?php 
                                foreach( $dados["pessoa"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>">
                                    <?=$objeto->getNome();?>
                                </option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <?php
                    }
                    ?>
                    
                    <?php
                    if( $atualizar ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="disabledInput">Doador</label>
                            <input type="text" class="form-control" id="disabledInput" value="<?= $atualizar ? $dados[0]->getPessoa()->getNome() : "";?>" disabled>
                        </div>
                    </div>
                    <?php }?>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="motivoDoacaoId">Motivo da Doação*</label>
                            <select class="form-control" id="motivoDoacaoId" name="motivoDoacaoId">
                                <option value="">Selecione o Motivo da Doação</option>
                                <?php 
                                foreach( $dados["motivoDoacao"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getMotivoDoacao()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="estabelecimentoId">Unidade*</label>
                            <select class="form-control" id="estabelecimentoId" name="estabelecimentoId">
                                <option value="">Selecione a Unidade</option>
                                <?php 
                                foreach( $dados["estabelecimento"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getEstabelecimento()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="campanhaId">Campanha</label>
                            <select class="form-control" id="campanhaId" name="campanhaId">
                                <option value="">Selecione a Campanha</option>
                                <?php 
                                foreach( $dados["campanha"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getCampanha()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="data">Data*</label>
                            <div class="input-group date">
                                <input type="text" class="form-control datepicker-util-d1" id="data" name="data" value="<?= $atualizar ? Functions::formatarDateTime($dados[0]->getData())->date : "";?>" placeholder="__/__/____" autocomplete="off" data-mask="data">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="horario">Horário*</label>
                            <select class="form-control" id="horario" name="horario">
                                <?php for($i = 7; $i <= 16; $i++ ){
                                    $valor = str_pad($i, 2, "0", STR_PAD_LEFT);
                                ?>
                                <option value="<?=$valor?>:00:00" <?=($atualizar) && $valor == substr($_REQUEST["dados"][0]->getHorario(), 0, 2) ? "selected" : "";?>>
                                    <?=$valor?>:00
                                </option>
                                <?php
                                }?>
                            </select>
                        </div>
                    </div>
                    
                    <?php if( !$ACESSO->isDoador() ) {?>
                    <div class="col-sm-12">
                        <h3>Status</h3>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="status">Status*</label>
                            <select class="form-control" id="status" name="status">
                                <option value="1" <?=($atualizar && $_REQUEST["dados"][0]->getStatus() == 1) ? "selected" : "";?> >Ativo</option>
                                <option value="2" <?=($atualizar && $_REQUEST["dados"][0]->getStatus() == 2) ? "selected" : "";?> >Inativo</option>
                            </select>
                        </div>
                    </div>
                    <?php }else{?>
                    <input type="hidden" value="1" id="status" name="status">
                    <?php }?>
                    
                    <div class="col-sm-12">
                        <br>
                        <div class="form-group">
                            <button type="button" class="btn btn-default" onclick="agendamentoSalvaDados()">Salvar</button>
                            <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                        </div>
                    </div>
                    
                </form>
            </div>
            <!-- /.col-lg-12 (nested) -->
            
        </div>
        <!-- /.row (nested) -->
    </div>
    <!-- /.panel-body -->
</div>
<!-- /.panel -->
