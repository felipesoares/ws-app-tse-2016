<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

#echo "<pre>"; print_r($dados); exit;

?>

<div class="row">
    
    <div class="col-lg-6">
        <div class="form-group">
            <label class="control-label" for="pesquisar-sorologia">Pesquisar registros pelo Id da Sorologia, Id da Bolsa ou Id do Doador</label>
            <input type="text" class="form-control" id="pesquisar-sorologia" placeholder="Digite para pesquisar e tecle enter" autocomplete="off" autofocus>
        </div>
        <div class="form-group">
            <label class="control-label" for="pesquisar-sorologia-nome-doador">Pesquisar registros pelo nome do doador</label>
            <input type="text" class="form-control" id="pesquisar-sorologia-nome-doador" placeholder="Digite para pesquisar e tecle enter" autocomplete="off" autofocus>
        </div>
        <div class="form-group">
            <label class="control-label" for="data-enter">Pesquisar registros pelas datas de doações</label>
            <div class="input-daterange input-group" id="datepicker">
                <input type="text" class="input-sm form-control datepicker" name="start" id="data-start" data-mask="data" placeholder="__/__/____" />
                <span class="input-group-addon">à</span>
                <input type="text" class="input-sm form-control datepicker" name="end" id="data-end" data-mask="data" placeholder="__/__/____" />
            </div>
            <br />
            <button type="button" class="btn btn-default" id="pesquisar-sorologia-datas-doacoes">Pesquisar datas</button>
            <button type="button" class="btn btn-default" id="limpar-pesquisa" onclick="location.reload();" style="display: none;">Limpar Pesquisa</button>
        </div>
        
    </div>
    
    <div class="col-lg-12">
        
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th title="">ID</th>
                        <th title="">Bolsas</th>
                        <th title="">ID Doador</th>
                        <th title="">Doador</th>
                        <th title="">Data Doação</th>
                        <th title="">Laboratório</th>
                        <th title="">Exames</th>
                        <th title="">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $aux = 0;
                    foreach( $dados as $objeto ){
                        $aux++;
                    ?>
                    <tr data-registro="<?=$objeto->getId();?>">
                        <td>
                            <?=str_pad($objeto->getId(), 4, "0", STR_PAD_LEFT);?>
                        </td>
                        <td>
                            <?php
                                $bolsas = array();
                                foreach( $objeto->getBolsas() as $bolsa ){
                                    $bolsas[] = str_pad($bolsa->getId(), 4, "0", STR_PAD_LEFT);
                                }
                                echo join($bolsas, ", ");
                            ?>
                        </td>
                        <td>
                            <?=$objeto->getBolsas()[0]->getDoacao()->getDoador()->getIdDoador();?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getBolsas()[0]->getDoacao()->getDoador()->getNome());?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getLaboratorio()->getNome());?>
                        </td>
                        <td>
                            <?=Functions::formatarDateTime($objeto->getBolsas()[0]->getDoacao()->getData())->date;?>
                        </td>
                        <td>
                            <a href="?pagina=<?=$_GET["pagina"];?>&acao=editar&id=<?=$objeto->getId();?>">Visualizar Resultados</a>
                        </td>
                        <td>
                            <a href="javascript:void(0)" data-href="?pagina=<?=$_GET["pagina"];?>&acao=editar&id=<?=$objeto->getId();?>">
                                <i class="fa fa-pencil-square-o"></i>
                            </a>
                            <a href="javascript:void(0)" data-remove="<?=$objeto->getId();?>"> <i class="fa fa-times"></i> </a>
                        </td>
                    </tr>
                    <?php 
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <!-- Modal -->
        <div class="modal fade" id="excluirModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <input type="hidden" id="id" value="" />
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Excluir Registro</h4>
                    </div>
                    <div class="modal-body">
                        Deseja mesmo excluir este registro?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" onclick="" data-dismiss="modal">Sim</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Não</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        
    </div>
    <!-- /.col-lg-12 -->
    
</div>
<!-- /.row -->
