<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

#echo "<pre>"; print_r($dados); exit;

?>

<div class="panel panel-default">
    <div class="panel-heading">
        Detalhe Estabelecimento
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form">
                    <input type="hidden" value="" id="id" name="id">
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="codigo">Código*</label>
                            <input type="text" class="form-control" id="codigo" name="codigo" value="" autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="nome">Nome*</label>
                            <input type="text" class="form-control" id="nome" name="nome" value="" autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="cnpj">CNPJ*</label>
                            <input type="text" class="form-control" id="cnpj" name="cnpj" value="" placeholder="__.___.___/____-__" autocomplete="off" data-mask="cnpj">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="estabelecimentoTipoId">Tipo de Estabelecimento*</label>
                            <select class="form-control" id="estabelecimentoTipoId" name="estabelecimentoTipoId">
                                <?php 
                                foreach( $dados["estabelecimentoTipo"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>"><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="estabelecimentoTipoUctId">Tipo de UCT</label>
                            <select class="form-control" id="estabelecimentoTipoUctId" name="estabelecimentoTipoUctId">
                                <option value="">Selecione o Tipo de Unidade</option>
                                <?php 
                                foreach( $dados["estabelecimentoTipoUct"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>"><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="telefone">Telefone*</label>
                            <input type="tel" class="form-control" id="telefone" name="telefone" value="" placeholder="" autocomplete="off" data-mask="telefone">
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <h3>Endereço</h3>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="cep">CEP*</label>
                            <input type="text" class="form-control" id="cep" name="cep" value="" autocomplete="off" placeholder="__.___-___" data-mask="cep">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="estado">Estado*</label>
                            <select class="form-control" id="estado">
                                <option value="">Selecione o Estado</option>
                                <?php 
                                foreach( $dados["estado"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getSigla();?>"><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="cidadeId">Cidade*</label>
                            <select class="form-control" id="cidadeId" name="cidadeId">
                                <option value="">Selecione a Cidade</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-8">
                        <div class="form-group">
                            <label class="control-label" for="logradouro">Logradouro*</label>
                            <input type="tel" class="form-control" id="logradouro" name="logradouro" value="" placeholder="Endereço" autocomplete="off">
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="control-label" for="numero">Número*</label>
                            <input type="tel" class="form-control" id="numero" name="numero" value="" autocomplete="off">
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="complemento">Complemento</label>
                            <input type="tel" class="form-control" id="complemento" name="complemento" value="" placeholder="" autocomplete="off">
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="bairro">Bairro*</label>
                            <input type="tel" class="form-control" id="bairro" name="bairro" value="" autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <br>
                        <div class="form-group">
                            <button type="button" class="btn btn-default" onclick="">Salvar</button>
                            <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                        </div>
                    </div>
                    
                </form>
            </div>
            <!-- /.col-lg-12 (nested) -->
            
        </div>
        <!-- /.row (nested) -->
    </div>
    <!-- /.panel-body -->
</div>
<!-- /.panel -->
