<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

#echo "<pre>"; print_r($dados); exit;

?>

<div class="row">
    
    <div class="col-lg-12">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th title="">ID</th>
                        <th title="">Código</th>
                        <th title="">Nome</th>
                        <th title="">CNPJ</th>
                        <th title="">Tipo Estabelecimento</th>
                        <th title="">Telefone</th>
                        <th title="">Endereço</th>
                        <th title="">Bairro</th>
                        <th title="">Cidade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $aux = 0;
                    foreach( $dados as $objeto ){
                        $aux++;
                    ?>
                    <tr>
                        <td>
                            <?=$objeto->getId();?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getCodigo());?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getNome());?>
                        </td>
                        <td>
                            <?=Functions::maskCNPJ($objeto->getCnpj());?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getEstabelecimentoTipo()->getNome());?>
                            <?=$objeto->getEstabelecimentoTipo()->getId() == 1 ? ' - ' . Functions::printHtml($objeto->getEstabelecimentoTipoUct()->getNome()) : ''; ?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getTelefone());?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getEndereco()->getLogradouro()) . " - " . Functions::printHtml($objeto->getEndereco()->getNumero());?>
                        </td>
                        <td>
                            <?=Functions::printHtml($objeto->getEndereco()->getBairro());?>
                        </td>
                        <td>
                            <?=$objeto->getEndereco()->getCidade()->getNome();?>
                        </td>
                    </tr>
                    <?php 
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.col-lg-12 -->
    
</div>
<!-- /.row -->