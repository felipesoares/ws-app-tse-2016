<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

$atualizar = ( isset($_GET["id"][0]) );
$inserir   = ( !$atualizar );

#echo "<pre>"; print_r($dados); exit;

?>

<div class="panel panel-default">
    <div class="panel-heading">
        Detalhe Funcionário
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form" id="formulario" method="post" action="/ajax/funcionario-salva-dados.php">
                    <input type="hidden" value="<?= $atualizar ? $_GET["id"] : "";?>" id="id" name="id">
                    
                    <?php
                    if( $inserir ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="pessoaId">Funcionário</label>
                            <select class="form-control" id="pessoaId" name="pessoaId">
                                <option value="">Selecione o Funcionário</option>
                                <?php 
                                foreach( $dados["pessoa"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>">
                                    <?=$objeto->getNome();?>
                                </option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <?php }?>
                    
                    <?php
                    if( $atualizar ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="disabledInput">Funcionário</label>
                            <input type="text" class="form-control" id="disabledInput" value="<?= $atualizar ? $dados[0]->getNome() : "";?>" disabled>
                        </div>
                    </div>
                    <?php }?>
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="control-label" for="matricula">Matrícula*</label>
                            <input type="text" class="form-control" id="matricula" name="matricula" value="<?= $atualizar ? $dados[0]->getMatricula() : "";?>" autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="control-label" for="dataAdmissao">Data de Admissão*</label>
                            <div class="input-group date">
                                <input type="text" class="form-control datepicker-d0" id="dataAdmissao" name="dataAdmissao" value="<?= $atualizar ? Functions::formatarDateTime($dados[0]->getDataAdmissao())->date : "";?>" placeholder="__/__/____" autocomplete="off" data-mask="data">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="control-label" for="salario">Salário*</label>
                            
                            <div class="form-group input-group">
                                <span class="input-group-addon">$</span>
                                <input type="text" class="form-control" id="salario" name="salario" value="<?= $atualizar ? Functions::formatarDecimaisView($dados[0]->getSalario()) : "";?>" autocomplete="off" data-mask="money">
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="cargoId">Cargo*</label>
                            <select class="form-control" id="cargoId" name="cargoId">
                                <option value="">Selecione o Cargo</option>
                                <?php 
                                foreach( $dados["cargo"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getCargo()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="registroProfissional">Registro Profissional</label>
                            <input type="text" class="form-control" id="registroProfissional" name="registroProfissional" value="<?= $atualizar ? $dados[0]->getRegistroProfissional() : "";?>" autocomplete="off">
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <br>
                        <div class="form-group">
                            <label class="control-label" for="estabelecimentoId">Estabelecimento alocado*</label>
                            <select class="form-control" id="estabelecimentoId" name="estabelecimentoId">
                                <option value="">Selecione o Estabelecimento</option>
                                <?php 
                                foreach( $dados["estabelecimento"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getEstabelecimento()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <h3>Status</h3>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="status">Status*</label>
                            <select class="form-control" id="status" name="status">
                                <option value="1" <?=($atualizar && $_REQUEST["dados"][0]->getStatusFuncionario() == 1) ? "selected" : "";?> >Ativo</option>
                                <option value="2" <?=($atualizar && $_REQUEST["dados"][0]->getStatusFuncionario() == 2) ? "selected" : "";?> >Inativo</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <br>
                        <div class="form-group">
                            <button type="button" class="btn btn-default" onclick="funcionarioSalvaDados()">Salvar</button>
                            <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                        </div>
                    </div>
                    
                </form>
            </div>
            <!-- /.col-lg-12 (nested) -->
            
        </div>
        <!-- /.row (nested) -->
    </div>
    <!-- /.panel-body -->
</div>
<!-- /.panel -->
