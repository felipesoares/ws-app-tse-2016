<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

$atualizar = ( isset($_GET["id"][0]) );
$inserir   = ( !$atualizar );

#echo "<pre>"; print_r($dados); exit;

?>

<div class="panel panel-default">
    <div class="panel-heading">
        Detalhe Bolsa
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form" id="formulario" method="post" action="/ajax/agendamento-salva-dados.php">
                    <input type="hidden" value="<?= $atualizar ? $_GET["id"] : "";?>" id="id" name="id">
                    
                    <?php
                    if( $inserir && !$ACESSO->isDoador() ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="pessoaId">Doador*</label>
                            <select class="form-control" id="pessoaId" name="pessoaId">
                                <option value="">Selecione o Doador</option>
                                <?php 
                                foreach( $dados["pessoa"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>">
                                    <?=$objeto->getNome();?>
                                </option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <?php
                    }
                    ?>
                    
                    <?php
                    if( $atualizar ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="disabledInput">ID Bolsa</label>
                            <input type="text" class="form-control" id="disabledInput" value="<?= $atualizar ? $_GET["id"] : "";?>" disabled>
                        </div>
                    </div>
                    <?php }?>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="motivoDoacaoId">Doação*</label>
                            <select class="form-control" id="motivoDoacaoId" name="motivoDoacaoId" <?= $atualizar ? "disabled" : "";?>>
                                <option value="">Selecione a Doação</option>
                                <?php 
                                foreach( $dados["doacao"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getDoacao()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getId();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <br>
                        <div class="form-group">
                            <button type="button" class="btn btn-default" onclick="">Salvar</button>
                            <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                        </div>
                    </div>
                    
                </form>
            </div>
            <!-- /.col-lg-12 (nested) -->
            
        </div>
        <!-- /.row (nested) -->
    </div>
    <!-- /.panel-body -->
</div>
<!-- /.panel -->

<?php
if( $atualizar ){
?>
<div class="panel panel-default">
    <div class="panel-heading">
        Rastreabilidade Bolsa
    </div>
    <div class="panel-body">
        <div class="row">

            <div class="col-lg-12">

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th title="">Origem</th>
                                <th title="">Destino</th>
                                <th title="">Data</th>
                                <th title="">Hora</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <?=Functions::printHtml($dados[0]->getDoacao()->getEstabelecimento()->getNome());?>
                                </td>
                                <td>
                                    <?=Functions::printHtml($dados[0]->getDoacao()->getEstabelecimento()->getNome());?>
                                </td>
                                <td>
                                    <?=Functions::formatarDateTime($dados[0]->getDoacao()->getData())->date;?>
                                </td>
                                <td>
                                    <?=substr($dados[0]->getDoacao()->getHorario(), 0, 5);?>
                                </td>
                            </tr>
                            
                            <?php 
                            $ultimaTransferencia = "";
                            
                            if( isset($dados["transferencias"][0]) ){
                                foreach( $dados["transferencias"] as $objeto )
                                {
                                    $ultimaTransferencia = $objeto->getEstabelecimentoDestino()->getNome();
                                ?>
                                <tr>
                                    <td>
                                        <?=Functions::printHtml($objeto->getEstabelecimentoOrigem()->getNome());?>
                                    </td>
                                    <td>
                                        <?=Functions::printHtml($objeto->getEstabelecimentoDestino()->getNome());?>
                                    </td>
                                    <td>
                                        <?=Functions::formatarDateTime($objeto->getData())->date;?>
                                    </td>
                                    <td>
                                        <?=substr($objeto->getHorario(), 0, 5);?>
                                    </td>
                                </tr>
                                <?php 
                                }
                            }?>
                            
                            <?php 
                            if( isset($dados["transfusao"][0]) ){
                                foreach( $dados["transfusao"] as $objeto )
                                {
                                ?>
                                <tr>
                                    <td>
                                        <?=Functions::printHtml($ultimaTransferencia);?>
                                    </td>
                                    <td>
                                        <?=Functions::printHtml($objeto->getReceptor()->getNome());?>
                                    </td>
                                    <td>
                                        <?=Functions::formatarDateTime($objeto->getDateTime())->date;?>
                                    </td>
                                    <td>
                                        <?=substr($objeto->getDateTime(), 11, 5);?>
                                    </td>
                                </tr>
                                <?php 
                                }
                            }?>
                            
                        </tbody>
                    </table>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="excluirModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <input type="hidden" id="id" value="" />
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title" id="myModalLabel">Excluir Registro</h4>
                            </div>
                            <div class="modal-body">
                                Deseja mesmo excluir este registro?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" onclick="" data-dismiss="modal">Sim</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Não</button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>

            </div>
            <!-- /.col-lg-12 -->

        </div>
    </div>
</div>
<!-- /.panel -->
<?php }?>
