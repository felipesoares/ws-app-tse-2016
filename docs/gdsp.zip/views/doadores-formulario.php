<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

$atualizar = ( isset($_GET["id"][0]) );
$inserir   = ( !$atualizar );

#echo "<pre>"; print_r($dados); exit;

?>

<div class="panel panel-default">
    <div class="panel-heading">
        Detalhe Doador
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                <form role="form" id="formulario" method="post" action="/ajax/doador-salva-dados.php">
                    <input type="hidden" value="<?= $atualizar ? $_GET["id"] : "";?>" id="id" name="id">
                    
                    <?php
                    if( $inserir ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="pessoaId">Doador*</label>
                            <select class="form-control" id="pessoaId" name="pessoaId">
                                <option value="">Selecione o Doador</option>
                                <?php 
                                foreach( $dados["pessoa"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>">
                                    <?=$objeto->getNome();?>
                                </option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <?php }?>
                    
                    <?php
                    if( $atualizar ){
                    ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="disabledInput">Doador</label>
                            <input type="text" class="form-control" id="disabledInput" value="<?= $atualizar ? $dados[0]->getNome() : "";?>" disabled>
                        </div>
                    </div>
                    <?php }?>
                    
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label" for="tipoDoadorId">Tipo de Doador*</label>
                            <select class="form-control" id="tipoDoadorId" name="tipoDoadorId">
                                <?php 
                                foreach( $dados["tipoDoador"] as $objeto )
                                {
                                ?>
                                <option value="<?=$objeto->getId();?>" <?=($atualizar && $_REQUEST["dados"][0]->getTipoDoador()->getId() == $objeto->getId()) ? "selected" : "";?> ><?=$objeto->getNome();?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <h3>Status</h3>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label" for="status">Status*</label>
                            <select class="form-control" id="status" name="status">
                                <option value="1" <?=($atualizar && $_REQUEST["dados"][0]->getStatusDoador() == 1) ? "selected" : "";?> >Ativo</option>
                                <option value="2" <?=($atualizar && $_REQUEST["dados"][0]->getStatusDoador() == 2) ? "selected" : "";?> >Inativo</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <br>
                        <div class="form-group">
                            <button type="button" class="btn btn-default" onclick="doadorSalvaDados()">Salvar</button>
                            <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                        </div>
                    </div>
                    
                </form>
            </div>
            <!-- /.col-lg-12 (nested) -->
            
        </div>
        <!-- /.row (nested) -->
    </div>
    <!-- /.panel-body -->
</div>
<!-- /.panel -->
