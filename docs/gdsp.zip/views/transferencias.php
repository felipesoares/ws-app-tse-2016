<?php

#$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

#echo "<pre>"; print_r($dados); exit;

?>

<div class="row">
    
    <div class="col-lg-12">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th title="">ID</th>
                        <th title="">Bolsa de Sangue</th>
                        <th title="">Unidade Origem</th>
                        <th title="">Unidade Destino</th>
                        <th title="">Data</th>
                        <th title="">Horário</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $aux = 0;
                    while( $aux < 5 ){
                        $aux++;
                    ?>
                    <tr>
                        <td>
                            <?=$aux;?>
                        </td>
                        <td>
                            Bolsa 000<?=$aux;?>
                        </td>
                        <td>
                            Lorem Ipsum
                        </td>
                        <td>
                            Lorem Ipsum
                        </td>
                        <td>
                            <?=date("d/m/y");?>
                        </td>
                        <td>
                            <?=date("H:i");?>
                        </td>
                    </tr>
                    <?php 
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.col-lg-12 -->
    
</div>
<!-- /.row -->