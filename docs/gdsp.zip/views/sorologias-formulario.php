<?php

$dados = $_REQUEST["dados"]  ? $_REQUEST["dados"]  : array();

$atualizar = ( isset($_GET["id"][0]) );
$inserir   = ( !$atualizar );

#echo "<pre>"; print_r($dados); exit;

?>

<?php
if( $atualizar ){
?>
<div class="panel panel-default">
    <div class="panel-heading">
        Resultado dos Exames
    </div>
    <div class="panel-body">
        <div class="row">
            
            <div class="col-lg-12">
                
                <?php
                if( $atualizar ){
                ?>
                <div class="col-sm-12">
                    <div class="form-group">
                        <label class="control-label" for="disabledInput">ID Sorologia</label>
                        <input type="text" class="form-control" id="disabledInput" value="<?= $atualizar ? str_pad($_GET["id"], 4, "0", STR_PAD_LEFT) : "";?>" disabled>
                    </div>
                </div>
                <?php }?>
                
                <?php 
                foreach( $dados[0]->getResultadosExames() as $objeto )
                {
                ?>
                <div class="col-sm-12">
                    <div class="form-group">
                        <label><?=Functions::printHtml($objeto->getTipoExame()->getNome());?></label>
                        <!--
                        <p class="form-control-static"></p>
                        -->
                        <textarea class="form-control" rows="7" readonly><?=Functions::printHtml($objeto->getDescricao());?></textarea>
                    </div>
                </div>
                <?php 
                }?>
                
                <div class="col-sm-12">
                    <div class="form-group">
                        <button id="" class="btn btn-default" onclick="window.print(); return false;">Baixar PDF</button>
                        <a href="?pagina=<?=$_GET["pagina"];?>" class="btn btn-default ml-15">Cancelar</a>
                    </div>
                </div>
                
            </div>
        
        </div>
    </div>
</div>
<!-- /.panel -->
<?php }?>
