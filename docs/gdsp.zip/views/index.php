<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?=$seo[$pg]["title"];?> :: GDSP</title>
    
    <link rel="icon" href="/views/assets/img/favicon-black-white.png">
    <link rel="icon" href="/views/assets/img/favicon-black-white.png" sizes="64x64">
    
    <!-- Bootstrap Core CSS -->
    <link href="/views/sb-admin-2/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="/views/sb-admin-2/bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/views/sb-admin-2/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="/views/sb-admin-2/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- fakeLoader.js -->
    <link href="/views/lib/js/fakeLoader.js-master/fakeLoader.css" rel="stylesheet">
    
    <!-- toastr -->
    <link href="/views/lib/js/CodeSeven-toastr-8bbd8db/build/toastr.min.css" rel="stylesheet">
    
    <!-- bootstrap datepicker -->
    <link href="/views/lib/js/bootstrap-datepicker-1.4.0-dist/css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css">
    
    <!-- style.css -->
    <link href="/views/assets/css/style.css" rel="stylesheet" type="text/css">
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div class="fakeLoader"></div>
    
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                <a class="navbar-brand" href="/" title="Sistema de Gerenciamento de Doação de Sangue e Plaquetas">
                    <img src="/views/assets/img/logo-black-white.png" alt="Logo GDSP" height="25" class="logo-inicio">
                </a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li>
                            <a href="?pagina=pessoas&acao=editar&id=<?=$PESSOA->getId()?>"><i class="fa fa-user fa-fw"></i> Meu Cadastro</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="javascript:void(0)" id="deslogar"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
                
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        <li>
                            <a href="/"><i class="fa fa-home fa-fw"></i> Dashboard</a>
                        </li>
                        
                        <?php if( $ACESSO->isAdmin() ){ ?>
                        
                        <li class="<?=$pg == 'pessoas' ? 'active' : '';?>">
                            <a href="#"><i class="fa fa-group fa-fw"></i> Pessoas<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="?pagina=pessoas">Listar</a>
                                </li>
                                <li>
                                    <a href="?pagina=pessoas&acao=adicionar">Cadastrar</a>
                                </li>
                            </ul>
                        </li>
                        <li class="<?=$pg == 'funcionarios' ? 'active' : '';?>">
                            <a href="#"><i class="fa fa-user-md fa-fw"></i> Funcionários<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="?pagina=funcionarios">Listar</a>
                                </li>
                                <li>
                                    <a href="?pagina=funcionarios&acao=adicionar">Cadastrar</a>
                                </li>
                            </ul>
                        </li>
                        <!--
                        <li class="<?=$pg == 'receptores' ? 'active' : '';?>">
                            <a href="#"><i class="fa fa-group fa-fw"></i> Receptores<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="?pagina=receptores">Listar</a>
                                </li>
                                <li>
                                    <a href="?pagina=receptores&acao=adicionar">Cadastrar</a>
                                </li>
                            </ul>
                        </li>
                        -->
                        <li class="<?=$pg == 'estabelecimentos' ? 'active' : '';?>">
                            <a href="#"><i class="fa fa-hospital-o fa-fw"></i> Estabelecimentos<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="?pagina=estabelecimentos">Listar</a>
                                </li>
                                <li>
                                    <a href="?pagina=estabelecimentos&acao=adicionar">Cadastrar</a>
                                </li>
                            </ul>
                        </li>
                        
                        <?php }?>
                        
                        <?php if( $ACESSO->isAdmin() || $ACESSO->isAtendente() ){ ?>
                        <li class="<?=$pg == 'campanhas' ? 'active' : '';?>">
                            <a href="#"><i class="fa fa-bullhorn fa-fw"></i> Campanhas<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="?pagina=campanhas">Listar</a>
                                </li>
                                <li>
                                    <a href="?pagina=campanhas&acao=adicionar">Cadastrar</a>
                                </li>
                            </ul>
                        </li>
                        <?php }?>
                        
                        <?php if( $ACESSO->isAdmin() || $ACESSO->isDoador() || $ACESSO->isMedico() || $ACESSO->isAtendente() ){ ?>
                        <li class="<?=$pg == 'agendamentos' ? 'active' : '';?>">
                            <a href="#"><i class="fa fa-calendar-o fa-fw"></i> Agendamentos<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="?pagina=agendamentos">Listar</a>
                                </li>
                                <?php if( $ACESSO->isAdmin() || $ACESSO->isDoador() || $ACESSO->isAtendente() ){ ?>
                                <li>
                                    <a href="?pagina=agendamentos&acao=adicionar">Agendar</a>
                                </li>
                                <?php }?>
                            </ul>
                        </li>
                        <?php }?>
                        
                        <?php if( !$ACESSO->isDoador() ){ ?>

                            <?php if( $ACESSO->isAdmin() || $ACESSO->isEnfermeiro() || $ACESSO->isMedico() ){ ?>
                            <li class="<?=$pg == 'triagens' ? 'active' : '';?>">
                                <a href="#"><i class="fa fa-filter fa-fw"></i> Triagens<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="?pagina=triagens">Listar</a>
                                    </li>
                                    <?php if( $ACESSO->isAdmin() || $ACESSO->isMedico() ){ ?>
                                    <li>
                                        <a href="?pagina=triagens&acao=adicionar">Registrar</a>
                                    </li>
                                    <?php }?>
                                </ul>
                            </li>
                            <?php }?>

                            <?php if( $ACESSO->isAdmin() || $ACESSO->isEnfermeiro() ){ ?>
                            <li class="<?=$pg == 'doadores' ? 'active' : '';?>">
                                <a href="#"><i class="fa fa-group fa-fw"></i> Doadores<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="?pagina=doadores">Listar</a>
                                    </li>
                                    <li>
                                        <a href="?pagina=doadores&acao=adicionar">Cadastrar</a>
                                    </li>
                                </ul>
                            </li>
                            <?php }?>
                            
                        <?php }?>
                              
                            <?php if( $ACESSO->isAdmin() || $ACESSO->isDoador() || $ACESSO->isEnfermeiro() || $ACESSO->isLaboratorio() ){ ?>
                            <li class="<?=$pg == 'doacoes' ? 'active' : '';?>">
                                <a href="#"><i class="fa fa-h-square fa-fw"></i> Doações<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="?pagina=doacoes">Listar</a>
                                    </li>
                                    <?php if( $ACESSO->isAdmin() || $ACESSO->isEnfermeiro() ){ ?>
                                    <li>
                                        <a href="?pagina=doacoes&acao=adicionar">Registrar</a>
                                    </li>
                                    <?php }?>
                                </ul>
                            </li>
                            <?php }?>
                        
                        <?php if( !$ACESSO->isDoador() ){ ?>
                            
                            <?php if( $ACESSO->isAdmin() || $ACESSO->isLaboratorio() ){ ?>
                            <li class="<?=$pg == 'bolsas' ? 'active' : '';?>">
                                <a href="#"><i class="fa fa-heart fa-fw"></i> Bolsas de Sangue<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="?pagina=bolsas">Pesquisar</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)">Cadastrar</a>
                                    </li>
                                </ul>
                            </li>
                            
                            <li class="<?=$pg == '' ? 'active' : '';?>">
                                <a href="#"><i class="fa fa-file-pdf-o fa-fw"></i> Tipos de Exames<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="javascript:void(0)">Listar</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)">Cadastrar</a>
                                    </li>
                                </ul>
                            </li>

                            <li class="<?=$pg == 'sorologias' ? 'active' : '';?>">
                                <a href="#"><i class="fa fa-plus-square fa-fw"></i> Sorologias<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="?pagina=sorologias">Pesquisar</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)">Solicitar</a>
                                    </li>
                                </ul>
                            </li>

                            <li class="<?=$pg == 'transferencias' ? 'active' : '';?>">
                                <a href="#"><i class="fa fa-angle-double-right fa-fw"></i> Transferências<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="?pagina=transferencias">Listar</a>
                                    </li>
                                    <li>
                                        <a href="?pagina=transferencias&acao=adicionar">Transferir</a>
                                    </li>
                                </ul>
                            </li>
                            <?php }?>

                        <?php }?>
                        
                        <?php if( $ACESSO->isAdmin() ){ ?>
                            <li class="<?=$pg == 'relatorios' ? 'active' : '';?>">
                                <a href="#"><i class="fa fa-angle-double-right fa-fw"></i> Relatórios<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="?pagina=relatorios">Listar</a>
                                    </li>
                                </ul>
                            </li>
                        <?php }?>
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            <?=$seo[$pg]["h1"];?>
                            <?=!empty($acao) ? "<i class='fa fa-angle-double-right'></i> ". mb_convert_case($acao, MB_CASE_TITLE, "UTF-8") : "";?>
                        </h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                
                <div class="row">
                    <div class="col-lg-12">
                        <?php 
                            
                            $classe = $seo[$pg]["controller"] . "Controller";
                            require_once "classes/controllers/{$classe}.php";
                            
                            $objeto = new $classe();
                            $objeto->$acao();
                            
                        ?>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                    
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="/views/sb-admin-2/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/views/sb-admin-2/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="/views/sb-admin-2/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="/views/sb-admin-2/dist/js/sb-admin-2.js"></script>

    <!-- ajax forms -->
    <script src="/views/lib/js/jquery.form.min.js"></script>
    
    <!-- masked input -->
    <script src="/views/lib/js/jquery.maskedinput.min.js"></script>
    
    <!-- mask Money -->
    <script src="/views/lib/js/plentz-jquery-maskmoney-7ededdc/src/jquery.maskMoney.js"></script>
    
    <!-- fakeLoader.js -->
    <script src="/views/lib/js/fakeLoader.js-master/fakeLoader.js"></script>
    
    <!-- toastr -->
    <script src="/views/lib/js/CodeSeven-toastr-8bbd8db/build/toastr.min.js"></script>
    
    <!-- bootstrap datepicker -->
    <script src="/views/lib/js/bootstrap-datepicker-1.4.0-dist/js/bootstrap-datepicker.min.js"></script>
    <script src="/views/lib/js/bootstrap-datepicker-1.4.0-dist/locales/bootstrap-datepicker.pt-BR.min.js"></script>
    
    <!-- script.js -->
    <script src="/views/assets/js/script.js"></script>
    
    <?php
    if( isset($_SESSION["notice"]["msg"][0]) ){
    ?>
        <script>
            $(document).ready(function(){
               showMessage("<?=Functions::printHtml($_SESSION["notice"]["msg"]);?>", "<?=$_SESSION["notice"]["status"];?>");
            });
        </script>
    <?php
        unset($_SESSION["notice"]);
    }
    ?>
    
</body>

</html>
