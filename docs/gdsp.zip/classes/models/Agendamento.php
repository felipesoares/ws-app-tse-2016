<?php

class Agendamento{
    
    private $id;
    private $pessoa;
    private $motivoDoacao;
    private $estabelecimento;
    private $campanha;
    private $data;
    private $horario;
    private $status;
    
    public function __construct($id = null, $pessoa = null, $motivoDoacao = null, $estabelecimento = null, $campanha = null, $data = null, $horario = null, $status = null) {
        $this->setId($id);
        $this->setPessoa($pessoa);
        $this->setMotivoDoacao($motivoDoacao);
        $this->setEstabelecimento($estabelecimento);
        $this->setCampanha($campanha);
        $this->setData($data);
        $this->setHorario($horario);
        $this->setStatus($status);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setPessoa($dado) {
        $this->pessoa = $dado;
    }
    public function getPessoa() {
        return $this->pessoa;
    }
    
    public function setMotivoDoacao($dado) {
        $this->motivoDoacao = $dado;
    }
    public function getMotivoDoacao() {
        return $this->motivoDoacao;
    }
    
    public function setEstabelecimento($dado) {
        $this->estabelecimento = $dado;
    }
    public function getEstabelecimento() {
        return $this->estabelecimento;
    }
    
    public function setCampanha($dado) {
        $this->campanha = $dado;
    }
    public function getCampanha() {
        return $this->campanha;
    }
    
    public function setData($dado) {
        $this->data = $dado;
    }
    public function getData() {
        return $this->data;
    }
    
    public function setHorario($dado) {
        $this->horario = $dado;
    }
    public function getHorario() {
        return $this->horario;
    }
    
    public function setStatus($dado) {
        $this->status = $dado;
    }
    public function getStatus() {
        return $this->status;
    }
    
}