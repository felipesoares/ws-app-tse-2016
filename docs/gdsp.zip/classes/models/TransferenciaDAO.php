<?php

require_once "Transferencia.php";
require_once "BolsaDAO.php";
require_once "EstabelecimentoDAO.php";

class TransferenciaDAO {
    
    private static $DB;
    private static $tabela = "transferencias";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "t.id ASC", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector t.id = {$id}";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT t.* FROM " . self::$tabela . " AS t {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        $rs = $rs ? $rs : array();
        
        $dados = array();
        
        $bolsaDAO = new BolsaDAO();
        $estabelecimentoDAO = new EstabelecimentoDAO();
        
        foreach ($rs as $row) {
            
            $bolsa = $bolsaDAO->listar($row["bolsa_id"]);
            $bolsa = $bolsa[0];
            
            $estabelecimentoOrigem = $estabelecimentoDAO->listar($row["estabelecimento_origem_id"]);
            $estabelecimentoOrigem = $estabelecimentoOrigem[0];
            
            $estabelecimentoDestino = $estabelecimentoDAO->listar($row["estabelecimento_destino_id"]);
            $estabelecimentoDestino = $estabelecimentoDestino[0];
            
            $dados[] = new Transferencia($row["id"], $bolsa, $estabelecimentoOrigem, $estabelecimentoDestino, $row["data"], $row["horario"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir( $bolsa ){
        
        global $SESSION;
        
        $dataCriacao = date ( "Y-m-d H:i:s" );
		$dataUp = date ( "Y-m-d H:i:s" );
		$userCriacao = $SESSION->acessoId();
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
    }
    
    public function atualizar( $bolsa ){
        
        global $SESSION;
        
		$dataUp = date ( "Y-m-d H:i:s" );
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
    }
    
    public function excluir( $id ){
        
        $sql = "DELETE FROM `" . self::$tabela . "` WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $id ) );
        
        return $ok;
    }
    
}