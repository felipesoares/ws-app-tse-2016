<?php

class Doacao{
    
    private $id;
    private $doador;
    private $motivoDoacao;
    private $receptorCpf;
    private $receptorNome;
    private $estabelecimento;
    private $data;
    private $horario;
    private $funcionario;
    
    public function __construct($id = null, $doador = null, $motivoDoacao = null, $receptorCpf = null, $receptorNome = null, $estabelecimento = null, $data = null, $horario = null, $funcionario = null) {
        $this->setId($id);
        $this->setDoador($doador);
        $this->setMotivoDoacao($motivoDoacao);
        $this->setReceptorCpf($receptorCpf);
        $this->setReceptorNome($receptorNome);
        $this->setEstabelecimento($estabelecimento);
        $this->setData($data);
        $this->setHorario($horario);
        $this->setFuncionario($funcionario);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setDoador($dado) {
        $this->doador = $dado;
    }
    public function getDoador() {
        return $this->doador;
    }
    
    public function setMotivoDoacao($dado) {
        $this->motivoDoacao = $dado;
    }
    public function getMotivoDoacao() {
        return $this->motivoDoacao;
    }
    
    public function setReceptorCpf($dado) {
        $this->receptorCpf = $dado;
    }
    public function getReceptorCpf() {
        return $this->receptorCpf;
    }
    
    public function setReceptorNome($dado) {
        $this->receptorNome = $dado;
    }
    public function getReceptorNome() {
        return $this->receptorNome;
    }
    
    public function setEstabelecimento($dado) {
        $this->estabelecimento = $dado;
    }
    public function getEstabelecimento() {
        return $this->estabelecimento;
    }
    
    public function setData($dado) {
        $this->data = $dado;
    }
    public function getData() {
        return $this->data;
    }
    
    public function setHorario($dado) {
        $this->horario = $dado;
    }
    public function getHorario() {
        return $this->horario;
    }
    
    public function setFuncionario($dado) {
        $this->funcionario = $dado;
    }
    public function getFuncionario() {
        return $this->funcionario;
    }
    
}