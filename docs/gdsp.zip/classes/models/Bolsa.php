<?php

class Bolsa{
    
    private $id;
    private $doacao;
    
    public function __construct($id = null, $doacao = null) {
        $this->setId($id);
        $this->setDoacao($doacao);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setDoacao($dado) {
        $this->doacao = $dado;
    }
    public function getDoacao() {
        return $this->doacao;
    }
    
}