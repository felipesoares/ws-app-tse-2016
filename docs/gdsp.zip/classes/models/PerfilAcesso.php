<?php

class PerfilAcesso {
    
    private $id;
    private $nome;
    private $status;
    
    public function __construct($id = null, $nome = null, $status = null) {
        $this->setId($id);
        $this->setNome($nome);
        $this->setStatus($status);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setNome($dado) {
        $this->nome = $dado;
    }
    public function getNome() {
        return $this->nome;
    }
    
    public function setStatus($dado) {
        $this->status = $dado;
    }
    public function getStatus() {
        return $this->status;
    }
    
}