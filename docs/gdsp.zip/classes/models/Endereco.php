<?php

class Endereco {
    
    private $logradouro;
    private $numero;
    private $complemento;
    private $bairro;
    private $cep;
    private $cidade;
    
    public function __construct($logradouro = null, $numero = null, $complemento = null, $bairro = null, $cep = null, $cidade = null) {
        $this->setLogradouro($logradouro);
        $this->setNumero($numero);
        $this->setComplemento($complemento);
        $this->setBairro($bairro);
        $this->setCep($cep);
        $this->setCidade($cidade);
    }
    
    public function setLogradouro($dado) {
        $this->logradouro = $dado;
    }
    public function getLogradouro() {
        return $this->logradouro;
    }
    
    public function setNumero($dado) {
        $this->numero = $dado;
    }
    public function getNumero() {
        return $this->numero;
    }
    
    public function setComplemento($dado) {
        $this->complemento = $dado;
    }
    public function getComplemento() {
        return $this->complemento;
    }
    
    public function setBairro($dado) {
        $this->bairro = $dado;
    }
    public function getBairro() {
        return $this->bairro;
    }
    
    public function setCep($dado) {
        $this->cep = $dado;
    }
    public function getCep() {
        return $this->cep;
    }
    
    public function setCidade($dado) {
        $this->cidade = $dado;
    }
    public function getCidade() {
        return $this->cidade;
    }
    
}