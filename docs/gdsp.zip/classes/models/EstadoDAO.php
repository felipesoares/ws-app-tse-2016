<?php

require_once "Estado.php";

class EstadoDAO {
    
    private static $DB;
    private static $tabela = "estados";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar() {
        
        $query = "SELECT * FROM " . self::$tabela . " ORDER BY nome ASC";
        
        $rs = self::$DB->CacheGetAll($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $dados[] = new Estado($row["nome"], $row["sigla"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
}