<?php

require_once "iCrudDAO.php";

require_once "PerfilAcesso.php";
require_once "Acesso.php";
require_once "Estado.php";
require_once "Cidade.php";
require_once "Endereco.php";
require_once "Pessoa.php";

class PessoaDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "pessoas";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function checharDuplicidade($nomeCampo, $valorCampo, $id = null) {
		
		$condicao = "";
		if ($id) { // editar
			$condicao .= " id != {$id} AND";
		}
		
		$rs = self::$DB->Execute("SELECT {$nomeCampo} FROM " . self::$tabela . " WHERE $condicao $nomeCampo = ?", array($valorCampo));
		return ($rs->RecordCount()) ? true : false;
	}
    
    public function listar($id = null, $where = "", $order_by = "p.id ASC", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector p.id = {$id}";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT p.*, a.email, a.senha, ap.id AS perfilAcessoId, ap.nome AS perfilAcessoNome, ap.status AS perfilAcessoStatus, a.status AS acessoStatus, c.nome AS cidadeNome, e.nome AS estadoNome, e.sigla AS estadoSigla FROM " . self::$tabela . " AS p INNER JOIN acesso AS a ON p.acesso_id = a.id INNER JOIN acesso_perfis AS ap ON a.perfil_acesso_id = ap.id INNER JOIN cidades AS c ON p.cidade_id = c.id INNER JOIN estados AS e ON c.sigla_estado = e.sigla {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $perfilAcesso = new PerfilAcesso($row["perfilAcessoId"], $row["perfilAcessoNome"], $row["perfilAcessoStatus"]);
            
            $acesso = new Acesso($row["acesso_id"], $row["email"], $row["senha"], $perfilAcesso, $row["acessoStatus"]);
            
            $estado = new Estado($row["estadoNome"], $row["estadoSigla"]);
            
            $cidade = new Cidade($row["cidade_id"], $row["cidadeNome"], $estado);
            
            $endereco = new Endereco($row["logradouro"], $row["numero"], $row["complemento"], $row["bairro"], $row["cep"], $cidade);
            
            $dados[] = new Pessoa($row["id"], $row["nome"], $row["cpf"], $row["rg"], $row["data_nascimento"], $row["sexo"], $row["tipo_sanguineo"], $acesso, $row["telefone"], $endereco, $row["status"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir( $pessoa ){
        
        global $SESSION;
        
        $dataCriacao = date ( "Y-m-d H:i:s" );
		$dataUp = date ( "Y-m-d H:i:s" );
		$userCriacao = $SESSION->acessoId() ? $SESSION->acessoId() : 0;
		$userUp = $SESSION->acessoId() ? $SESSION->acessoId() : 0;
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        # campos opcionais
        $complemento = ! empty ( $pessoa->getEndereco()->getComplemento() ) ? $pessoa->getEndereco()->getComplemento() : null;
        $tipoSanguineo = ! empty ( $pessoa->getTipoSanguineo() ) ? $pessoa->getTipoSanguineo() : null;
        
        $sqlPessoas = "INSERT INTO `" . self::$tabela . "`(`nome`, `cpf`, `rg`, `data_nascimento`, `sexo`, `tipo_sanguineo`, `acesso_id`, `telefone`, `cep`, `cidade_id`, `logradouro`, `numero`, `bairro`, `complemento`, `status`, `data_criacao`, `data_up`, `user_criacao`, `user_up`, `browser`, `ip`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
        $sqlAcesso = "INSERT INTO `acesso`(`email`, `senha`, `perfil_acesso_id`, `status`, `data_criacao`, `data_up`, `user_criacao`, `user_up`, `browser`, `ip`) VALUES (?,?,?,?,?,?,?,?,?,?)";
        
        self::$DB->StartTrans();
        
        self::$DB->Execute( $sqlAcesso, array( $pessoa->getAcesso()->getEmail(), md5($pessoa->getAcesso()->getSenha()), $pessoa->getAcesso()->getPerfilAcesso()->getId(), $pessoa->getStatus(), $dataCriacao, $dataUp, $userCriacao, $userUp, $browser, $ip ) );
        
        $acessoId = self::$DB->Insert_ID();
        
        self::$DB->Execute( $sqlPessoas, array( Functions::formatarNome($pessoa->getNome()), Functions::cleanCpf($pessoa->getCpf()), $pessoa->getRg(), Functions::formatarDateTime($pessoa->getDataNascimento(), "en")->date, $pessoa->getSexo(), $tipoSanguineo, $acessoId, $pessoa->getTelefone(), Functions::cleanCep($pessoa->getEndereco()->getCep()), $pessoa->getEndereco()->getCidade()->getId(), $pessoa->getEndereco()->getLogradouro(), $pessoa->getEndereco()->getNumero(), Functions::formatarNome($pessoa->getEndereco()->getBairro()), $complemento, $pessoa->getStatus(), $dataCriacao, $dataUp, $userCriacao, $userUp, $browser, $ip ) );
        
        $insertId = self::$DB->Insert_ID();
        
        $ok = !self::$DB->HasFailedTrans();
        
        self::$DB->CompleteTrans();
        
        return ($ok) ? $insertId : false;
    }
    
    public function atualizar( $pessoa ){
        
        global $SESSION;
        
		$dataUp = date ( "Y-m-d H:i:s" );
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        # campos opcionais
        $complemento = ! empty ( $pessoa->getEndereco()->getComplemento() ) ? $pessoa->getEndereco()->getComplemento() : null;
        $tipoSanguineo = ! empty ( $pessoa->getTipoSanguineo() ) ? $pessoa->getTipoSanguineo() : null;
        
        $sql = "UPDATE `" . self::$tabela . "` SET `nome`=?,`cpf`=?,`rg`=?,`data_nascimento`=?,`sexo`=?,`tipo_sanguineo`=?,`telefone`=?,`cep`=?,`cidade_id`=?,`logradouro`=?,`numero`=?,`bairro`=?,`complemento`=?,`status`=?,`data_up`=?,`user_up`=?,`browser`=?,`ip`=? WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( Functions::formatarNome($pessoa->getNome()), Functions::cleanCpf($pessoa->getCpf()), $pessoa->getRg(), Functions::formatarDateTime($pessoa->getDataNascimento(), "en")->date, $pessoa->getSexo(), $tipoSanguineo, $pessoa->getTelefone(), Functions::cleanCep($pessoa->getEndereco()->getCep()), $pessoa->getEndereco()->getCidade()->getId(), $pessoa->getEndereco()->getLogradouro(), $pessoa->getEndereco()->getNumero(), Functions::formatarNome($pessoa->getEndereco()->getBairro()), $complemento, $pessoa->getStatus(), $dataUp, $userUp, $browser, $ip, $pessoa->getId() ) );
        
        return $ok;
        
    }
    
    public function excluir( $id ){
        
        $sql = "DELETE FROM `" . self::$tabela . "` WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $id ) );
        
        return $ok;
    }
    
}