<?php

require_once "Acesso.php";
require_once "PerfilAcesso.php";

class AcessoDAO {
    
    private static $DB;
    private static $tabela = "acesso";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function autenticar($login, $senha) {
        
        $id = self::$DB->GetOne( "SELECT a.id FROM " . self::$tabela . " AS a INNER JOIN pessoas AS p ON a.id = p.acesso_id WHERE (p.cpf = ? OR a.email = ?) AND a.senha = md5(?) AND a.status = 1 AND p.status = 1", array( Functions::cleanCPF($login), $login, $senha ) );
        
        if ($id) {
            return $id;
        }
        return false;
        
    }
    
    public function checharDuplicidade($nomeCampo, $valorCampo, $id = null) {
		
		$condicao = "";
		if ($id) { // editar
			$condicao .= " id != {$id} AND";
		}
		
		$rs = self::$DB->Execute("SELECT {$nomeCampo} FROM " . self::$tabela . " WHERE $condicao $nomeCampo = ?", array($valorCampo));
		return ($rs->RecordCount()) ? true : false;
	}
    
    public function listar($id = null, $where = "", $order_by = "a.email ASC", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector a.id = {$id}";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT a.*, ap.nome AS perfilAcessoNome, ap.status AS perfilAcessoStatus FROM " . self::$tabela . " AS a INNER JOIN acesso_perfis AS ap ON a.perfil_acesso_id = ap.id {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $perfilAcesso = new PerfilAcesso($row["perfil_acesso_id"], $row["perfilAcessoNome"], $row["perfilAcessoStatus"]);
            
            $dados[] = new Acesso($row["id"], $row["email"], $row["senha"], $perfilAcesso, $row["status"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
}