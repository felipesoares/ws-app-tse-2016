<?php

require_once "iCrudDAO.php";

require_once "PerfilAcesso.php";

class PerfilAcessoDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "acesso_perfis";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "", $limit = "") {
        
        $query = "SELECT * FROM " . self::$tabela . " ORDER BY nome ASC";
        
        $rs = self::$DB->CacheGetAll($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $dados[] = new PerfilAcesso($row["id"], $row["nome"], $row["status"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir($objeto){}
    public function atualizar($objeto){}
    public function excluir($id){}
    
}