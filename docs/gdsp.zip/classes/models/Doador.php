<?php

require_once "Pessoa.php";

class Doador extends Pessoa {
    
    private $idDoador;
    private $tipoDoador;
    private $statusDoador;
    
    public function __construct($id = null, $nome = null, $cpf = null, $rg = null, $dataNascimento = null, $sexo = null, $tipoSanguineo = null, $acesso = null, $telefone = null, $endereco = null, $status = null, $idDoador = null, $tipoDoador = null, $statusDoador = null) {
        parent::__construct($id, $nome, $cpf, $rg, $dataNascimento, $sexo, $tipoSanguineo, $acesso, $telefone, $endereco, $status);
        $this->setIdDoador($idDoador);
        $this->setTipoDoador($tipoDoador);
        $this->setStatusDoador($statusDoador);
    }
    
    public function setIdDoador($dado) {
        $this->idDoador = $dado;
    }
    public function getIdDoador() {
        return $this->idDoador;
    }
    
    public function setTipoDoador($dado) {
        $this->tipoDoador = $dado;
    }
    public function getTipoDoador() {
        return $this->tipoDoador;
    }
    
    public function setStatusDoador($dado) {
        $this->statusDoador = $dado;
    }
    public function getStatusDoador() {
        return $this->statusDoador;
    }
    
}