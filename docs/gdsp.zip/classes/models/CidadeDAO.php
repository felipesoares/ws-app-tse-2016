<?php

require_once "Cidade.php";
require_once "Estado.php";

class CidadeDAO {
    
    private static $DB;
    private static $tabela = "cidades";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "c.nome ASC", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector {$this->tabela}.id = {$id}";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT c.*, e.nome AS nomeEstado FROM " . self::$tabela . " AS c INNER JOIN estados AS e ON c.sigla_estado = e.sigla {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->CacheGetAll($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $estado = new Estado($row["nomeEstado"], $row["sigla_estado"]);
            
            $dados[] = new Cidade($row["id"], $row["nome"], $estado);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
}