<?php

class Estabelecimento {
    
    private $id;
    private $codigo;
    private $nome;
    private $cnpj;
    private $estabelecimentoTipo;
    private $estabelecimentoTipoUct;
    private $telefone;
    private $endereco;
    private $status;
    
    public function __construct($id = null, $codigo = null, $nome = null, $cnpj = null, $estabelecimentoTipo = null, $estabelecimentoTipoUct = null, $telefone = null, $endereco = null, $status = null) {
        $this->setId($id);
        $this->setCodigo($codigo);
        $this->setNome($nome);
        $this->setCnpj($cnpj);
        $this->setEstabelecimentoTipo($estabelecimentoTipo);
        $this->setEstabelecimentoTipoUct($estabelecimentoTipoUct);
        $this->setTelefone($telefone);
        $this->setEndereco($endereco);
        $this->setStatus($status);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setCodigo($dado) {
        $this->codigo = $dado;
    }
    public function getCodigo() {
        return $this->codigo;
    }
    
    public function setNome($dado) {
        $this->nome = $dado;
    }
    public function getNome() {
        return $this->nome;
    }
    
    public function setCnpj($dado) {
        $this->cnpj = $dado;
    }
    public function getCnpj() {
        return $this->cnpj;
    }
    
    public function setEstabelecimentoTipo($dado) {
        $this->estabelecimentoTipo = $dado;
    }
    public function getEstabelecimentoTipo() {
        return $this->estabelecimentoTipo;
    }
    
    public function setEstabelecimentoTipoUct($dado) {
        $this->estabelecimentoTipoUct = $dado;
    }
    public function getEstabelecimentoTipoUct() {
        return $this->estabelecimentoTipoUct;
    }
    
    public function setTelefone($dado) {
        $this->telefone = $dado;
    }
    public function getTelefone() {
        return $this->telefone;
    }
    
    public function setEndereco($dado) {
        $this->endereco = $dado;
    }
    public function getEndereco() {
        return $this->endereco;
    }
    
    public function setStatus($dado) {
        $this->status = $dado;
    }
    public function getStatus() {
        return $this->status;
    }
    
}