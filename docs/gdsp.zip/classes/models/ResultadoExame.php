<?php

class ResultadoExame {
    
    private $id;
    private $sorologia;
    private $tipoExame;
    private $descricao;
    private $anexo;
    
    public function __construct($id = null, $sorologia = null, $tipoExame = null, $descricao = null, $anexo = null) {
        $this->setId($id);
        $this->setSorologia($sorologia);
        $this->setTipoExame($tipoExame);
        $this->setDescricao($descricao);
        $this->setAnexo($anexo);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setSorologia($dado) {
        $this->sorologia = $dado;
    }
    public function getSorologia() {
        return $this->sorologia;
    }
    
    public function setTipoExame($dado) {
        $this->tipoExame = $dado;
    }
    public function getTipoExame() {
        return $this->tipoExame;
    }
    
    public function setDescricao($dado) {
        $this->descricao = $dado;
    }
    public function getDescricao() {
        return $this->descricao;
    }
    
    public function setAnexo($dado) {
        $this->anexo = $dado;
    }
    public function getAnexo() {
        return $this->anexo;
    }
    
}