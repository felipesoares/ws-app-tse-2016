<?php

class Transferencia {
    
    private $id;
    private $bolsa;
    private $estabelecimentoOrigem;
    private $estabelecimentoDestino;
    private $data;
    private $horario;
    
    public function __construct($id = null, $bolsa = null, $estabelecimentoOrigem = null, $estabelecimentoDestino = null, $data = null, $horario = null) {
        $this->setId($id);
        $this->setBolsa($bolsa);
        $this->setEstabelecimentoOrigem($estabelecimentoOrigem);
        $this->setEstabelecimentoDestino($estabelecimentoDestino);
        $this->setData($data);
        $this->setHorario($horario);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setBolsa($dado) {
        $this->bolsa = $dado;
    }
    public function getBolsa() {
        return $this->bolsa;
    }
    
    public function setEstabelecimentoOrigem($dado) {
        $this->estabelecimentoOrigem = $dado;
    }
    public function getEstabelecimentoOrigem() {
        return $this->estabelecimentoOrigem;
    }
    
    public function setEstabelecimentoDestino($dado) {
        $this->estabelecimentoDestino = $dado;
    }
    public function getEstabelecimentoDestino() {
        return $this->estabelecimentoDestino;
    }
    
    public function setData($dado) {
        $this->data = $dado;
    }
    public function getData() {
        return $this->data;
    }
    
    public function setHorario($dado) {
        $this->horario = $dado;
    }
    public function getHorario() {
        return $this->horario;
    }
    
}