<?php

require_once "iCrudDAO.php";

require_once "Triagem.php";
require_once "PessoaDAO.php";
require_once "FuncionarioDAO.php";

class TriagemDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "triagens";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function checharDuplicidade($nomeCampo, $valorCampo, $id = null) {
		
		$condicao = "";
		if ($id) { // editar
			$condicao .= " id != {$id} AND";
		}
		
		$rs = self::$DB->Execute("SELECT {$nomeCampo} FROM " . self::$tabela . " WHERE $condicao $nomeCampo = ?", array($valorCampo));
		return ($rs->RecordCount()) ? true : false;
	}
    
    public function listar($id = null, $where = "", $order_by = "p.nome ASC", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector t.id = {$id}";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT t.* FROM " . self::$tabela . " AS t INNER JOIN pessoas AS p ON t.pessoa_id = p.id {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $pessoa = new PessoaDAO();
            $pessoa = $pessoa->listar($row["pessoa_id"]);
            $pessoa = ($pessoa) ? $pessoa[0] : null;
            
            $funcionario = new FuncionarioDAO();
            $funcionario = $funcionario->listar($row["funcionario_id"]);
            $funcionario = ($funcionario) ? $funcionario[0] : null;
            
            $dados[] = new Triagem($row["id"], $pessoa, $funcionario, $row["data"], $row["horario"], $row["q1"], $row["q2"], $row["q3"], $row["q4"], $row["q5"], $row["q6"], $row["q7"], $row["q8"], $row["q9"], $row["q10"], $row["aptidao_ok"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir( $triagem ){
        
        global $SESSION;
        
        $dataCriacao = date ( "Y-m-d H:i:s" );
		$dataUp = date ( "Y-m-d H:i:s" );
		$userCriacao = $SESSION->acessoId();
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        $sql = "INSERT INTO `" . self::$tabela . "`(`pessoa_id`, `funcionario_id`, `data`, `horario`, `q1`, `q2`, `q3`, `q4`, `q5`, `q6`, `q7`, `q8`, `q9`, `q10`, `aptidao_ok`, `data_criacao`, `data_up`, `user_criacao`, `user_up`, `browser`, `ip`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
        $ok = self::$DB->Execute( $sql, array($triagem->getPessoa()->getId(), $triagem->getFuncionario()->getId(), Functions::formatarDateTime($triagem->getData(), "en")->date, $triagem->getHorario(), $triagem->getQ1(), $triagem->getQ2(), $triagem->getQ3(), $triagem->getQ4(), $triagem->getQ5(), $triagem->getQ6(), $triagem->getQ7(), $triagem->getQ8(), $triagem->getQ9(), $triagem->getQ10(), (int)$triagem->getAptidao(), $dataCriacao, $dataUp, $userCriacao, $userUp, $browser, $ip ) );
        
        $insertId = self::$DB->Insert_ID();
        
        return ($ok) ? $insertId : false;
    }
    
    public function atualizar( $triagem ){
        
        global $SESSION;
        
		$dataUp = date ( "Y-m-d H:i:s" );
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        $sql = "UPDATE `" . self::$tabela . "` SET `funcionario_id`=?,`data`=?,`horario`=?,`q1`=?,`q2`=?,`q3`=?,`q4`=?,`q5`=?,`q6`=?,`q7`=?,`q8`=?,`q9`=?,`q10`=?,`aptidao_ok`=?,`data_up`=?,`user_up`=?,`browser`=?,`ip`=? WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $triagem->getFuncionario()->getId(), Functions::formatarDateTime($triagem->getData(), "en")->date, $triagem->getHorario(), $triagem->getQ1(), $triagem->getQ2(), $triagem->getQ3(), $triagem->getQ4(), $triagem->getQ5(), $triagem->getQ6(), $triagem->getQ7(), $triagem->getQ8(), $triagem->getQ9(), $triagem->getQ10(), (int)$triagem->getAptidao(), $dataUp, $userUp, $browser, $ip, $triagem->getId() ) );
        
        return $ok;
        
    }
    
    public function excluir( $id ){
        
        $sql = "DELETE FROM `" . self::$tabela . "` WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $id ) );
        
        return $ok;
    }
    
}