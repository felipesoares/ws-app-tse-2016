<?php

class Receptor {
    
    private $id;
    private $nome;
    private $cpf;
    private $estabelecimento;
    
    public function __construct($id = null, $nome = null, $cpf = null, $estabelecimento = null) {
        $this->setId($id);
        $this->setNome($nome);
        $this->setCpf($cpf);
        $this->setEstabelecimento($estabelecimento);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setNome($dado) {
        $this->nome = $dado;
    }
    public function getNome() {
        return $this->nome;
    }
    
    public function setCpf($dado) {
        $this->cpf = $dado;
    }
    public function getCpf() {
        return $this->cpf;
    }
    
    public function setEstabelecimento($dado) {
        $this->estabelecimento = $dado;
    }
    public function getEstabelecimento() {
        return $this->estabelecimento;
    }
    
}