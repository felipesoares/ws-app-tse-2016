<?php

require_once "iCrudDAO.php";

require_once "EstabelecimentoDAO.php";
require_once "Campanha.php";

class CampanhaDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "campanhas";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function checharDuplicidade($nomeCampo, $valorCampo, $id = null) {
		
		$condicao = "";
		if ($id) { // editar
			$condicao .= " id != {$id} AND";
		}
		
		$rs = self::$DB->Execute("SELECT {$nomeCampo} FROM " . self::$tabela . " WHERE $condicao $nomeCampo = ?", array($valorCampo));
		return ($rs->RecordCount()) ? true : false;
	}
    
    public function listar($id = null, $where = "", $order_by = "c.id ASC", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector c.id = {$id}";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT c.* FROM " . self::$tabela . " AS c {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        
        $dados = array();
        
        $estabelecimentoDAO = new EstabelecimentoDAO();
        
        foreach ($rs as $row) {
            
            if( $row["estabelecimento_id"] ){
                $estabelecimento = $estabelecimentoDAO->listar($row["estabelecimento_id"]);
                $estabelecimento = $estabelecimento[0];
                
            }else{
                $estabelecimento = null;
            }
            
            $dados[] = new Campanha($row["id"], $row["nome"], $row["descricao"], $row["data_inicio"], $row["data_fim"], $estabelecimento, $row["status"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir( $campanha ){
        
        global $SESSION;
        
        $dataCriacao = date ( "Y-m-d H:i:s" );
		$dataUp = date ( "Y-m-d H:i:s" );
		$userCriacao = $SESSION->acessoId();
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        # campos opcionais
        $estabelecimentoId = ! empty ( $campanha->getEstabelecimento()->getId() ) ? $campanha->getEstabelecimento()->getId() : null;
        
        $sql = "INSERT INTO `" . self::$tabela . "`(`nome`, `descricao`, `data_inicio`, `data_fim`, `estabelecimento_id`, `status`, `data_criacao`, `data_up`, `user_criacao`, `user_up`, `browser`, `ip`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        
        $ok = self::$DB->Execute( $sql, array( Functions::formatarNome($campanha->getNome()), $campanha->getDescricao(), Functions::formatarDateTime($campanha->getDataInicio(), "en")->date, Functions::formatarDateTime($campanha->getDataFim(), "en")->date, $estabelecimentoId, $campanha->getStatus(), $dataCriacao, $dataUp, $userCriacao, $userUp, $browser, $ip ) );
        
        $insertId = self::$DB->Insert_ID();
        
        return ($ok) ? $insertId : false;
    }
    
    public function atualizar( $campanha ){
        
        global $SESSION;
        
		$dataUp = date ( "Y-m-d H:i:s" );
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        # campos opcionais
        $estabelecimentoId = ! empty ( $campanha->getEstabelecimento()->getId() ) ? $campanha->getEstabelecimento()->getId() : null;
        
        $sql = "UPDATE `" . self::$tabela . "` SET `nome`=?,`descricao`=?,`data_inicio`=?,`data_fim`=?,`estabelecimento_id`=?,`status`=?,`data_up`=?,`user_up`=?,`browser`=?,`ip`=? WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( Functions::formatarNome($campanha->getNome()), $campanha->getDescricao(), Functions::formatarDateTime($campanha->getDataInicio(), "en")->date, Functions::formatarDateTime($campanha->getDataFim(), "en")->date, $estabelecimentoId, $campanha->getStatus(), $dataUp, $userUp, $browser, $ip, $campanha->getId() ) );
        
        return $ok;
        
    }
    
    public function excluir( $id ){
        
        $sql = "DELETE FROM `" . self::$tabela . "` WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $id ) );
        
        return $ok;
    }
    
}