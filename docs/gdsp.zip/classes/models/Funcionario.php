<?php

require_once "Pessoa.php";

class Funcionario extends Pessoa {
    
    private $idFuncionario;
    private $matricula;
    private $dataAdmissao;
    private $salario;
    private $registroProfissional;
    private $cargo;
    private $estabelecimento;
    private $statusFuncionario;
    
    public function __construct($id = null, $nome = null, $cpf = null, $rg = null, $dataNascimento = null, $sexo = null, $tipoSanguineo = null, $acesso = null, $telefone = null, $endereco = null, $status = null, $idFuncionario = null, $matricula = null, $dataAdmissao = null, $salario = null, $registroProfissional = null, $cargo = null, $estabelecimento = null, $statusFuncionario = null) {
        parent::__construct($id, $nome, $cpf, $rg, $dataNascimento, $sexo, $tipoSanguineo, $acesso, $telefone, $endereco, $status);
        $this->setIdFuncionario($idFuncionario);
        $this->setMatricula($matricula);
        $this->setDataAdmissao($dataAdmissao);
        $this->setSalario($salario);
        $this->setRegistroProfissional($registroProfissional);
        $this->setCargo($cargo);
        $this->setEstabelecimento($estabelecimento);
        $this->setStatusFuncionario($statusFuncionario);
    }
    
    public function setIdFuncionario($dado) {
        $this->idFuncionario = $dado;
    }
    public function getIdFuncionario() {
        return $this->idFuncionario;
    }
    
    public function setMatricula($dado) {
        $this->matricula = $dado;
    }
    public function getMatricula() {
        return $this->matricula;
    }
    
    public function setDataAdmissao($dado) {
        $this->dataAdmissao = $dado;
    }
    public function getDataAdmissao() {
        return $this->dataAdmissao;
    }
    
    public function setSalario($dado) {
        $this->salario = $dado;
    }
    public function getSalario() {
        return $this->salario;
    }
    
    public function setRegistroProfissional($dado) {
        $this->registroProfissional = $dado;
    }
    public function getRegistroProfissional() {
        return $this->registroProfissional;
    }
    
    public function setCargo($dado) {
        $this->cargo = $dado;
    }
    public function getCargo() {
        return $this->cargo;
    }
    
    public function setEstabelecimento($dado) {
        $this->estabelecimento = $dado;
    }
    public function getEstabelecimento() {
        return $this->estabelecimento;
    }
    
    public function setStatusFuncionario($dado) {
        $this->statusFuncionario = $dado;
    }
    public function getStatusFuncionario() {
        return $this->statusFuncionario;
    }
    
}