<?php

require_once "Doacao.php";
require_once "DoadorDAO.php";
require_once "DoacaoMotivoDAO.php";
require_once "EstabelecimentoDAO.php";
require_once "FuncionarioDAO.php";

class DoacaoDAO {
    
    private static $DB;
    private static $tabela = "doacoes";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector d.id = {$id}";
        }
        
        if (empty($order_by)) {
            $order_by = "d.data DESC, d.horario DESC, d.id ASC";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT d.* FROM " . self::$tabela . " AS d INNER JOIN doadores AS dd ON d.doador_id = dd.id {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        $rs = $rs ? $rs : array();
        
        $dados = array();
        
        $doadorDAO = new DoadorDAO();
        $motivoDoacaoDAO = new DoacaoMotivoDAO();
        $estabelecimentoDAO = new EstabelecimentoDAO();
        $funcionarioDAO = new FuncionarioDAO();
        
        foreach ($rs as $row) {
            
            $doador = $doadorDAO->listar($row["doador_id"]);
            $doador = $doador[0];
            
            $motivoDoacao = $motivoDoacaoDAO->listar($row["motivo_doacao_id"]);
            $motivoDoacao = $motivoDoacao[0];
            
            $estabelecimento = $estabelecimentoDAO->listar($row["estabelecimento_id"]);
            $estabelecimento = $estabelecimento[0];
            
            $funcionario = $funcionarioDAO->listar($row["funcionario_id"]);
            $funcionario = $funcionario[0];
            
            $dados[] = new Doacao($row["id"], $doador, $motivoDoacao, $row["receptor_cpf"], $row["receptor_nome"], $estabelecimento, $row["data"], $row["horario"], $funcionario);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir( $bolsa ){
        
        global $SESSION;
        
        $dataCriacao = date ( "Y-m-d H:i:s" );
		$dataUp = date ( "Y-m-d H:i:s" );
		$userCriacao = $SESSION->acessoId();
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
    }
    
    public function atualizar( $bolsa ){
        
        global $SESSION;
        
		$dataUp = date ( "Y-m-d H:i:s" );
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
    }
    
    public function excluir( $id ){
        
        $sql = "DELETE FROM `" . self::$tabela . "` WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $id ) );
        
        return $ok;
    }
    
}