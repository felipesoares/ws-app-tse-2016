<?php

class Sorologia {
    
    private $id;
    private $bolsas;
    private $examesSolicitados;
    private $resultadosExames;
    private $laboratorio;
    private $tipoSanguineo;
    private $liberacao;
    
    public function __construct($id = null, $bolsas = null, $examesSolicitados = null, $resultadosExames = null, $laboratorio = null, $tipoSanguineo = null, $liberacao = null) {
        $this->setId($id);
        $this->setBolsas($bolsas);
        $this->setExamesSolicitados($examesSolicitados);
        $this->setResultadosExames($resultadosExames);
        $this->setLaboratorio($laboratorio);
        $this->setTipoSanguineo($tipoSanguineo);
        $this->setLiberacao($liberacao);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setBolsas($dado) {
        $this->bolsas = $dado;
    }
    public function getBolsas() {
        return $this->bolsas;
    }
    
    public function setExamesSolicitados($dado) {
        $this->examesSolicitados = $dado;
    }
    public function getExamesSolicitados() {
        return $this->examesSolicitados;
    }
    
    public function setResultadosExames($dado) {
        $this->resultadosExames = $dado;
    }
    public function getResultadosExames() {
        return $this->resultadosExames;
    }
    
    public function setLaboratorio($dado) {
        $this->laboratorio = $dado;
    }
    public function getLaboratorio() {
        return $this->laboratorio;
    }
    
    public function setTipoSanguineo($dado) {
        $this->tipoSanguineo = $dado;
    }
    public function getTipoSanguineo() {
        return $this->tipoSanguineo;
    }
    
    public function setLiberacao($dado) {
        $this->liberacao = $dado;
    }
    public function getLiberacao() {
        return $this->liberacao;
    }
    
}