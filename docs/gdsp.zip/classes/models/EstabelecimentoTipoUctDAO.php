<?php

require_once "iCrudDAO.php";

require_once "EstabelecimentoTipoUct.php";

class EstabelecimentoTipoUctDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "estabelecimentos_tipo_uct";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "", $limit = "") {
        
        $query = "SELECT * FROM " . self::$tabela . " ORDER BY id ASC";
        
        $rs = self::$DB->CacheGetAll($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $dados[] = new EstabelecimentoTipoUct($row["id"], $row["nome"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir($objeto){}
    public function atualizar($objeto){}
    public function excluir($id){}
    
}