<?php

class Triagem {
    
    private $id;
    private $pessoa;
    private $funcionario;
    private $data;
    private $horario;
    private $q1;
    private $q2;
    private $q3;
    private $q4;
    private $q5;
    private $q6;
    private $q7;
    private $q8;
    private $q9;
    private $q10;
    private $aptidao;
    
    public function __construct($id = null, $pessoa = null, $funcionario = null, $data = null, $horario = null, $q1 = null, $q2 = null, $q3 = null, $q4 = null, $q5 = null, $q6 = null, $q7 = null, $q8 = null, $q9 = null, $q10 = null, $aptidao = null) {
        $this->setId($id);
        $this->setPessoa($pessoa);
        $this->setFuncionario($funcionario);
        $this->setData($data);
        $this->setHorario($horario);
        $this->setQ1($q1);
        $this->setQ2($q2);
        $this->setQ3($q3);
        $this->setQ4($q4);
        $this->setQ5($q5);
        $this->setQ6($q6);
        $this->setQ7($q7);
        $this->setQ8($q8);
        $this->setQ9($q9);
        $this->setQ10($q10);
        $this->setAptidao($aptidao);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setPessoa($dado) {
        $this->pessoa = $dado;
    }
    public function getPessoa() {
        return $this->pessoa;
    }
    
    public function setFuncionario($dado) {
        $this->funcionario = $dado;
    }
    public function getFuncionario() {
        return $this->funcionario;
    }
    
    public function setData($dado) {
        $this->data = $dado;
    }
    public function getData() {
        return $this->data;
    }
    
    public function setHorario($dado) {
        $this->horario = $dado;
    }
    public function getHorario() {
        return $this->horario;
    }
    
    public function setQ1($dado) {
        $this->q1 = $dado;
    }
    public function getQ1() {
        return $this->q1;
    }
    
    public function setQ2($dado) {
        $this->q2 = $dado;
    }
    public function getQ2() {
        return $this->q2;
    }
    
    public function setQ3($dado) {
        $this->q3 = $dado;
    }
    public function getQ3() {
        return $this->q3;
    }
    
    public function setQ4($dado) {
        $this->q4 = $dado;
    }
    public function getQ4() {
        return $this->q4;
    }
    
    public function setQ5($dado) {
        $this->q5 = $dado;
    }
    public function getQ5() {
        return $this->q5;
    }
    
    public function setQ6($dado) {
        $this->q6 = $dado;
    }
    public function getQ6() {
        return $this->q6;
    }
    
    public function setQ7($dado) {
        $this->q7 = $dado;
    }
    public function getQ7() {
        return $this->q7;
    }
    
    public function setQ8($dado) {
        $this->q8 = $dado;
    }
    public function getQ8() {
        return $this->q8;
    }
    
    public function setQ9($dado) {
        $this->q9 = $dado;
    }
    public function getQ9() {
        return $this->q9;
    }
    
    public function setQ10($dado) {
        $this->q10 = $dado;
    }
    public function getQ10() {
        return $this->q10;
    }
    
    public function setAptidao($dado) {
        $this->aptidao = $dado;
    }
    public function getAptidao() {
        return $this->aptidao;
    }
    
}