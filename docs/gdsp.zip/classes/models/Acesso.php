<?php

class Acesso {
    
    private $id;
    private $email;
    private $senha;
    private $perfilAcesso;
    private $status;
    
    public function __construct($id = null, $email = null, $senha = null, $perfilAcesso = null, $status = null) {
        $this->setId($id);
        $this->setEmail($email);
        $this->setSenha($senha);
        $this->setPerfilAcesso($perfilAcesso);
        $this->setstatus($status);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setEmail($dado) {
        $this->email = $dado;
    }
    public function getEmail() {
        return $this->email;
    }
    
    public function setSenha($dado) {
        $this->senha = $dado;
    }
    public function getSenha() {
        return $this->senha;
    }
    
    public function setPerfilAcesso($dado) {
        $this->perfilAcesso = $dado;
    }
    public function getPerfilAcesso() {
        return $this->perfilAcesso;
    }
    
    public function setStatus($dado) {
        $this->status = $dado;
    }
    public function getStatus() {
        return $this->status;
    }
    
    
    public function isAdmin(){
        return ($this->perfilAcesso->getId() == 1);
    }
    
    public function isDoador(){
        return ($this->perfilAcesso->getId() == 2);
    }
    
    public function isEnfermeiro(){
        return ($this->perfilAcesso->getId() == 3);
    }
    
    public function isMedico(){
        return ($this->perfilAcesso->getId() == 4);
    }
    
    public function isAtendente(){
        return ($this->perfilAcesso->getId() == 5);
    }
    
    public function isSupervisorAdministrativo(){
        return ($this->perfilAcesso->getId() == 6);
    }
    
    public function isSupervisorLogistica(){
        return ($this->perfilAcesso->getId() == 7);
    }
    
    public function isLaboratorio(){
        return ($this->perfilAcesso->getId() == 8);
    }
    
    public function isHospital(){
        return ($this->perfilAcesso->getId() == 9);
    }
    
}