<?php

require_once "iCrudDAO.php";
require_once "Agendamento.php";
require_once "DoacaoMotivo.php";

require_once "PessoaDAO.php";
require_once "EstabelecimentoDAO.php";
require_once "CampanhaDAO.php";

class AgendamentoDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "agendamentos";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function checharDuplicidade($estabelecimentoId, $data, $horario, $id = null) {
		
		$condicao = "";
		if ($id) { // editar
			$condicao .= " id != {$id} AND";
		}
		
		$rs = self::$DB->Execute("SELECT id FROM " . self::$tabela . " WHERE {$condicao} estabelecimento_id = ? AND data = ? AND horario = ?", array($estabelecimentoId, Functions::formatarDateTime($data, "en")->date, $horario));
		return ($rs->RecordCount()) ? true : false;
	}
    
    public function listar($id = null, $where = "", $order_by = "a.data DESC, a.horario ASC, p.nome ASC", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector a.id = {$id}";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT a.*, md.nome AS motivoDoacaoNome FROM " . self::$tabela . " AS a INNER JOIN pessoas AS p ON a.pessoa_id = p.id INNER JOIN motivo_doacao AS md ON a.motivo_doacao_id = md.id {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $objeto = new PessoaDAO();
            $dado = $objeto->listar($row["pessoa_id"]);
            $pessoa = ($dado) ? $dado[0] : null;
            
            $motivoDoacao = new DoacaoMotivo($row["motivo_doacao_id"], $row["motivoDoacaoNome"]);
            
            $objeto = new EstabelecimentoDAO();
            $dado = $objeto->listar($row["estabelecimento_id"]);
            $estabelecimento = ($dado) ? $dado[0] : null;
            
            $objeto = new CampanhaDAO();
            $dado = $row["campanha_id"] ? $objeto->listar($row["campanha_id"]) : null;
            $campanha = ($dado) ? $dado[0] : new Campanha();
            
            $dados[] = new Agendamento($row["id"], $pessoa, $motivoDoacao, $estabelecimento, $campanha, $row["data"], $row["horario"], $row["status"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir( $agendamento ){
        
        global $SESSION;
        
        $dataCriacao = date ( "Y-m-d H:i:s" );
		$dataUp = date ( "Y-m-d H:i:s" );
		$userCriacao = $SESSION->acessoId();
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        # campos opcionais
        $campanha = ! empty ( $agendamento->getCampanha()->getId() ) ? $agendamento->getCampanha()->getId() : null;
        
        $sql = "INSERT INTO `" . self::$tabela . "`(`pessoa_id`, `motivo_doacao_id`, `estabelecimento_id`, `campanha_id`, `data`, `horario`, `status`, `data_criacao`, `data_up`, `user_criacao`, `user_up`, `browser`, `ip`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
        $ok = self::$DB->Execute( $sql, array( $agendamento->getPessoa()->getId(), $agendamento->getMotivoDoacao()->getId(), $agendamento->getEstabelecimento()->getId(), $campanha, Functions::formatarDateTime($agendamento->getData(), "en")->date, $agendamento->getHorario(), $agendamento->getStatus(), $dataCriacao, $dataUp, $userCriacao, $userUp, $browser, $ip ) );
        
        $insertId = self::$DB->Insert_ID();
        
        return ($ok) ? $insertId : false;
    }
    
    public function atualizar( $agendamento ){
        
        global $SESSION;
        
		$dataUp = date ( "Y-m-d H:i:s" );
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        # campos opcionais
        $campanha = ! empty ( $agendamento->getCampanha()->getId() ) ? $agendamento->getCampanha()->getId() : null;
        
        $sql = "UPDATE `" . self::$tabela . "` SET `motivo_doacao_id`=?,`estabelecimento_id`=?,`campanha_id`=?,`data`=?,`horario`=?,`status`=?,`data_up`=?,`user_up`=?,`browser`=?,`ip`=? WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $agendamento->getMotivoDoacao()->getId(), $agendamento->getEstabelecimento()->getId(), $campanha, Functions::formatarDateTime($agendamento->getData(), "en")->date, $agendamento->getHorario(), $agendamento->getStatus(), $dataUp, $userUp, $browser, $ip, $agendamento->getId() ) );
        
        return $ok;
        
    }
    
    public function excluir( $id ){
        
        $sql = "DELETE FROM `" . self::$tabela . "` WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $id ) );
        
        return $ok;
    }
    
}