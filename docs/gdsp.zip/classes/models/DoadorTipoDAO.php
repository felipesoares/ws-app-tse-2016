<?php

require_once "iCrudDAO.php";

require_once "DoadorTipo.php";

class DoadorTipoDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "doadores_tipo";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "", $limit = "") {
        
        $query = "SELECT * FROM " . self::$tabela . " ORDER BY id ASC";
        
        $rs = self::$DB->CacheGetAll($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $dados[] = new DoadorTipo($row["id"], $row["nome"], $row["status"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir($objeto){}
    public function atualizar($objeto){}
    public function excluir($id){}
    
}