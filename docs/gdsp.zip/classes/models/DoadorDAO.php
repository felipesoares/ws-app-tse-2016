<?php

require_once "iCrudDAO.php";

require_once "PessoaDAO.php";
require_once "Doador.php";
require_once "DoadorTipo.php";

class DoadorDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "doadores";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "p.nome ASC", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector d.id = {$id}";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT d.*, dt.nome AS tipoDoadorNome, dt.status AS tipoDoadorStatus FROM " . self::$tabela . " AS d INNER JOIN pessoas AS p ON d.pessoa_id = p.id INNER JOIN doadores_tipo AS dt ON d.tipo_doador_id = dt.id {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $pessoa = new PessoaDAO();
            $pessoa = $pessoa->listar($row["pessoa_id"]);
            $pessoa = ($pessoa) ? $pessoa[0] : null;
            
            $tipoDoador = new DoadorTipo($row["tipo_doador_id"], $row["tipoDoadorNome"], $row["tipoDoadorStatus"]);
            
            $dados[] = new Doador($pessoa->getId(), $pessoa->getNome(), $pessoa->getCpf(), $pessoa->getRg(), $pessoa->getDataNascimento(), $pessoa->getSexo(), $pessoa->getTipoSanguineo(), $pessoa->getAcesso(), $pessoa->getTelefone(), $pessoa->getEndereco(), $pessoa->getStatus(), $row["id"], $tipoDoador, $row["status"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir( $doador ){
        
        global $SESSION;
        
        $dataCriacao = date ( "Y-m-d H:i:s" );
		$dataUp = date ( "Y-m-d H:i:s" );
		$userCriacao = $SESSION->acessoId();
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        $sql = "INSERT INTO `" . self::$tabela . "`(`pessoa_id`, `tipo_doador_id`, `status`, `data_criacao`, `data_up`, `user_criacao`, `user_up`, `browser`, `ip`) VALUES (?,?,?,?,?,?,?,?,?)";
        
        $ok = self::$DB->Execute( $sql, array( $doador->getId(), $doador->getTipoDoador()->getId(), $doador->getStatusDoador(), $dataCriacao, $dataUp, $userCriacao, $userUp, $browser, $ip ) );
        
        $insertId = self::$DB->Insert_ID();
        
        return ($ok) ? $insertId : false;
    }
    
    public function atualizar( $doador ){
        
        global $SESSION;
        
		$dataUp = date ( "Y-m-d H:i:s" );
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        $sql = "UPDATE `" . self::$tabela . "` SET `tipo_doador_id`=?,`status`=?,`data_up`=?,`user_up`=?,`browser`=?,`ip`=? WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $doador->getTipoDoador()->getId(), $doador->getStatusDoador(), $dataUp, $userUp, $browser, $ip, $doador->getIdDoador() ) );
        
        return $ok;
        
    }
    
    public function excluir( $id ){
        
        $sql = "DELETE FROM `" . self::$tabela . "` WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $id ) );
        
        return $ok;
    }
    
}