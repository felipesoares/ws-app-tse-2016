<?php

require_once "iCrudDAO.php";

require_once "Bolsa.php";
require_once "DoacaoDAO.php";

class BolsaDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "bolsas";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector b.id = {$id}";
        }
        
        if (empty($order_by)) {
            $order_by = "b.id ASC";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT b.*, sb.sorologia_id FROM " . self::$tabela . " AS b LEFT JOIN sorologias_bolsas AS sb ON b.id = sb.bolsa_id {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        $rs = $rs ? $rs : array();
        
        $dados = array();
        
        $doacaoDAO = new DoacaoDAO();
        
        foreach ($rs as $row) {
            
            $doacao = $doacaoDAO->listar(null, "d.id = {$row["doacao_id"]}");
            $doacao = $doacao[0];
            
            $dados[] = new Bolsa($row["id"], $doacao);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir( $bolsa ){
        
        global $SESSION;
        
        $dataCriacao = date ( "Y-m-d H:i:s" );
		$dataUp = date ( "Y-m-d H:i:s" );
		$userCriacao = $SESSION->acessoId();
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
    }
    
    public function atualizar( $bolsa ){
        
        global $SESSION;
        
		$dataUp = date ( "Y-m-d H:i:s" );
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
    }
    
    public function excluir( $id ){
        
        $sql = "DELETE FROM `" . self::$tabela . "` WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $id ) );
        
        return $ok;
    }
    
}