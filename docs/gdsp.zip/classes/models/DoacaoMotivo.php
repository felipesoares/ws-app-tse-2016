<?php

class DoacaoMotivo {
    
    private $id;
    private $nome;
    
    public function __construct($id = null, $nome = null) {
        $this->setId($id);
        $this->setNome($nome);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setNome($dado) {
        $this->nome = $dado;
    }
    public function getNome() {
        return $this->nome;
    }
    
}