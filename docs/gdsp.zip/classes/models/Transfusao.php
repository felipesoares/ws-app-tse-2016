<?php

class Transfusao {
    
    private $id;
    private $bolsa;
    private $receptor;
    private $datetime;
    
    public function __construct($id = null, $bolsa = null, $receptor = null, $datetime = null) {
        $this->setId($id);
        $this->setBolsa($bolsa);
        $this->setReceptor($receptor);
        $this->setDatetime($datetime);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setBolsa($dado) {
        $this->bolsa = $dado;
    }
    public function getBolsa() {
        return $this->bolsa;
    }
    
    public function setReceptor($dado) {
        $this->receptor = $dado;
    }
    public function getReceptor() {
        return $this->receptor;
    }
    
    public function setDatetime($dado) {
        $this->datetime = $dado;
    }
    public function getDatetime() {
        return $this->datetime;
    }
    
}