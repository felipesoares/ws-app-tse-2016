<?php

require_once "iCrudDAO.php";

require_once "DoacaoMotivo.php";

class DoacaoMotivoDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "motivo_doacao";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector md.id = {$id}";
        }
        
        if (empty($order_by)) {
            $order_by = "md.id ASC";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT md.* FROM " . self::$tabela . " AS md {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->CacheGetAll($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $dados[] = new DoacaoMotivo($row["id"], $row["nome"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir($objeto){}
    public function atualizar($objeto){}
    public function excluir($id){}
    
}