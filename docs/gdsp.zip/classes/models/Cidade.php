<?php

class Cidade {
    
    private $id;
    private $nome;
    private $estado;
    
    public function __construct($id = null, $nome = null, $estado = null) {
        $this->setId($id);
        $this->setNome($nome);
        $this->setEstado($estado);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setNome($dado) {
        $this->nome = $dado;
    }
    public function getNome() {
        return $this->nome;
    }
    
    public function setEstado($dado) {
        $this->estado = $dado;
    }
    public function getEstado() {
        return $this->estado;
    }
    
}