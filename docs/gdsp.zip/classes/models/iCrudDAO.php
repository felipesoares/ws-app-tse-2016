<?php

interface iCrudDAO
{
    public function listar($id, $where, $order_by, $limit);
    public function inserir($objeto);
    public function atualizar($objeto);
    public function excluir($id);
}