<?php

class Estado {
    
    private $nome;
    private $sigla;
    
    public function __construct($nome = null, $sigla = null) {
        $this->setNome($nome);
        $this->setSigla($sigla);
    }
    
    public function setNome($dado) {
        $this->nome = $dado;
    }
    public function getNome() {
        return $this->nome;
    }
    
    public function setSigla($dado) {
        $this->sigla = $dado;
    }
    public function getSigla() {
        return $this->sigla;
    }
    
}