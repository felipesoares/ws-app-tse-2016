<?php

require_once "iCrudDAO.php";

require_once "PessoaDAO.php";
require_once "EstabelecimentoDAO.php";
require_once "Funcionario.php";
require_once "Cargo.php";

class FuncionarioDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "funcionarios";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function checharDuplicidade($nomeCampo, $valorCampo, $id = null) {
		
		$condicao = "";
		if ($id) { // editar
			$condicao .= " id != {$id} AND";
		}
		
		$rs = self::$DB->Execute("SELECT {$nomeCampo} FROM " . self::$tabela . " WHERE $condicao $nomeCampo = ?", array($valorCampo));
		return ($rs->RecordCount()) ? true : false;
	}
    
    public function listar($id = null, $where = "", $order_by = "p.id ASC", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector f.id = {$id}";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT f.*, c.nome AS cargoNome FROM " . self::$tabela . " AS f INNER JOIN pessoas AS p ON f.pessoa_id = p.id INNER JOIN cargos c ON f.cargo_id = c.id {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $pessoa = new PessoaDAO();
            $pessoa = $pessoa->listar($row["pessoa_id"]);
            $pessoa = ($pessoa) ? $pessoa[0] : null;
            
            $cargo = new Cargo($row["cargo_id"], $row["cargoNome"]);
            
            $estabelecimento = new EstabelecimentoDAO();
            $estabelecimento = $estabelecimento->listar($row["estabelecimento_id"]);
            $estabelecimento = ($estabelecimento) ? $estabelecimento[0] : null;
            
            $dados[] = new Funcionario($pessoa->getId(), $pessoa->getNome(), $pessoa->getCpf(), $pessoa->getRg(), $pessoa->getDataNascimento(), $pessoa->getSexo(), $pessoa->getTipoSanguineo(), $pessoa->getAcesso(), $pessoa->getTelefone(), $pessoa->getEndereco(), $pessoa->getStatus(), $row["id"], $row["matricula"], $row["data_admissao"], $row["salario"], $row["registro_profissional"], $cargo, $estabelecimento, $row["status"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir( $funcionario ){
        
        global $SESSION;
        
        $dataCriacao = date ( "Y-m-d H:i:s" );
		$dataUp = date ( "Y-m-d H:i:s" );
		$userCriacao = $SESSION->acessoId();
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        # campos opcionais
        $registroProfissional = ! empty ( $funcionario->getRegistroProfissional() ) ? $funcionario->getRegistroProfissional() : null;
        
        $sql = "INSERT INTO `" . self::$tabela . "`(`pessoa_id`, `matricula`, `data_admissao`, `salario`, `registro_profissional`, `cargo_id`, `estabelecimento_id`, `status`, `data_criacao`, `data_up`, `user_criacao`, `user_up`, `browser`, `ip`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
        $ok = self::$DB->Execute( $sql, array( $funcionario->getId(), $funcionario->getMatricula(), Functions::formatarDateTime($funcionario->getDataAdmissao(), "en")->date, Functions::formatarDecimaisBanco($funcionario->getSalario()), $registroProfissional, $funcionario->getCargo()->getId(), $funcionario->getEstabelecimento()->getId(), $funcionario->getStatusFuncionario(), $dataCriacao, $dataUp, $userCriacao, $userUp, $browser, $ip ) );
        
        $insertId = self::$DB->Insert_ID();
        
        return ($ok) ? $insertId : false;
    }
    
    public function atualizar( $funcionario ){
        
        global $SESSION;
        
		$dataUp = date ( "Y-m-d H:i:s" );
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
        # campos opcionais
        $registroProfissional = ! empty ( $funcionario->getRegistroProfissional() ) ? $funcionario->getRegistroProfissional() : null;
        
        $sql = "UPDATE `" . self::$tabela . "` SET `matricula`=?,`data_admissao`=?,`salario`=?,`registro_profissional`=?,`cargo_id`=?,`estabelecimento_id`=?,`status`=?,`data_up`=?,`user_up`=?,`browser`=?,`ip`=? WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $funcionario->getMatricula(), Functions::formatarDateTime($funcionario->getDataAdmissao(), "en")->date, Functions::formatarDecimaisBanco($funcionario->getSalario()), $registroProfissional, $funcionario->getCargo()->getId(), $funcionario->getEstabelecimento()->getId(), $funcionario->getStatusFuncionario(), $dataUp, $userUp, $browser, $ip, $funcionario->getIdFuncionario() ) );
        
        return $ok;
        
    }
    
    public function excluir( $id ){
        
        $sql = "DELETE FROM `" . self::$tabela . "` WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $id ) );
        
        return $ok;
    }
    
}