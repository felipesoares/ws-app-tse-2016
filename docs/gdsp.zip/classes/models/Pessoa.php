<?php

class Pessoa {
    
    private $id;
    private $nome;
    private $cpf;
    private $rg;
    private $dataNascimento;
    private $sexo;
    private $tipoSanguineo;
    private $acesso;
    private $telefone;
    private $endereco;
    private $status;
    
    public function __construct($id = null, $nome = null, $cpf = null, $rg = null, $dataNascimento = null, $sexo = null, $tipoSanguineo = null, $acesso = null, $telefone = null, $endereco = null, $status = null) {
        $this->setId($id);
        $this->setNome($nome);
        $this->setCpf($cpf);
        $this->setRg($rg);
        $this->setDataNascimento($dataNascimento);
        $this->setSexo($sexo);
        $this->setTipoSanguineo($tipoSanguineo);
        $this->setAcesso($acesso);
        $this->setTelefone($telefone);
        $this->setEndereco($endereco);
        $this->setStatus($status);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setNome($dado) {
        $this->nome = $dado;
    }
    public function getNome() {
        return $this->nome;
    }
    
    public function setCpf($dado) {
        $this->cpf = $dado;
    }
    public function getCpf() {
        return $this->cpf;
    }
    
    public function setRg($dado) {
        $this->rg = $dado;
    }
    public function getRg() {
        return $this->rg;
    }
    
    public function setDataNascimento($dado) {
        $this->dataNascimento = $dado;
    }
    public function getDataNascimento() {
        return $this->dataNascimento;
    }
    
    public function setSexo($dado) {
        $this->sexo = $dado;
    }
    public function getSexo() {
        return $this->sexo;
    }
    
    public function setTipoSanguineo($dado) {
        $this->tipoSanguineo = $dado;
    }
    public function getTipoSanguineo() {
        return $this->tipoSanguineo;
    }
    
    public function setAcesso($dado) {
        $this->acesso = $dado;
    }
    public function getAcesso() {
        return $this->acesso;
    }
    
    public function setTelefone($dado) {
        $this->telefone = $dado;
    }
    public function getTelefone() {
        return $this->telefone;
    }
    
    public function setEndereco($dado) {
        $this->endereco = $dado;
    }
    public function getEndereco() {
        return $this->endereco;
    }
    
    public function setStatus($dado) {
        $this->status = $dado;
    }
    public function getStatus() {
        return $this->status;
    }
    
}