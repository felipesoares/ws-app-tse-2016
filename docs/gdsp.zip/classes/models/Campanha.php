<?php

class Campanha {
    
    private $id;
    private $nome;
    private $descricao;
    private $dataInicio;
    private $dataFim;
    private $estabelecimento;
    private $status;
    
    public function __construct($id = null, $nome = null, $descricao = null, $dataInicio = null, $dataFim = null, $estabelecimento = null, $status = null) {
        $this->setId($id);
        $this->setNome($nome);
        $this->setDescricao($descricao);
        $this->setDataInicio($dataInicio);
        $this->setDataFim($dataFim);
        $this->setEstabelecimento($estabelecimento);
        $this->setStatus($status);
    }
    
    public function setId($dado) {
        $this->id = $dado;
    }
    public function getId() {
        return $this->id;
    }
    
    public function setNome($dado) {
        $this->nome = $dado;
    }
    public function getNome() {
        return $this->nome;
    }
    
    public function setDescricao($dado) {
        $this->descricao = $dado;
    }
    public function getDescricao() {
        return $this->descricao;
    }
    
    public function setDataInicio($dado) {
        $this->dataInicio = $dado;
    }
    public function getDataInicio() {
        return $this->dataInicio;
    }
    
    public function setDataFim($dado) {
        $this->dataFim = $dado;
    }
    public function getDataFim() {
        return $this->dataFim;
    }
    
    public function setEstabelecimento($dado) {
        $this->estabelecimento = $dado;
    }
    public function getEstabelecimento() {
        return $this->estabelecimento;
    }
    
    public function setStatus($dado) {
        $this->status = $dado;
    }
    public function getStatus() {
        return $this->status;
    }
    
}