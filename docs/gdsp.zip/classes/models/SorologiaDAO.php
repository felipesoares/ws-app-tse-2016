<?php

require_once "Sorologia.php";
require_once "BolsaDAO.php";
require_once "TipoExame.php";
require_once "ResultadoExame.php";
require_once "EstabelecimentoDAO.php";

class SorologiaDAO {
    
    private static $DB;
    private static $tabela = "sorologias";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector s.id = {$id}";
        }
        
        if (empty($order_by)) {
            $order_by = "s.id ASC";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT s.*, d.doador_id, d.data, p.nome FROM " . self::$tabela . " AS s INNER JOIN `sorologias_bolsas` AS sb ON s.id = sb.sorologia_id INNER JOIN bolsas b ON sb.bolsa_id = b.id INNER JOIN doacoes d ON b.doacao_id = d.id INNER JOIN doadores dd ON d.doador_id = dd.id INNER JOIN pessoas p ON dd.pessoa_id = p.id {$where} GROUP BY s.id ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        $rs = $rs ? $rs : array();
        
        $dados = array();
        
        $bolsaDAO = new BolsaDAO();
        $estabelecimentoDAO = new EstabelecimentoDAO();
        
        foreach ($rs as $row) {
            
            $bolsas = $bolsaDAO->listar(null, "sorologia_id = {$row["id"]}");
            
            $estabelecimento = $estabelecimentoDAO->listar($row["estabelecimento_id"]);
            $estabelecimento = $estabelecimento[0];
            
            $query = "SELECT ses.*, seti.nome AS nomeTipoExame, seti.status AS statusTipoExame FROM sorologias_exames_solicitacoes AS ses INNER JOIN sorologias_exames_tipo AS seti ON ses.tipo_exame_id = seti.id WHERE ses.sorologia_id = {$row["id"]}";
            
            $rs2 = self::$DB->GetAssoc($query);
            $rs2 = $rs2 ? $rs2 : array();
            
            $examesSolicitados = array();
            
            foreach ($rs2 as $row2) {
                $tipoExame = new TipoExame($row2["id"], $row2["nomeTipoExame"], $row2["statusTipoExame"]);
                $examesSolicitados[] = $tipoExame;
            }
            
            
            $query = "SELECT ser.*, seti.nome AS nomeTipoExame, seti.status AS statusTipoExame FROM sorologias_exames_resultados AS ser INNER JOIN sorologias_exames_tipo AS seti ON ser.tipo_exame_id = seti.id WHERE ser.sorologia_id = {$row["id"]}";
            
            $rs2 = self::$DB->GetAssoc($query);
            $rs2 = $rs2 ? $rs2 : array();
            
            $resultadosExames = array();
            
            $sorologia = new Sorologia($row["id"]);
            
            foreach ($rs2 as $row2) {
                $tipoExame = new TipoExame($row2["tipo_exame_id"], $row2["nomeTipoExame"], $row2["statusTipoExame"]);
                $resultadoExame = new ResultadoExame($row2["id"], $sorologia, $tipoExame, $row2["descricao"], $row2["anexo"]);
                $resultadosExames[] = $resultadoExame;
            }
            
            $dados[] = new Sorologia($row["id"], $bolsas, $examesSolicitados, $resultadosExames, $estabelecimento, $row["tipo_sanguineo"], $row["liberacao"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir( $bolsa ){
        
        global $SESSION;
        
        $dataCriacao = date ( "Y-m-d H:i:s" );
		$dataUp = date ( "Y-m-d H:i:s" );
		$userCriacao = $SESSION->acessoId();
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
    }
    
    public function atualizar( $bolsa ){
        
        global $SESSION;
        
		$dataUp = date ( "Y-m-d H:i:s" );
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
    }
    
    public function excluir( $id ){
        
        $sql = "DELETE FROM `" . self::$tabela . "` WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $id ) );
        
        return $ok;
    }
    
}