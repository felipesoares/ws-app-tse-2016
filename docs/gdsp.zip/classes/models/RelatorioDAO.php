<?php

class RelatorioDAO {
    
    private static $DB;
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function uniaoFuncionariosDoadores() {
        
        $query = "
        SELECT p.cpf, p.nome FROM `funcionarios` f INNER JOIN `pessoas` p ON f.pessoa_id = p.id
        UNION
        SELECT p.cpf, p.nome FROM `doadores` d INNER JOIN `pessoas` p ON d.pessoa_id = p.id
        LIMIT 10
        ";
        
        $rs = self::$DB->GetAll($query);
        $rs = $rs ? $rs : array();
        
        return ($rs) ? $rs : null;
    }
    
    public function intersecaoFuncionariosDoadores() {
        
        $query = "
        SELECT p.cpf, p.nome FROM `funcionarios` f INNER JOIN `pessoas` p ON f.pessoa_id = p.id INNER JOIN `doadores` d ON d.pessoa_id = f.pessoa_id
        ";
        
        $rs = self::$DB->GetAll($query);
        $rs = $rs ? $rs : array();
        
        return ($rs) ? $rs : null;
    }
    
    public function diferencaFuncionariosDoadores() {
        
        $query = "
        SELECT p.cpf, p.nome FROM `funcionarios` f INNER JOIN `pessoas` p ON f.pessoa_id = p.id WHERE f.pessoa_id NOT IN (SELECT d.pessoa_id FROM doadores d)
        LIMIT 10
        ";
        
        $rs = self::$DB->GetAll($query);
        $rs = $rs ? $rs : array();
        
        return ($rs) ? $rs : null;
    }
    
    public function somaSalarioMedicas() {
        
        $query = "
        SELECT SUM(f.salario) salario FROM funcionarios f INNER JOIN pessoas p ON f.pessoa_id = p.id INNER JOIN cargos c ON f.cargo_id = c.id WHERE p.sexo = 'F' AND c.nome = 'Médico'
        ";
        
        $rs = self::$DB->GetAll($query);
        $rs = $rs ? $rs : array();
        
        return ($rs) ? $rs : null;
    }
    
    public function quantidadeEnfermeiros() {
        
        $query = "
        SELECT COUNT(*) quantidade FROM funcionarios f INNER JOIN pessoas p ON f.pessoa_id = p.id INNER JOIN cargos c ON f.cargo_id = c.id WHERE p.sexo = 'M' AND c.nome = 'Enfermeiro'
        ";
        
        $rs = self::$DB->GetAll($query);
        $rs = $rs ? $rs : array();
        
        return ($rs) ? $rs : null;
    }
    
    public function salariosAtendentesEnfermeiros() {
        
        $query = "
        SELECT MIN(f.salario) minimo, MAX(f.salario) maximo FROM funcionarios f INNER JOIN pessoas p ON f.pessoa_id = p.id INNER JOIN cargos c ON f.cargo_id = c.id where p.sexo = 'M' AND (c.nome ='Atendente' OR c.nome = 'Enfermeiro')
        ";
        
        $rs = self::$DB->GetAll($query);
        $rs = $rs ? $rs : array();
        
        return ($rs) ? $rs : null;
    }
    
    public function mediasAvaliacoesAtendimento() {
        
        $query = "
        SELECT p.nome, AVG(aa.nota) media FROM `avaliacao_atendimento` aa INNER JOIN agendamentos a ON aa.agendamento_id = a.id INNER JOIN pessoas p ON a.pessoa_id = p.id WHERE p.sexo = 'F' GROUP BY p.nome HAVING media >=3
        LIMIT 10
        ";
        
        $rs = self::$DB->GetAll($query);
        $rs = $rs ? $rs : array();
        
        return ($rs) ? $rs : null;
    }
    
    public function qtdTransfusoesTiposanguineo() {
        
        $query = "
        SELECT * FROM gdsp.qtd_transfusoes_tipo_sanguineo
        ";
        $query = "
        SELECT s.tipo_sanguineo, COUNT(s.tipo_sanguineo) qtd_transfusoes FROM `transfusoes` t INNER JOIN bolsas b ON t.bolsa_id = b.id INNER JOIN sorologias_bolsas sb ON b.id = sb.bolsa_id INNER JOIN sorologias s ON sb.sorologia_id = s.id GROUP BY s.tipo_sanguineo
        ";
        
        $rs = self::$DB->GetAll($query);
        $rs = $rs ? $rs : array();
        
        return ($rs) ? $rs : null;
    }
    
    public function qtdDoacoesEspontaneasSexo() {
        
        $query = "
        SELECT * FROM gdsp.qtd_doacoes_espontaneas_sexo
        ";
        $query = "
        SELECT p.sexo, COUNT(d.id) qtd_doacoes_espontaneas FROM `doacoes` d INNER JOIN doadores dd ON d.doador_id = dd.id INNER JOIN pessoas p ON dd.pessoa_id = p.id INNER JOIN motivo_doacao md ON d.motivo_doacao_id = md.id WHERE md.nome = 'Espontânea' GROUP BY p.sexo
        ";
        
        $rs = self::$DB->GetAll($query);
        $rs = $rs ? $rs : array();
        
        return ($rs) ? $rs : null;
    }
    
}