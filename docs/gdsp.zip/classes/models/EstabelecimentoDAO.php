<?php

require_once "iCrudDAO.php";

require_once "Estado.php";
require_once "Cidade.php";
require_once "Endereco.php";
require_once "EstabelecimentoTipo.php";
require_once "EstabelecimentoTipoUct.php";
require_once "Estabelecimento.php";

class EstabelecimentoDAO implements iCrudDAO {
    
    private static $DB;
    private static $tabela = "estabelecimentos";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "c.nome ASC, u.id ASC", $limit = "") {
        
        global $DB;
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector u.id = {$id}";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT u.*, ut.nome AS estabelecimentoTipoNome, ut.status AS estabelecimentoStatus, utu.nome AS estabelecimentoTipoUctNome, c.nome AS cidadeNome, e.nome AS estadoNome, e.sigla AS estadoSigla FROM " . self::$tabela . " AS u INNER JOIN estabelecimentos_tipo AS ut ON u.estabelecimento_tipo_id = ut.id LEFT JOIN estabelecimentos_tipo_uct AS utu ON u.estabelecimento_tipo_uct_id = utu.id INNER JOIN cidades AS c ON u.cidade_id = c.id INNER JOIN estados AS e ON c.sigla_estado = e.sigla {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = $DB->GetAssoc($query);
        
        $dados = array();
        
        foreach ($rs as $row) {
            
            $estado = new Estado($row["estadoNome"], $row["estadoSigla"]);
            
            $cidade = new Cidade($row["cidade_id"], $row["cidadeNome"], $estado);
            
            $endereco = new Endereco($row["logradouro"], $row["numero"], $row["complemento"], $row["bairro"], $row["cep"], $cidade);
            
            $estabelecimentoTipo = new EstabelecimentoTipo($row["estabelecimento_tipo_id"], $row["estabelecimentoTipoNome"], $row["estabelecimentoStatus"]);
            
            $estabelecimentoTipoUct = new EstabelecimentoTipoUct($row["estabelecimento_tipo_uct_id"], $row["estabelecimentoTipoUctNome"]);
            
            $dados[] = new Estabelecimento($row["id"], $row["codigo"], $row["nome"], $row["cnpj"], $estabelecimentoTipo, $estabelecimentoTipoUct, $row["telefone"], $endereco, $row["status"]);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir($estabelecimento){}
    public function atualizar($estabelecimento){}
    public function excluir($id){}
    
}