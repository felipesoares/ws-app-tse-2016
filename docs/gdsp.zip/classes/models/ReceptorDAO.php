<?php

require_once "Receptor.php";
require_once "EstabelecimentoDAO.php";

class ReceptorDAO {
    
    private static $DB;
    private static $tabela = "receptores";
    
    public function __construct() {
        global $DB;
        self::$DB = $DB;
    }
    
    public function listar($id = null, $where = "", $order_by = "r.id ASC", $limit = "") {
        
        $conector = "";
        
        if ($where) {
            $conector = "AND";
            $where    = "WHERE {$where}";
        }
        
        if ($id) {
            if (!$conector)
                $conector = "WHERE";
            $where .= " $conector r.id = {$id}";
        }
        
        if (!empty($limit)) {
            $limit = "LIMIT {$limit}";
        }
        
        $query = "SELECT r.* FROM " . self::$tabela . " AS r {$where} ORDER BY {$order_by} {$limit}";
        
        $rs = self::$DB->GetAssoc($query);
        $rs = $rs ? $rs : array();
        
        $dados = array();
        
        $estabelecimentoDAO = new EstabelecimentoDAO();
        
        foreach ($rs as $row) {
            
            $estabelecimento = $estabelecimentoDAO->listar($row["estabelecimento_id"]);
            $estabelecimento = $estabelecimento[0];
            
            $dados[] = new Receptor($row["id"], $row["nome"], $row["cpf"], $estabelecimento);
            
        }
        
        return ($dados) ? $dados : null;
    }
    
    public function inserir( $bolsa ){
        
        global $SESSION;
        
        $dataCriacao = date ( "Y-m-d H:i:s" );
		$dataUp = date ( "Y-m-d H:i:s" );
		$userCriacao = $SESSION->acessoId();
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
    }
    
    public function atualizar( $bolsa ){
        
        global $SESSION;
        
		$dataUp = date ( "Y-m-d H:i:s" );
		$userUp = $SESSION->acessoId();
		$browser = strtoupper ( $_SERVER ["HTTP_USER_AGENT"] );
		$ip = $_SERVER ["REMOTE_ADDR"];
        
    }
    
    public function excluir( $id ){
        
        $sql = "DELETE FROM `" . self::$tabela . "` WHERE id = ?";
        
        $ok = self::$DB->Execute( $sql, array( $id ) );
        
        return $ok;
    }
    
}