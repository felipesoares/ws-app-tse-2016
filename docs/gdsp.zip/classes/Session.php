<?php

class Session {
    
    private static $sessionName = "GDSP_USER_ID";
    
    public function __construct() {
        
        if (!isset($_SESSION)) {
            session_start();
        }
        
        #$this->build();
        #$this->destroy();
    }
    
    public function build($acessoId) {
        
        $_SESSION[self::$sessionName] = $acessoId;
        $_SESSION["LAST_ACTIVITY"]    = time();
        
    }
    
    public function destroy() {
        
        unset($_SESSION[self::$sessionName]);
        unset($_SESSION["LAST_ACTIVITY"]);
        
    }
    
    public function logged() {
        
        return isset($_SESSION[self::$sessionName]) && $_SESSION[self::$sessionName];
        
    }
    
    public function expired() {
        
        if ($this->logged() && isset($_SESSION["LAST_ACTIVITY"]) && ((time() - $_SESSION["LAST_ACTIVITY"] > 900))) { # > 900 3600
            return true;
        }
        
        $_SESSION["LAST_ACTIVITY"] = time();
        
        return false;
    }
    
    public function acessoId() {
        
        if ($this->logged())
            return $_SESSION[self::$sessionName];
        
        return "";
    }
    
}