<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Funcionario.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Cargo.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Estabelecimento.php";

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "PessoaDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "FuncionarioDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "CargoDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "EstabelecimentoDAO.php";

class FuncionarioController {
    
    private $pessoaDAO;
    private $funcionarioDAO;
    private $cargoDAO;
    private $estabelecimentoDAO;
    
    public function __construct() {
        $this->pessoaDAO = new PessoaDAO();
        $this->funcionarioDAO = new FuncionarioDAO();
        $this->cargoDAO = new CargoDAO();
        $this->estabelecimentoDAO = new EstabelecimentoDAO();
    }
    
    public function listar() {
        
        $_REQUEST["dados"] = $this->funcionarioDAO->listar();
        
        require_once "views/{$_GET["pagina"]}.php";
    }
    
    public function checharDuplicidade($nomeCampo, $valorCampo, $id = null) {
        
        return $this->funcionarioDAO->checharDuplicidade($nomeCampo, $valorCampo, $id);
        
    }
    
    public function adicionar() {
        
        $_REQUEST["dados"] = $this->funcionarioDAO->listar();
        
        $where = "";
        
        if( $_REQUEST["dados"] ){
            $not = array();
            foreach( $_REQUEST["dados"] as $dado ){
                $not[] = $dado->getId();
            }
            $not_in = join(",", $not);
            $where = "p.id NOT IN({$not_in})";
        }
        
        $_REQUEST["dados"]["pessoa"] = $this->pessoaDAO->listar(null, $where);
        $_REQUEST["dados"]["cargo"] = $this->cargoDAO->listar();
        $_REQUEST["dados"]["estabelecimento"] = $this->estabelecimentoDAO->listar();
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
    public function editar() {
        
        $_REQUEST["dados"] = $this->funcionarioDAO->listar($_REQUEST["id"]);
        
        if( $_REQUEST["dados"] ){
            
            $_REQUEST["dados"]["cargo"] = $this->cargoDAO->listar();
            $_REQUEST["dados"]["estabelecimento"] = $this->estabelecimentoDAO->listar();
            
            require_once "views/{$_GET["pagina"]}-formulario.php";
            
        }else{
            
            require_once "views/404.php";
        }
        
    }
    
    public function inserir(){
        
        $cargo = new Cargo($_REQUEST["cargoId"], null);
        $estabelecimento = new Estabelecimento($_REQUEST["estabelecimentoId"], null, null, null, null, null, null, null, null);
        
        $funcionario = new Funcionario($_REQUEST["pessoaId"], null, null, null, null, null, null, null, null, null, null, null, $_REQUEST["matricula"], $_REQUEST["dataAdmissao"], $_REQUEST["salario"], $_REQUEST["registroProfissional"], $cargo, $estabelecimento, $_REQUEST["status"]);
        
        return $this->funcionarioDAO->inserir($funcionario);
        
    }
    
    public function atualizar(){
        
        // Solicitação ruim
        if( !$this->funcionarioDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        $cargo = new Cargo($_REQUEST["cargoId"], null);
        $estabelecimento = new Estabelecimento($_REQUEST["estabelecimentoId"], null, null, null, null, null, null, null, null);
        
        $funcionario = new Funcionario(null, null, null, null, null, null, null, null, null, null, null, $_REQUEST["id"], $_REQUEST["matricula"], $_REQUEST["dataAdmissao"], $_REQUEST["salario"], $_REQUEST["registroProfissional"], $cargo, $estabelecimento, $_REQUEST["status"]);
        
        return $this->funcionarioDAO->atualizar($funcionario);
        
    }
    
    public function excluir(){
        
        // Solicitação ruim
        if( !$this->funcionarioDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        return $this->funcionarioDAO->excluir($_REQUEST["id"]);
        
    }
    
}