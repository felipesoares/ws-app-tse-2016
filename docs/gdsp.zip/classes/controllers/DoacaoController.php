<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "DoacaoDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "PessoaDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "DoacaoMotivoDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "BolsaDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "SorologiaDAO.php";

class DoacaoController {
    
    private $doacaoDAO;
    private $pessoaDAO;
    private $motivoDoacaoDAO;
    private $estabelecimentoDAO;
    private $sorologiaDAO;
    private $bolsaDAO;
    
    public function __construct() {
        $this->doacaoDAO = new DoacaoDAO();
        $this->pessoaDAO = new PessoaDAO();
        $this->motivoDoacaoDAO = new DoacaoMotivoDAO();
        $this->estabelecimentoDAO = new EstabelecimentoDAO();
        $this->sorologiaDAO = new SorologiaDAO();
        $this->bolsaDAO = new BolsaDAO();
    }
    
    public function listar() {
        
        global $ACESSO;
        global $PESSOA;
        
        if( $ACESSO->isDoador() ){
            
            $_REQUEST["dados"] = $this->doacaoDAO->listar(null, "dd.pessoa_id = " . $PESSOA->getId());
            
        }else{
            $_REQUEST["dados"] = $this->doacaoDAO->listar(null, null, null, 30);
        }
        
        require_once "views/{$_GET["pagina"]}.php";
    }
    
    public function editar() {
        
        $_REQUEST["dados"] = $this->doacaoDAO->listar($_REQUEST["id"]);
        
        if( $_REQUEST["dados"] ){

            $_REQUEST["dados"]["pessoa"] = $this->pessoaDAO->listar();
            $_REQUEST["dados"]["motivoDoacao"] = $this->motivoDoacaoDAO->listar();
            $_REQUEST["dados"]["estabelecimento"] = $this->estabelecimentoDAO->listar(null, "u.estabelecimento_tipo_id IN (1)"); # unidades
            
            $bolsasDados = $this->bolsaDAO->listar(null, "b.doacao_id = {$_REQUEST["id"]}");
            
            $bolsas = array();
            foreach( $bolsasDados as $bolsa ){
                $bolsas[] = $bolsa->getId();
            }
            $bolsas = join($bolsas, ", ");
            
            $_REQUEST["dados"]["sorologia"] = $this->sorologiaDAO->listar(null, "sb.bolsa_id IN({$bolsas})");
            #echo "<pre>"; print_r ($_REQUEST["dados"]["sorologia"][0]->getResultadosExames()[0]);exit;
            require_once "views/{$_GET["pagina"]}-formulario.php";
            
        }else{
            
            require_once "views/404.php";
        }
        
    }
    
    public function adicionar() {
        
        global $ACESSO;
        
        $_REQUEST["dados"] = array();
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
}