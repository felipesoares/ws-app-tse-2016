<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "CidadeDAO.php";

class CidadeController {
    
    private $cidadeDAO;
    
    public function __construct() {
        $this->cidadeDAO = new CidadeDAO();
    }
    
    public function carregarCidadesEstado( $siglaEstado ) {
        
        return $this->cidadeDAO->listar(null, "c.sigla_estado = '{$siglaEstado}'");
        
    }
    
}