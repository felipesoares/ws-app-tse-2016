<?php

class DashboardController {
    
    public function __construct() {
        
    }
    
    public function listar() {
        
        require_once "views/dashboard.php";
    }
    
}