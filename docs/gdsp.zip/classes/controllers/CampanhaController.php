<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Campanha.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Estabelecimento.php";

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "CampanhaDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "EstabelecimentoDAO.php";

class CampanhaController {
    
    private $campanhaDAO;
    private $estabelecimentoDAO;
    
    public function __construct() {
        $this->campanhaDAO = new CampanhaDAO();
        $this->estabelecimentoDAO = new EstabelecimentoDAO();
    }
    
    public function listar() {
        
        global $ACESSO;
        global $PESSOA;
        
        $_REQUEST["dados"] = $this->campanhaDAO->listar();
        
        require_once "views/{$_GET["pagina"]}.php";
    }
    
    public function checharDuplicidade($nomeCampo, $valorCampo, $id = null) {
        
        return $this->campanhaDAO->checharDuplicidade($nomeCampo, $valorCampo, $id);
        
    }
    
    public function adicionar() {
        
        global $ACESSO;
        
        $_REQUEST["dados"]["estabelecimento"] = $this->estabelecimentoDAO->listar(null, "u.estabelecimento_tipo_id IN (1,2)"); # unidades e hospitais
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
    public function editar() {
        
        global $ACESSO;
        
        $_REQUEST["dados"] = $this->campanhaDAO->listar($_REQUEST["id"]);
        
        if( $_REQUEST["dados"] ){
            
            $_REQUEST["dados"]["estabelecimento"] = $this->estabelecimentoDAO->listar(null, "u.estabelecimento_tipo_id IN (1,2)"); # unidades e hospitais
            require_once "views/{$_GET["pagina"]}-formulario.php";
            
        }else{
            
            require_once "views/404.php";
        }
        
    }
    
    public function inserir(){
        
        $estabelecimento = new Estabelecimento();
        $estabelecimento->setId($_REQUEST["estabelecimentoId"]);
        
        $campanha = new Campanha(null, $_REQUEST["nome"], $_REQUEST["descricao"], $_REQUEST["dataInicio"], $_REQUEST["dataFim"], $estabelecimento, $_REQUEST["status"]);
        
        return $this->campanhaDAO->inserir($campanha);
        
    }
    
    public function atualizar(){
        
        // Solicitação ruim
        if( !$this->campanhaDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        $estabelecimento = new Estabelecimento();
        $estabelecimento->setId($_REQUEST["estabelecimentoId"]);
        
        $campanha = new Campanha($_REQUEST["id"], $_REQUEST["nome"], $_REQUEST["descricao"], $_REQUEST["dataInicio"], $_REQUEST["dataFim"], $estabelecimento, $_REQUEST["status"]);
        
        return $this->campanhaDAO->atualizar($campanha);
        
    }
    
    public function excluir(){
        
        // Solicitação ruim
        if( !$this->campanhaDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        return $this->campanhaDAO->excluir($_REQUEST["id"]);
        
    }
    
}