<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Doador.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "DoadorTipo.php";

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "PessoaDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "DoadorDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "DoadorTipoDAO.php";

class DoadorController {
    
    private $pessoaDAO;
    private $doadorDAO;
    private $tipoDoadorDAO;
    
    public function __construct() {
        $this->pessoaDAO = new PessoaDAO();
        $this->doadorDAO = new DoadorDAO();
        $this->tipoDoadorDAO = new DoadorTipoDAO();
    }
    
    public function listar() {
        
        $_REQUEST["dados"] = $this->doadorDAO->listar();
        
        require_once "views/{$_GET["pagina"]}.php";
    }
    
    public function adicionar() {
        
        $_REQUEST["dados"] = $this->doadorDAO->listar();
        
        $where = "";
        
        if( $_REQUEST["dados"] ){
            $not = array();
            foreach( $_REQUEST["dados"] as $dado ){
                $not[] = $dado->getId();
            }
            $not_in = join(",", $not);
            $where = "p.id NOT IN({$not_in})";
        }
        
        $_REQUEST["dados"]["pessoa"] = $this->pessoaDAO->listar(null, $where);
        
        $_REQUEST["dados"]["tipoDoador"] = $this->tipoDoadorDAO->listar();
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
    public function editar() {
        
        $_REQUEST["dados"] = $this->doadorDAO->listar($_REQUEST["id"]);
        
        if( $_REQUEST["dados"] ){
            
            $_REQUEST["dados"]["tipoDoador"] = $this->tipoDoadorDAO->listar();
            require_once "views/{$_GET["pagina"]}-formulario.php";
            
        }else{
            
            require_once "views/404.php";
        }
        
    }
    
    public function inserir(){
        
        $tipoDoador = new DoadorTipo($_REQUEST["tipoDoadorId"], null, null);
        
        $doador = new Doador($_REQUEST["pessoaId"], null, null, null, null, null, null, null, null, null, null, null, $tipoDoador, $_REQUEST["status"]);
        
        return $this->doadorDAO->inserir($doador);
        
    }
    
    public function atualizar(){
        
        // Solicitação ruim
        if( !$this->doadorDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        $tipoDoador = new DoadorTipo($_REQUEST["tipoDoadorId"], null, null);
        
        $doador = new Doador(null, null, null, null, null, null, null, null, null, null, null, $_REQUEST["id"], $tipoDoador, $_REQUEST["status"]);
        
        return $this->doadorDAO->atualizar($doador);
        
    }
    
    public function excluir(){
        
        // Solicitação ruim
        if( !$this->doadorDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        return $this->doadorDAO->excluir($_REQUEST["id"]);
        
    }
    
}