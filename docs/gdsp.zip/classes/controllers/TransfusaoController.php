<?php

class TransfusaoController {
    
    public function __construct() {
        
    }
    
    public function listar() {
        
        require_once "views/{$_GET["pagina"]}.php";
    }
    
    public function editar() {
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
    public function adicionar() {
        
        global $ACESSO;
        
        $_REQUEST["dados"] = array();
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
}