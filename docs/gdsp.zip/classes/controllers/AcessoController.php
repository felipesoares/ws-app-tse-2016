<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "AcessoDAO.php";

class AcessoController {
    
    private $acessoDAO;
    
    public function __construct() {
        $this->acessoDAO = new AcessoDAO();
    }
    
    public function autenticar($login, $senha) {
        
        global $SESSION;
        
        $acessoId = $this->acessoDAO->autenticar($login, $senha);
        
        if ($acessoId) {
            $SESSION->build($acessoId);
            return $acessoId;
        }
        return false;
        
    }
    
    public function checharDuplicidade($nomeCampo, $valorCampo, $id = null) {
        
        return $this->acessoDAO->checharDuplicidade($nomeCampo, $valorCampo, $id);
        
    }
    
    public function listarInfoAcesso($id) {
        
        if( $id )
            return $this->acessoDAO->listar($id);
        
        return null;
        
    }
    
}