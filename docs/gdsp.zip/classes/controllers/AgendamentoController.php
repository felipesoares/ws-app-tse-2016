<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Agendamento.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "DoacaoMotivo.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Estabelecimento.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Campanha.php";

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "AgendamentoDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "PessoaDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "DoacaoMotivoDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "EstabelecimentoDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "CampanhaDAO.php";

class AgendamentoController {
    
    private $agendamentoDAO;
    private $pessoaDAO;
    private $motivoDoacaoDAO;
    private $estabelecimentoDAO;
    private $campanhaDAO;
    
    public function __construct() {
        $this->agendamentoDAO = new AgendamentoDAO();
        $this->pessoaDAO = new PessoaDAO();
        $this->motivoDoacaoDAO = new DoacaoMotivoDAO();
        $this->estabelecimentoDAO = new EstabelecimentoDAO();
        $this->campanhaDAO = new CampanhaDAO();
    }
    
    public function listar() {
        
        global $ACESSO;
        global $PESSOA;
        
        if( $ACESSO->isDoador() ){
            
            $_REQUEST["dados"] = $this->agendamentoDAO->listar(null, "a.pessoa_id = " . $PESSOA->getId());
            
        }else{
            $_REQUEST["dados"] = $this->agendamentoDAO->listar();
        }
        
        require_once "views/{$_GET["pagina"]}.php";
    }
    
    public function checharDuplicidade($estabelecimentoId, $data, $horario, $id = null) {
        
        return $this->agendamentoDAO->checharDuplicidade($estabelecimentoId, $data, $horario, $id);
        
    }
    
    public function adicionar() {
        
        global $ACESSO;
        
        $_REQUEST["dados"]["pessoa"] = $this->pessoaDAO->listar();
        $_REQUEST["dados"]["motivoDoacao"] = $this->motivoDoacaoDAO->listar();
        $_REQUEST["dados"]["estabelecimento"] = $this->estabelecimentoDAO->listar(null, "u.estabelecimento_tipo_id IN (1)"); # unidades
        $_REQUEST["dados"]["campanha"] = $this->campanhaDAO->listar();
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
    public function editar() {
        
        global $ACESSO;
        
        $_REQUEST["dados"] = $this->agendamentoDAO->listar($_REQUEST["id"]);
        
        if( $_REQUEST["dados"] ){
            
            $_REQUEST["dados"]["pessoa"] = $this->pessoaDAO->listar();
            $_REQUEST["dados"]["motivoDoacao"] = $this->motivoDoacaoDAO->listar();
            $_REQUEST["dados"]["estabelecimento"] = $this->estabelecimentoDAO->listar(null, "u.estabelecimento_tipo_id IN (1)"); # unidades
            $_REQUEST["dados"]["campanha"] = $this->campanhaDAO->listar();
            
            require_once "views/{$_GET["pagina"]}-formulario.php";
            
        }else{
            
            require_once "views/404.php";
        }
        
    }
    
    public function inserir(){
        
        $pessoa = new Pessoa();
        $pessoa->setId($_REQUEST["pessoaId"]);
        
        $motivoDoacao = new DoacaoMotivo();
        $motivoDoacao->setId($_REQUEST["motivoDoacaoId"]);
        
        $estabelecimento = new Estabelecimento();
        $estabelecimento->setId($_REQUEST["estabelecimentoId"]);
        
        $campanha = new Campanha();
        $campanha->setId($_REQUEST["campanhaId"]);
        
        $agendamento = new Agendamento(null, $pessoa, $motivoDoacao, $estabelecimento, $campanha, $_REQUEST["data"], $_REQUEST["horario"], $_REQUEST["status"]);
        
        return $this->agendamentoDAO->inserir($agendamento);
        
    }
    
    public function atualizar(){
        
        // Solicitação ruim
        if( !$this->agendamentoDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        $motivoDoacao = new DoacaoMotivo();
        $motivoDoacao->setId($_REQUEST["motivoDoacaoId"]);
        
        $estabelecimento = new Estabelecimento();
        $estabelecimento->setId($_REQUEST["estabelecimentoId"]);
        
        $campanha = new Campanha();
        $campanha->setId($_REQUEST["campanhaId"]);
        
        $agendamento = new Agendamento($_REQUEST["id"], null, $motivoDoacao, $estabelecimento, $campanha, $_REQUEST["data"], $_REQUEST["horario"], $_REQUEST["status"]);
        
        return $this->agendamentoDAO->atualizar($agendamento);
        
    }
    
    public function excluir(){
        
        // Solicitação ruim
        if( !$this->agendamentoDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        return $this->agendamentoDAO->excluir($_REQUEST["id"]);
        
    }
    
}