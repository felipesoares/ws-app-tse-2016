<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "BolsaDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "DoacaoDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "SorologiaDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "TransferenciaDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "TransfusaoDAO.php";

class BolsaController {
    
    private $bolsaDAO;
    private $doacaoDAO;
    private $sorologiaDAO;
    private $transferenciaDAO;
    private $transfusaoDAO;
    
    public function __construct() {
        $this->bolsaDAO = new BolsaDAO();
        $this->doacaoDAO = new DoacaoDAO();
        $this->sorologiaDAO = new SorologiaDAO();
        $this->transferenciaDAO = new TransferenciaDAO();
        $this->transfusaoDAO = new TransfusaoDAO();
    }
    
    public function listar() {
        
        $_REQUEST["dados"] = $this->bolsaDAO->listar(null, null, null, 30);
        
        $bolsas = array();
        foreach( $_REQUEST["dados"] as $bolsa ){
            $bolsas[] = $bolsa->getId();
        }
        $bolsas = join($bolsas, ", ");
        
        #$_REQUEST["dados"]["sorologias"] = $this->sorologiaDAO->listar(null, "sb.bolsa_id IN({$bolsas})");
        
        require_once "views/{$_GET["pagina"]}.php";
    }
    
    public function pesquisar($id) {
        
        return $this->bolsaDAO->listar($id, null, null, 30);
        
    }
    
    public function editar() {
        
        $_REQUEST["dados"] = $this->bolsaDAO->listar($_REQUEST["id"]);
        
        if( $_REQUEST["dados"] ){

            $_REQUEST["dados"]["doacao"] = $this->doacaoDAO->listar();
            $_REQUEST["dados"]["transferencias"] = $this->transferenciaDAO->listar(null, "t.bolsa_id = {$_REQUEST["id"]}");
            $_REQUEST["dados"]["transfusao"] = $this->transfusaoDAO->listar(null, "t.bolsa_id = {$_REQUEST["id"]}");
            
            require_once "views/{$_GET["pagina"]}-formulario.php";
            
        }else{
            
            require_once "views/404.php";
        }
        
    }
    
    public function adicionar() {
        
        global $ACESSO;
        
        $_REQUEST["dados"] = array();
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
}