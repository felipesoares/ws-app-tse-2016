<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "PessoaDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "EstadoDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "CidadeDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "PerfilAcessoDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "EstabelecimentoDAO.php";

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "PerfilAcesso.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Acesso.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Cidade.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Endereco.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Pessoa.php";

class PessoaController {
    
    private $pessoaDAO;
    private $estadoDAO;
    private $cidadeDAO;
    private $perfilAcessoDAO;
    private $estabelecimentoDAO;
    
    public function __construct() {
        $this->pessoaDAO = new PessoaDAO();
        $this->estadoDAO = new EstadoDAO();
        $this->cidadeDAO = new CidadeDAO();
        $this->perfilAcessoDAO = new PerfilAcessoDAO();
        $this->estabelecimentoDAO = new EstabelecimentoDAO();
    }
    
    public function listarPaginaCadastro() {
        
        $_REQUEST["dados"]["estado"] = $this->estadoDAO->listar();
        $_REQUEST["dados"]["cidade"] = $this->cidadeDAO->listar();
        $_REQUEST["dados"]["perfilAcesso"] = $this->perfilAcessoDAO->listar();
        $_REQUEST["dados"]["estabelecimento"] = $this->estabelecimentoDAO->listar();
        
    }
    
    public function listar() {
        
        $_REQUEST["dados"] = $this->pessoaDAO->listar();
        
        require_once "views/{$_GET["pagina"]}.php";
    }
    
    public function listarDados($id = null, $where = "") {
        
        $dados = $this->pessoaDAO->listar($id, $where);
        return ($dados) ? $dados[0] : null;
        
    }
    
    public function adicionar() {
        
        global $ACESSO;
        
        $_REQUEST["dados"]["estado"] = $this->estadoDAO->listar();
        $_REQUEST["dados"]["perfilAcesso"] = $this->perfilAcessoDAO->listar();
        $_REQUEST["dados"]["estabelecimento"] = $this->estabelecimentoDAO->listar();
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
    public function editar() {
        
        global $ACESSO;
        global $PESSOA;
        
        if( !$ACESSO->isAdmin() && ($PESSOA->getId() != $_REQUEST["id"]) ){
            
            require_once "views/404.php";
            
        }else{

            $_REQUEST["dados"] = $this->pessoaDAO->listar($_REQUEST["id"]);

            if( $_REQUEST["dados"] ){

                $siglaEstado = $_REQUEST["dados"][0]->getEndereco()->getCidade()->getEstado()->getSigla();
                
                $_REQUEST["dados"]["estado"] = $this->estadoDAO->listar();
                $_REQUEST["dados"]["cidade"] = $this->cidadeDAO->listar(null, "c.sigla_estado = '{$siglaEstado}'");
                $_REQUEST["dados"]["perfilAcesso"] = $this->perfilAcessoDAO->listar();
                $_REQUEST["dados"]["estabelecimento"] = $this->estabelecimentoDAO->listar();

                require_once "views/{$_GET["pagina"]}-formulario.php";

            }else{

                require_once "views/404.php";
            }

        }
        
    }
    
    public function checharDuplicidade($nomeCampo, $valorCampo, $id = null) {
        
        return $this->pessoaDAO->checharDuplicidade($nomeCampo, $valorCampo, $id);
        
    }
    
    public function inserir(){
        
        $perfilAcesso = new PerfilAcesso($_REQUEST["perfilAcessoId"], null, null);
        $acesso = new Acesso(null, $_REQUEST["email"], $_REQUEST["senha"], $perfilAcesso, $_REQUEST["status"]);
        
        $cidade = new Cidade($_REQUEST["cidadeId"], null, null);
        
        $endereco = new Endereco($_REQUEST["logradouro"], $_REQUEST["numero"], $_REQUEST["complemento"], $_REQUEST["bairro"], $_REQUEST["cep"], $cidade);
        
        $pessoa = new Pessoa(null, $_REQUEST["nome"], $_REQUEST["cpf"], $_REQUEST["rg"], $_REQUEST["dataNascimento"], $_REQUEST["sexo"], $_REQUEST["tipoSanguineo"], $acesso, $_REQUEST["telefone"], $endereco, $_REQUEST["status"]);
        
        return $this->pessoaDAO->inserir($pessoa);
        
    }
    
    public function atualizar(){
        
        // Solicitação ruim
        if( !$this->pessoaDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        $perfilAcesso = new PerfilAcesso(null, null, null);
        $acesso = new Acesso(null, null, null, $perfilAcesso, null);
        
        $cidade = new Cidade($_REQUEST["cidadeId"], null, null);
        
        $endereco = new Endereco($_REQUEST["logradouro"], $_REQUEST["numero"], $_REQUEST["complemento"], $_REQUEST["bairro"], $_REQUEST["cep"], $cidade);
        
        $pessoa = new Pessoa($_REQUEST["id"], $_REQUEST["nome"], $_REQUEST["cpf"], $_REQUEST["rg"], $_REQUEST["dataNascimento"], $_REQUEST["sexo"], $_REQUEST["tipoSanguineo"], $acesso, $_REQUEST["telefone"], $endereco, $_REQUEST["status"]);
        
        return $this->pessoaDAO->atualizar($pessoa);
        
    }
    
    public function excluir(){
        
        // Solicitação ruim
        if( !$this->pessoaDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        return $this->pessoaDAO->excluir($_REQUEST["id"]);
        
    }
    
}