<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "SorologiaDAO.php";

class SorologiaController {
    
    private $sorologiaDAO;
    
    public function __construct() {
        $this->sorologiaDAO = new SorologiaDAO();
    }
    
    public function listar() {
        
        $_REQUEST["dados"] = $this->sorologiaDAO->listar(null, null, null, 40);
        
        require_once "views/{$_GET["pagina"]}.php";
    }
    
    public function pesquisar($id) {
        
        if($id)
            return $_REQUEST["dados"] = $this->sorologiaDAO->listar(null, "s.id = {$id} OR sb.bolsa_id IN({$id}) OR d.doador_id = {$id}", null, 40);
        else
            return $_REQUEST["dados"] = $this->sorologiaDAO->listar(null, null, null, 40);
    }
    
    public function pesquisarNomeDoador($nomeDoador) {
        
        if($nomeDoador)
            return $_REQUEST["dados"] = $this->sorologiaDAO->listar(null, "p.nome LIKE '%{$nomeDoador}%'", null, 40);
        else
            return $_REQUEST["dados"] = $this->sorologiaDAO->listar(null, null, null, 40);
    }
    
    public function pesquisarDatasDoacoes($dataStart, $dataEnd) {
        
        if($dataStart && $dataEnd){
            
            $dataStart = Functions::formatarDateTime($dataStart, null)->date;
            $dataEnd = Functions::formatarDateTime($dataEnd, null)->date;
            
            return $_REQUEST["dados"] = $this->sorologiaDAO->listar(null, "(d.data BETWEEN '{$dataStart}' AND '{$dataEnd}')", null, 40);
            
        }else{
            
            return $_REQUEST["dados"] = $this->sorologiaDAO->listar(null, null, null, 40);
        }
    }
    
    public function editar() {
        
        $_REQUEST["dados"] = $this->sorologiaDAO->listar($_REQUEST["id"]);
        
        if( $_REQUEST["dados"] ){
            
            require_once "views/{$_GET["pagina"]}-formulario.php";
            
        }else{
            
            require_once "views/404.php";
        }
        
    }
    
    public function adicionar() {
        
        global $ACESSO;
        
        $_REQUEST["dados"] = array();
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
}