<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Triagem.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Pessoa.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "Funcionario.php";

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "TriagemDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "PessoaDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "FuncionarioDAO.php";

class TriagemController {
    
    private $triagemDAO;
    private $pessoaDAO;
    private $funcionarioDAO;
    
    public function __construct() {
        $this->triagemDAO = new TriagemDAO();
        $this->pessoaDAO = new PessoaDAO();
        $this->funcionarioDAO = new FuncionarioDAO();
    }
    
    public function listar() {
        
        global $ACESSO;
        global $PESSOA;
        
        $_REQUEST["dados"] = $this->triagemDAO->listar();
        
        require_once "views/{$_GET["pagina"]}.php";
    }
    
    public function adicionar() {
        
        global $ACESSO;
        
        $_REQUEST["dados"]["pessoa"] = $this->pessoaDAO->listar();
        $_REQUEST["dados"]["funcionario"] = $this->funcionarioDAO->listar();
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
    public function editar() {
        
        global $ACESSO;
        
        $_REQUEST["dados"] = $this->triagemDAO->listar($_REQUEST["id"]);
        
        if( $_REQUEST["dados"] ){
            
            $_REQUEST["dados"]["pessoa"] = $this->pessoaDAO->listar();
            $_REQUEST["dados"]["funcionario"] = $this->funcionarioDAO->listar();
            
            require_once "views/{$_GET["pagina"]}-formulario.php";
            
        }else{
            
            require_once "views/404.php";
        }
        
    }
    
    public function inserir(){
        
        $pessoa = new Pessoa();
        $pessoa->setId($_REQUEST["pessoaId"]);
        
        $funcionario = new Funcionario();
        $funcionario->setId($_REQUEST["funcionarioId"]);
        
        $triagem = new Triagem(null, $pessoa, $funcionario, $_REQUEST["data"], $_REQUEST["horario"], $_REQUEST["q1"], $_REQUEST["q2"], $_REQUEST["q3"], $_REQUEST["q4"], $_REQUEST["q5"], $_REQUEST["q6"], $_REQUEST["q7"], $_REQUEST["q8"], $_REQUEST["q9"], $_REQUEST["q10"], $_REQUEST["aptidao_ok"]);
        
        return $this->triagemDAO->inserir($triagem);
        
    }
    
    public function atualizar(){
        
        // Solicitação ruim
        if( !$this->triagemDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        $funcionario = new Funcionario();
        $funcionario->setId($_REQUEST["funcionarioId"]);
        
        $triagem = new Triagem($_REQUEST["id"], null, $funcionario, $_REQUEST["data"], $_REQUEST["horario"], $_REQUEST["q1"], $_REQUEST["q2"], $_REQUEST["q3"], $_REQUEST["q4"], $_REQUEST["q5"], $_REQUEST["q6"], $_REQUEST["q7"], $_REQUEST["q8"], $_REQUEST["q9"], $_REQUEST["q10"], $_REQUEST["aptidao_ok"]);
        
        return $this->triagemDAO->atualizar($triagem);
        
    }
    
    public function excluir(){
        
        // Solicitação ruim
        if( !$this->triagemDAO->listar($_REQUEST["id"]) ){
            http_response_code(400); exit;
        }
        
        return $this->triagemDAO->excluir($_REQUEST["id"]);
        
    }
    
}