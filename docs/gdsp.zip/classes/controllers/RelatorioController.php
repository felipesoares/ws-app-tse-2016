<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "RelatorioDAO.php";

class RelatorioController {
    
    private $relatorioDAO;
    
    public function __construct() {
        $this->relatorioDAO = new RelatorioDAO();
    }
    
    public function listar() {
        
        $_REQUEST["dados"]["uniaoFuncionariosDoadores"] = $this->relatorioDAO->uniaoFuncionariosDoadores();
        $_REQUEST["dados"]["intersecaoFuncionariosDoadores"] = $this->relatorioDAO->intersecaoFuncionariosDoadores();
        $_REQUEST["dados"]["diferencaFuncionariosDoadores"] = $this->relatorioDAO->diferencaFuncionariosDoadores();
        $_REQUEST["dados"]["somaSalarioMedicas"] = $this->relatorioDAO->somaSalarioMedicas();
        $_REQUEST["dados"]["quantidadeEnfermeiros"] = $this->relatorioDAO->quantidadeEnfermeiros();
        $_REQUEST["dados"]["salariosAtendentesEnfermeiros"] = $this->relatorioDAO->salariosAtendentesEnfermeiros();
        $_REQUEST["dados"]["mediasAvaliacoesAtendimento"] = $this->relatorioDAO->mediasAvaliacoesAtendimento();
        
        // Visões
        $_REQUEST["dados"]["qtdTransfusoesTiposanguineo"] = $this->relatorioDAO->qtdTransfusoesTiposanguineo();
        $_REQUEST["dados"]["qtdDoacoesEspontaneasSexo"] = $this->relatorioDAO->qtdDoacoesEspontaneasSexo();
        
        require_once "views/relatorios.php";
        
    }
    
    public function editar() {
        
        require_once "views/404.php";
        
    }
    
    public function adicionar() {
        
        require_once "views/404.php";
        
    }
    
}