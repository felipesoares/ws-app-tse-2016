<?php

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "EstabelecimentoDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "EstabelecimentoTipoDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "EstabelecimentoTipoUctDAO.php";
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . "models" . DIRECTORY_SEPARATOR . "EstadoDAO.php";

class EstabelecimentoController {
    
    private $estabelecimentoDAO;
    private $estabelecimentoTipoDAO;
    private $estabelecimentoTipoUctDAO;
    private $estadoDAO;
    
    public function __construct() {
        $this->estabelecimentoDAO = new EstabelecimentoDAO();
        $this->estabelecimentoTipoDAO = new EstabelecimentoTipoDAO();
        $this->estabelecimentoTipoUctDAO = new EstabelecimentoTipoUctDAO();
        $this->estadoDAO = new EstadoDAO();
    }
    
    public function listar() {
        
        $_REQUEST["dados"] = $this->estabelecimentoDAO->listar();
        
        require_once "views/{$_GET["pagina"]}.php";
    }
    
    public function editar() {
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
    public function adicionar() {
        
        $_REQUEST["dados"]["estabelecimentoTipo"] = $this->estabelecimentoTipoDAO->listar();
        $_REQUEST["dados"]["estabelecimentoTipoUct"] = $this->estabelecimentoTipoUctDAO->listar();
        $_REQUEST["dados"]["estado"] = $this->estadoDAO->listar();
        
        require_once "views/{$_GET["pagina"]}-formulario.php";
    }
    
}