<?php

class Functions {
    
    public static function filtrarDados($string) {
        return trim($string);
        return addslashes(trim($string));
    }
    
    public static function printHtml($string){
        return htmlentities ( $string, ENT_QUOTES, "UTF-8" );
    }
    
    public static function jsonEncode($status, $msg, $js) {
        
        return json_encode(array(
            "status" => $status,
            "msg" => $msg,
            "js" => $js
        ));
        
    }
    
    public static function jsonRequiredFields($js = null) {
        
        return json_encode(array(
            "status" => "warning",
            "msg" => "Todos os campos obrigatórios devem ser preenchidos",
            "js" => $js
        ));
        
    }
    
    public static function jsonInvalidEmail($js = null) {
        
        return json_encode(array(
            "status" => "warning",
            "msg" => "E-mail inválido",
            "js" => $js
        ));
        
    }
    
    public static function jsonInvalidMaioridade($js = null) {
        
        return json_encode(array(
            "status" => "warning",
            "msg" => "Data de nascimento inferior a 18 anos",
            "js" => $js
        ));
        
    }
    
    public static function jsonInvalidCpf($js = null) {
        
        return json_encode(array(
            "status" => "warning",
            "msg" => "CPF inválido",
            "js" => $js
        ));
        
    }
    
    public static function jsonInvalidCnpj($js = null) {
        
        return json_encode(array(
            "status" => "warning",
            "msg" => "CNPJ inválido",
            "js" => $js
        ));
        
    }
    
    public static function jsonInvalidCep($js = null) {
        
        return json_encode(array(
            "status" => "warning",
            "msg" => "CEP inválido",
            "js" => $js
        ));
        
    }
    
    
    public static function jsonSuccess($js = null) {
        
        return json_encode(array(
            "status" => "success",
            "msg" => "Dados Salvos com Sucesso!",
            "js" => $js
        ));
        
    }
    
    public static function jsonSuccessRedirect($pagina, $acao, $id) {
        
        $status = "success";
        $msg = "Dados Salvos com Sucesso!";
        
        $_SESSION["notice"]["status"] = $status;
        $_SESSION["notice"]["msg"] = $msg;
        
        if( self::strtolower($acao) == "editar" )
            $js = "window.location = '?pagina={$pagina}&acao={$acao}&id={$id}'; ";
        else
            $js = "window.location = '?pagina={$pagina}&acao={$acao}'; ";
        
        return json_encode(array(
            "status" => $status,
            "msg" => "",
            "js" => $js
        ));
        
    }
    
    public static function jsonError($js = null) {
        
        return json_encode(array(
            "status" => "error",
            "msg" => "Erro ao tentar salvar Dados!",
            "js" => $js
        ));
        
    }
    
    public static function jsonSuccessDelete($js = null) {
        
        return json_encode(array(
            "status" => "success",
            "msg" => "Dados Excluídos com Sucesso!",
            "js" => $js
        ));
        
    }
    
    public static function jsonErrorDelete($js = null) {
        
        return json_encode(array(
            "status" => "error",
            "msg" => "Erro ao tentar excluir Dados!",
            "js" => $js
        ));
        
    }
    
    
    public static function validarStatus($status) {
        
        return (in_array($status, array(
            1,
            2
        )));
        
    }
    
    public static function validarEmail($email) {
        
        return (preg_match("/^[a-z0-9_\.\-]+@[a-z0-9_\.\-]*[a-z0-9_\-]+\.[a-z]{2,4}$/", $email));
        
    }
    
    public static function validarCPF($cpf) {
        
        $cpf = self::cleanCPF($cpf);
        
        if (isset($cpf["10"]) && is_numeric($cpf)) {
            
            for ($x = 0; $x < 10; $x++) { # Verifica se nenhuma das sequência foi digitada, caso seja, retorna falso
                if ($cpf == str_repeat($x, 11)) {
                    return false;
                }
            }
            
            # Calcula os números para verificar se o CPF é verdadeiro
            for ($t = 9; $t < 11; $t++) {
                for ($d = 0, $c = 0; $c < $t; $c++) {
                    $d += $cpf{$c} * (($t + 1) - $c);
                }
                
                $d = ((10 * $d) % 11) % 10;
                
                if ($cpf{$c} != $d) {
                    return false;
                }
            }
            return true;
            
        }
        return false;
        
    }
    
    public static function validarCNPJ($cnpj) {
        
        $cnpj = self::cleanCNPJ($cnpj);
        
        if (strlen($cnpj) != 14 || !is_numeric($cnpj))
            return false;
        
        $k     = 6;
        $soma1 = "";
        $soma2 = "";
        
        for ($i = 0; $i < 13; $i++) {
            $k = $k == 1 ? 9 : $k;
            $soma2 += ($cnpj{$i} * $k);
            $k--;
            if ($i < 12) {
                if ($k == 1) {
                    $k = 9;
                    $soma1 += ($cnpj{$i} * $k);
                    $k = 1;
                } else {
                    $soma1 += ($cnpj{$i} * $k);
                }
            }
        }
        
        $digito1 = $soma1 % 11 < 2 ? 0 : 11 - $soma1 % 11;
        $digito2 = $soma2 % 11 < 2 ? 0 : 11 - $soma2 % 11;
        
        return ($cnpj{12} == $digito1 and $cnpj{13} == $digito2);
    }
    
    public static function validarCEP($cep) {
        
        $cep = self::cleanCEP($cep);
        
        return (isset($cep["7"]) && is_numeric($cep));
        
    }
    
    public static function validarData($data) { # BR
        
        $data = explode(" ", $data);
        
        if (substr_count($data[0], "/") == 2) {
            list($dia, $mes, $ano) = explode("/", $data[0]);
            return checkdate($mes, $dia, $ano);
        }
        return false;
    }
    
	public static function validarMaioridade($dataNascimento) { # BR
		
		if (self::validarData ( $dataNascimento )) {
			list ( $dia_nasc, $mes_nasc, $ano_nasc ) = explode ( "/", $dataNascimento );
			list ( $dia_hoje, $mes_hoje, $ano_hoje ) = explode ( "/", date ( "d/m/Y" ) );
			return mktime ( 00, 00, 00, $mes_nasc, $dia_nasc, $ano_nasc ) <= mktime ( 00, 00, 00, $mes_hoje, $dia_hoje, $ano_hoje - 18 );
		}
        return false;
		
	}
	
	public static function formatarDateTime($datetime, $type = "br") {
		
		if (preg_match ( "/ /", $datetime )) {
			list ( $date, $time ) = explode ( " ", $datetime );
		} else {
			$date = $datetime;
			$time = null;
		}
		
		if ($type == "br") {
			if (substr_count ( $date, "-" ) == 2) {
				list ( $year, $month, $day ) = explode ( "-", $date );
				$date = implode ( "/", array ($day, $month, $year ) );
			}
		} else{
			if (substr_count ( $date, "/" ) == 2) {
				list ( $day, $month, $year ) = explode ( "/", $date );
				$date = implode ( "-", array ($year, $month, $day ) );
			}
		}
		
        $datetime = array(
            "date"      =>  $date,
            "time"      =>  $time,
            "datetime"  =>  $date." ".$time,
        );
        
        $datetime = (object) $datetime;
        
        return $datetime;
	}
	
	public static function formatarDecimaisView($num) {
		return self::getValorMonetario( $num );
	}
	
	public static function formatarDecimaisBanco($num) {
		return str_replace ( array(".", ","), array("", "."), $num );
	}
	
	public static function getValorMonetario($valor, $casas = 2) {
		return number_format ( $valor, $casas, ",", "." );
	}
	
	public static function maskString($mascara, $string) {
		
		$string = str_replace ( " ", "", $string );
		
		for($i = 0; $i < strlen ( $string ); $i ++) {
			$mascara [strpos ( $mascara, "#" )] = $string [$i];
		}
		return $mascara;
	}
	
    public static function cleanCPF($cpf) {
        
        return preg_replace("@[.-]@", "", $cpf);
        
    }
    
    public static function maskCPF($cpf) {
        
        return self::maskString( "###.###.###-##", $cpf );
        
    }
    
    public static function cleanCNPJ($cnpj) {
        
        return preg_replace("@[./-]@", "", $cnpj);
        
    }
    
    public static function maskCNPJ($cnpj) {
        
        return self::maskString( "##.###.###/####-##", $cnpj );
        
    }
    
    public static function cleanCEP($cep) {
        
        return preg_replace("@[.-]@", "", $cep);
        
    }
    
    public static function maskCEP($cep) {
        
        return self::maskString( "##.###-###", $cep );
        
    }
    
	# http://www.php.net/manual/pt_BR/function.mb-strtolower.php
	public static function strtolower($str){
		return mb_strtolower($str, "UTF-8");
	}
	
	# http://www.php.net/manual/pt_BR/function.mb-strtoupper.php
	public static function strtoupper($str){
		return mb_strtoupper($str, "UTF-8");
	}
	
	# http://www.php.net/manual/pt_BR/function.mb-convert-case.php
	public static function ucwords($str){
		return mb_convert_case($str, MB_CASE_TITLE, "UTF-8");
	}
	
	public static function formatarNome($nome) {
		
		$nome = self::ucwords( $nome );
		
		$maiusculas = array (" Da ", " Das ", " De ", " Do ", " Dos " );
		$minusculas = array (" da ", " das ", " de ", " do ", " dos " );
		
		return str_replace ( $maiusculas, $minusculas, $nome );
	}
	
}
